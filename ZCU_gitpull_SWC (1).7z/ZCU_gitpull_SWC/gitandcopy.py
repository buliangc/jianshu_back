# -*- coding: utf-8 -*-
import os
import shutil
import subprocess
import SDB_Interface_Configuration


asw_geely_swc = "pkg/asw/geely_swc"
gitee_path="https://gitee.geely.com/Geely_Supplier"
# 删除替换文件
replace_items = ["bin/hsm", "pkg/bswpackage", "pkg/tools", "pkg/cdd", "pkg/cfg", "workspace/contiswc", "workspace/ecuconfig", "workspace/variants"]
replace_items_ccm = ["pkg/asw/geely_ccm", "workspace/ccmswc"]
replace_items_ccmStore = ["geely_ccm", "ccmswc"]
variant_replaces = {"ZCUDS": "workspace/RTE_ZCUD_S", "ZCUDM": "workspace/RTE_ZCUD_M", "ZCUP": "workspace/RTE_ZCUDP"}
# initial.cmake文件插入
initial_cmake_insert = {"ZCUDS":[r"pkg/tools/app/variants/${variant}/cdd/RealSystemTime","pkg/asw/geely_swc","RealSystemTime","geely_swc"],
                        "ZCUDM":[r"pkg/tools/app/variants/${variant}/cdd/LGOC","pkg/asw/geely_swc","LGOC","geely_swc"],
                        "ZCUP":[r"pkg/tools/app/variants/${variant}/cdd/LGOC","pkg/asw/geely_swc", "pkg/asw/geely_ccm","LGOC","geely_swc", "geely_ccm"],}
# 回退文件
checkout_files_D = ["pkg/tools/ci_scripts/conan/shell_paths.sh","pkg/tools/ci_scripts/conan/shell_paths.bat"]
checkout_files_P = ["pkg/tools/ci_scripts/conan/shell_paths.sh", "pkg/tools/app/variants/ZCUP/app/DiagMgr/CMakeLists.txt"]

# ZCU路径选择
def switch_type(ZCU_type):
    all_types = ["ZCUD", "ZCUDS", "ZCUDM", "ZCUP"]
    if ZCU_type in all_types:
        print(" ===================Your project is {}===================".format(ZCU_type))
    else:
        print("ERROR: Your project is Wrong")
        exit(1)
    
    global sub_path
    # if ZCU_type == "ZCUDS":
    #     sub_path = "zcu_d/zcud_s"
    # elif ZCU_type == "ZCUDM":
    #     sub_path = "zcu_d/zcud_m"
    # elif ZCU_type == "ZCUP":
    #     sub_path = "zcu_p"
    sub_path = ''    
    return sub_path

# 拉取仓库代码 是否清空修改可选
def git_pull(git_path, branch_name,clean_gitrepo):
    repo = git_path.split("/")
    git_flag = 0
    print(" ===================开始拉取 {} 仓库最新代码================= ".format(repo[-1]))
    if not os.path.exists(git_path):
        print("Your repository is not exist, clone from gitee")
        subprocess.run(["git", "clone", f"{gitee_path}/{repo[-1]}.git"])
    subdirectories = [name for name in os.listdir(git_path) if os.path.isdir(os.path.join(git_path, name))]
    # print(subdirectories)
    for subdir in subdirectories:
        # 如果目录是Git仓库
        if '.git' == subdir:
            git_flag = 1
    if git_flag == 1:
        os.chdir(git_path)
        # 清除修改
        if clean_gitrepo == 1:
            subprocess.run(["git", "clean", "-dfx"])
            subprocess.run(["git", "reset", "--hard"])
        subprocess.run(["git", "fetch"])
        
        # 切换分支
        if subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch_name}"]).returncode == 0:
            subprocess.run(["git", "checkout", branch_name])
        elif subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/remotes/origin/{branch_name}"]).returncode == 0:
            subprocess.run(["git", "checkout", "-b", branch_name, f"origin/{branch_name}"])
        else:
            # print(f"ERROR: Branch {branch_name} does not exist ====")
            # return 1
            # 检查输入是否是tag
            if subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/tags/{branch_name}"]).returncode == 0:
                subprocess.run(["git", "checkout", branch_name])
            else:
                print(f"ERROR: Branch or tag {branch_name} does not exist ====")
                return 1
        subprocess.run(["git", "pull"])
        subprocess.run(["git", "log","-n 5"])
    else:
        print(f"ERROR: {git_path} is not a repo ====")
    return 0

# 删除设定路径的文件
def delete_files(zcu_path,replace_items, replace_items_ccm, variant_replaces, release_type, ZCU_type, ccmUpdate_choose):
    print(" ===================删除geely文件=================== ")
    for replace_item in replace_items:
        shutil.rmtree(os.path.join(zcu_path,replace_item))
        print(f"delete_item: {replace_item}")
    if ccmUpdate_choose == 1:
        print(" ===================删除ccm文件=================== ")
        for replace_item in replace_items_ccm:
            shutil.rmtree(os.path.join(zcu_path, replace_item))
            print(f"delete_item: {replace_item}")
			
    if ZCU_type != "ZCUP":
        shutil.rmtree(os.path.join(zcu_path, variant_replaces[ZCU_type]))
        print(f"delete_item: {variant_replaces[ZCU_type]}")
    # 总集成环境释放需要删除替换geely_swc
    if release_type == "Full":
        shutil.rmtree(os.path.join(zcu_path, asw_geely_swc, "file_c"))
        shutil.rmtree(os.path.join(zcu_path, asw_geely_swc, "file_h"))
        print("delete_item: pkg/asw/geely_swc")

# 拷贝设定路径的文件
def copy_files(conti_zcu_path, ccm_path, geely_zcu_path, replace_items, replace_items_ccm, variant_replaces, release_type, geely_swc,ZCU_type,  ccmUpdate_choose):
    print(" ===================复制conti文件到geely=================== ")
    for replace_item in replace_items:
        shutil.copytree(os.path.join(conti_zcu_path, replace_item), os.path.join(geely_zcu_path, replace_item))
        print(f"copy_item: {replace_item}")
    if ccmUpdate_choose == 1:
        print(" ===================复制ccm文件到geely=================== ")
        itemNum = 0
        for replace_item in replace_items_ccm:
            shutil.copytree(os.path.join(ccm_path, replace_items_ccmStore[itemNum]), os.path.join(geely_zcu_path, replace_item))
            itemNum += 1
            print(f"copy_item: {replace_item}")
			
    if ZCU_type != "ZCUP":
        shutil.copytree(os.path.join(conti_zcu_path, variant_replaces[ZCU_type]), os.path.join(geely_zcu_path, variant_replaces[ZCU_type]))
        print(f"copy_item: {variant_replaces[ZCU_type]}")
    # copy geely_swc
    if release_type == "Full":
        shutil.copytree(os.path.join(geely_swc, "files_c"), os.path.join(geely_zcu_path, asw_geely_swc, "file_c"))
        shutil.copytree(os.path.join(geely_swc, "files_h"), os.path.join(geely_zcu_path, asw_geely_swc, "file_h"))
        print("copy_item: pkg/asw/geely_swc")
    # 预编译的时候copy conti doc文件夹中表格到geely doc,表格要求不存在于geely doc
    if release_type == "Pre":
        for root, dirs, files in os.walk(os.path.join(conti_zcu_path,"doc")):
            for file in files:
                if file.endswith('.xlsx'):
                    file_path = os.path.join(root, file)
                    destination_file_path = os.path.join(geely_zcu_path,"doc", file)
                    # 目的地不存在同名文件
                    if not os.path.exists(destination_file_path):
                        shutil.copy(file_path, os.path.join(geely_zcu_path,"doc"))

# 获取某一行的前置空格的数量
def get_leading_space_counter(line):
    count = 0
    for char in line:
        if char == ' ':
            count += 1
        else:
            break

    return count

# 修正文件
def edit_files(geely_path, sub_path,geely_template_swc,ZCU_type):
    print(" ===================回退shell_path及修改cmake_exclude和initial文件=================== ")
    os.chdir(geely_path)
    # 回退文件
    if ZCU_type != "ZCUP":
        checkout_files = checkout_files_D
    else:
        checkout_files = checkout_files_P
    for file in checkout_files:
        subprocess.run(['git', 'checkout', 'HEAD', os.path.join(sub_path,file)])
        print(f"checkout_file:{file}")

    # varient路径    
    if ZCU_type == "ZCUDS":
        zcu_variant = "ZCUD_S"
    elif ZCU_type == "ZCUDM":
        zcu_variant = "ZCUD_M"
    elif ZCU_type == "ZCUP":
        zcu_variant = "ZCUP"

    # 修正initial.cmake 插入pkg/asw/geely_swc、geely_swc
    file_date = ""
    with open(os.path.join(geely_path,sub_path,f"pkg/tools/app/variants/{zcu_variant}/initial.cmake"), 'r') as f_in:
        for line in f_in:
            if ZCU_type == "ZCUP":
                if initial_cmake_insert[ZCU_type][0]  == line.strip().replace("\n",""):
                    couter = get_leading_space_counter(line)
                    line = line + " " * couter + initial_cmake_insert[ZCU_type][1] + '\n' + " " * couter + initial_cmake_insert[ZCU_type][2] + "\n" 
                    print("geely_swc_path_line:\n",line)
                elif initial_cmake_insert[ZCU_type][3] == line.strip().replace("\n",""):
                    couter = get_leading_space_counter(line)
                    line = line + " " * couter + initial_cmake_insert[ZCU_type][4] + "\n" + " " * couter + initial_cmake_insert[ZCU_type][5] + "\n"
                    print("geely_swc_line:\n",line)
                file_date += line
            else:
                if initial_cmake_insert[ZCU_type][0]  == line.strip().replace("\n",""):
                    couter = get_leading_space_counter(line)
                    line = line + " " * couter + initial_cmake_insert[ZCU_type][1] + "\n" 
                    print("geely_swc_path_line:\n",line)
                elif initial_cmake_insert[ZCU_type][2] == line.strip().replace("\n",""):
                    couter = get_leading_space_counter(line)
                    line = line + " " * couter + initial_cmake_insert[ZCU_type][3] + "\n"
                    print("geely_swc_line:\n",line)
                file_date += line
    with open(os.path.join(geely_path,sub_path,f"pkg/tools/app/variants/{zcu_variant}/initial.cmake"), 'w') as f_out:
        f_out.write(file_date)

    # 修正cmake_exclude.yaml 插入geely_swc_template.c
    file_date = ""
    with open(os.path.join(geely_path,sub_path,f"pkg/tools/app/variants/{zcu_variant}/cmake_exclude.yaml"), 'r') as f_in:
        for line in f_in:
            if r'h_files:' in line:
                couter = get_leading_space_counter(preline)
                geely_template_swc_with_space = geely_template_swc.strip("\n").replace("\n","\n" + " " * couter)
                line = " " * couter + geely_template_swc_with_space + "\n" + line
                # print("geely_template_swc:\n",line,
                #       "geely_template_swc_with_space:\n",geely_template_swc_with_space,
                #       "geely_template_swc:\n",geely_template_swc)
            file_date += line
            preline = line
    with open(os.path.join(geely_path,sub_path,f"pkg/tools/app/variants/{zcu_variant}/cmake_exclude.yaml"), 'w') as f_out:
        f_out.write(file_date)

# 编译代码
def generate_code(geely_zcu_path):     
    parent_dir = os.path.dirname(geely_zcu_path)
    os.chdir(parent_dir)

    current_dir = os.getcwd()
    # print("当前所在文件夹:", current_dir)
    script_path = os.path.join(current_dir, 'build_onekey.sh')
    if not os.path.exists(script_path):
        print("Error: build_onekey.sh script not found in the current directory.")
        return
    
    # Change file permissions if needed (uncomment if necessary)
    # os.chmod(script_path, 0o755)
    # 调用shell脚本 build_onekey.sh
    print("执行sheel脚本：build_onekey.sh")
    # 重新拉起一个bash输出
    # process = subprocess.Popen(script_path, stdin=subprocess.PIPE, shell=True,text=True)
    # 在python的终端上输出
    process = subprocess.Popen(["bash",script_path], text=True)
    # process.stdin.write('2\n')
    # process.stdin.flush()
    # process.stdin.close()
    # 等待脚本执行完成
    process.wait()
    print("\n generate bash进程执行完毕，返回值为:", process.returncode)

# 开始执行选择的操作
def run(run_config):
    # load config
    geely_path = run_config["geely_path"]
    conti_path = run_config["conti_path"]
    ccm_path = run_config["ccm_path"]
    geely_branch = run_config["geely_branch"]
    conti_branch = run_config["conti_branch"]
    ccm_branch = run_config["ccm_branch"]
    release_type = run_config["release_type"]
    ZCU_type = run_config["ZCU_type"]
    compare_path = run_config["compare_path"] 
    interface_path = run_config["interface_path"]
    geely_swc = run_config["geely_swc"]
    git_choose = run_config["git_choose"]
    clean_choose = run_config["clean_choose"]
    copy_choose = run_config["copy_choose"]
    comp_choose = run_config["comp_choose"]
    geely_template_swc = run_config["geely_template_swc"]
    ccmUpdate_choose = run_config["ccmUpdate_choose"]
    interface_choose = run_config["interface_choose"]
    generate_choose = run_config["gennrate_choose"]
    ZCU_Switch = run_config["ZCU_Switch"]
    # 路径转换
    sub_path = switch_type(ZCU_type)
    geely_zcu_path = os.path.join(geely_path,sub_path)
    conti_zcu_path = os.path.join(conti_path,sub_path)
    # 拉取代码可选择清空修改
    if git_choose == 1:
        if git_pull(geely_path, geely_branch,clean_choose) != 0:
            print("ERROR: 拉取geely代码失败")
            exit(1)
        elif git_pull(conti_path, conti_branch,clean_choose) != 0:
                print("ERROR: 拉取conti代码失败")
                exit(1)
        elif ccmUpdate_choose == 1:
                if git_pull(ccm_path, ccm_branch,clean_choose) != 0:
                    print("ERROR: 拉取ccm代码失败")
                    exit(1)
    # 拷贝conti文件并修正
    if copy_choose == 1:
        delete_files(geely_zcu_path, replace_items, replace_items_ccm, variant_replaces, release_type,ZCU_type, ccmUpdate_choose)
        copy_files(conti_zcu_path, ccm_path, geely_zcu_path, replace_items, replace_items_ccm, variant_replaces, release_type, geely_swc,ZCU_type,  ccmUpdate_choose)
        edit_files(geely_path, sub_path,geely_template_swc,ZCU_type)
    # 调用接口配置脚本
    if interface_choose == 1:
        SDB_Interface_Configuration.Interface_Config(geely_zcu_path,interface_path,ZCU_type,ZCU_Switch)
    # 调用脚本编译代码
    if generate_choose == 1:
        generate_code(geely_zcu_path)
    # 打开compare进行比较
    if comp_choose == 1:
        try:
            result = subprocess.run([compare_path, "-solo", conti_zcu_path, geely_zcu_path],check=True)
        except subprocess.CalledProcessError as e:
            print("命令执行出错，退出码为:", e.returncode)
        else:
            print("compare 命令执行成功，退出码为:", result.returncode)    
