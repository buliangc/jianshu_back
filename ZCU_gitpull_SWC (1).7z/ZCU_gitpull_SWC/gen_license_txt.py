import base64

expire_date = "2025-12-31"
token = "geely2024"
plain = f"expire_date={expire_date};token={token}"
b64 = base64.b64encode(plain.encode("utf-8")).decode("utf-8")

with open("license.txt", "w", encoding="utf-8") as f:
    f.write(b64)

print("加密license.txt已生成，内容如下：")
print(b64)
