import sys
import json
import time
import traceback
import os
from datetime import datetime
import base64
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QComboBox, QTextEdit,
    QVBoxLayout, QHBoxLayout, QFileDialog, QSizePolicy, QFrame, QSplashScreen, QMessageBox
)
from PyQt5.QtCore import Qt, QObject, pyqtSignal, QThread, QTimer
from PyQt5.QtGui import QFont, QIcon, QPixmap
import SDB_Interface_Configuration

CONFIG_FILE = "config.json"
LICENSE_FILE = "license.txt"

LICENSE_TOKEN = "geely2024"  # 你可以自定义token

def resource_path(relative_path):
    """获取资源文件的绝对路径，兼容PyInstaller打包和源码运行"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

def check_license():
    """检查加密license有效性，返回(是否有效, 错误信息/到期时间)"""
    if not os.path.exists(LICENSE_FILE):
        return False, "未检测到license文件，请导入有效license。"
    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return False, "license文件内容为空。"
            try:
                decoded = base64.b64decode(content).decode("utf-8")
                # txt内容格式: expire_date=YYYY-MM-DD;token=xxxx
                parts = dict(x.split("=", 1) for x in decoded.split(";") if "=" in x)
                expire_str = parts.get("expire_date")
                token = parts.get("token")
            except Exception as e:
                return False, f"license文件解码或解析失败: {str(e)}"
        if not expire_str:
            return False, "license文件格式错误，缺少expire_date字段。"
        if not token:
            return False, "license文件格式错误，缺少token字段。"
        if token != LICENSE_TOKEN:
            return False, "license token不正确。"
        try:
            expire_date = datetime.strptime(expire_str, "%Y-%m-%d")
        except Exception as e:
            return False, f"expire_date格式错误，需为YYYY-MM-DD: {str(e)}"
        now = datetime.now()
        if now > expire_date:
            return False, f"license已过期，有效期至: {expire_str}"
        return True, expire_str
    except Exception as e:
        return False, f"license文件读取失败: {str(e)}"

# 自定义流类，用于重定向stdout
class Stream(QObject):
    newText = pyqtSignal(str)
    
    def write(self, text):
        self.newText.emit(str(text))
    
    def flush(self):
        pass

# 工作线程类，用于执行耗时任务
class Worker(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(str)
    error = pyqtSignal(str)
    
    def __init__(self, project_folder, interface_type, excel_file, project_name):
        super().__init__()
        self.project_folder = project_folder
        self.interface_type = interface_type
        self.excel_file = excel_file
        self.project_name = project_name
        self._is_running = True
    
    def run(self):
        """执行长时间运行的任务"""
        try:
            self.progress.emit(f"[INFO] 开始运行工程...")
            self.progress.emit(f"[INFO] 工程文件夹: {self.project_folder}\n")
            self.progress.emit(f"[INFO] 项目名称: {self.project_name}\n")
            self.progress.emit(f"[INFO] 接口类型: {self.interface_type}\n")
            self.progress.emit(f"[INFO] Excel文件: {self.excel_file}\n")

            # 模拟处理过程
            self.progress.emit(f"[DEBUG] 正在加载Excel文件: {self.excel_file}")
            time.sleep(1)
            SDB_Interface_Configuration.Interface_Config(
                self.project_folder, self.excel_file, self.project_name, self.interface_type
            )
            self.progress.emit(f"[INFO] 工程构建完成!")
            self.progress.emit(f"[SUCCESS] 处理完成! ")
        except Exception as e:
            self.error.emit(f"[ERROR] 运行过程中发生错误: {str(e)}")
            self.error.emit(traceback.format_exc())
        finally:
            self.finished.emit()
    
    def stop(self):
        """停止任务"""
        self._is_running = False

class MyGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.license_valid, self.license_info = check_license()
        self.load_config()
        self.initUI()
        
        # 设置窗口图标
        self.setWindowIcon(QIcon(resource_path("geely_logo.png")))  # 使用资源路径
        
        # 设置stdout重定向
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        self.output_stream = Stream()
        self.output_stream.newText.connect(self.append_output)
        sys.stdout = self.output_stream
        sys.stderr = self.output_stream
        
        # 打印初始信息
        print("=" * 60)
        print("工程配置界面已启动")
        print(f"当前配置: {self.config}")
        print("=" * 60)
        
        # 初始化线程
        self.thread = None
        self.worker = None

    def initUI(self):
        self.setWindowTitle('吉利汽车工程配置界面 ---- WAS')
        self.setGeometry(100, 100, 800, 800)

        # 主布局
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # 顶部吉利 Logo 和标题
        header_frame = QFrame()
        header_layout = QVBoxLayout(header_frame)  # 使用 QVBoxLayout 使内容居中
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(10)

        geely_logo = QLabel()
        geely_logo.setPixmap(QPixmap(resource_path("geely_logo.png")).scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        geely_logo.setAlignment(Qt.AlignCenter)  # 居中对齐

        geely_title = QLabel("吉利汽车工程配置工具")
        geely_title.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: #1a6baf;
        """)
        geely_title.setAlignment(Qt.AlignCenter)  # 居中对齐

        header_layout.addWidget(geely_logo)
        header_layout.addWidget(geely_title)

        main_layout.addWidget(header_frame)

        # 配置区域
        config_frame = QFrame()
        config_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 10px;
                border: 1px solid #d0d0d0;
            }
        """)
        config_layout = QVBoxLayout(config_frame)
        config_layout.setContentsMargins(20, 20, 20, 20)
        config_layout.setSpacing(20)

        # 工程文件夹选择
        folder_layout = QHBoxLayout()
        folder_layout.setSpacing(15)
        
        self.project_folder_label = QLabel("选择工程文件夹：")
        self.project_folder_label.setFixedWidth(140)
        self.project_folder_label.setStyleSheet("font-weight: bold; color: #555;")
        
        self.project_folder_path = QLabel(self.config.get("project_folder", "未选择"))
        self.project_folder_path.setObjectName("path-label")
        self.project_folder_path.setStyleSheet("""
            QLabel#path-label {
                background-color: #f8f8f8;
                border: 2px solid #a0c5e8;
                border-radius: 8px;
                padding: 5px;
                color: #333;
                font-size: 14px;
                min-height: 30px;  /* 统一高度 */
            }
        """)
        self.project_folder_path.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        
        self.project_folder_button = QPushButton("浏览")
        self.project_folder_button.setFixedHeight(50)  # 增大按钮高度
        self.project_folder_button.setFixedWidth(120)  # 增大按钮宽度
        self.project_folder_button.setStyleSheet("""
            QPushButton {
                background-color: #5b9bd5;
                color: white;
                font-weight: bold;
                border: 2px solid #a0c5e8;  /* 添加边框 */
                border-radius: 8px;
                padding: 8px;  /* 调整内边距 */
            }
            QPushButton:hover {
                background-color: #4a8bc4;
            }
        """)
        self.project_folder_button.clicked.connect(self.browse_project_folder)
        
        folder_layout.addWidget(self.project_folder_label)
        folder_layout.addWidget(self.project_folder_path)
        folder_layout.addWidget(self.project_folder_button)
        config_layout.addLayout(folder_layout)

        # 项目名称选择
        project_name_layout = QHBoxLayout()
        project_name_layout.setSpacing(15)

        self.project_name_label = QLabel("项目名称：")
        self.project_name_label.setFixedWidth(140)
        self.project_name_label.setStyleSheet("font-weight: bold; color: #555;")

        self.project_name_combo = QComboBox()
        self.project_name_combo.setFixedHeight(30)
        self.project_name_combo.addItems(["ZCUD", "ZCUP"])
        saved_project_name = self.project_name if hasattr(self, "project_name") else "ZCUD"
        # saved_project_name = self.config["project_name"]  
        index = self.project_name_combo.findText(saved_project_name)
        if index >= 0:
            self.project_name_combo.setCurrentIndex(index)
        # 统一风格样式
        down_arrow_path = resource_path('down_arrow.png').replace("\\", "/")
        combo_style = (
            "QComboBox {"
            "background-color: white;"
            "border: 2px solid #a0c5e8;"
            "border-radius: 8px;"
            "padding: 5px;"
            "font-size: 14px;"
            "min-height: 30px;"
            "}"
            "QComboBox::drop-down {"
            "subcontrol-origin: padding;"
            "subcontrol-position: top right;"
            "width: 30px;"
            "border-left-width: 1px;"
            "border-left-color: #a0c5e8;"
            "border-left-style: solid;"
            "border-top-right-radius: 8px;"
            "border-bottom-right-radius: 8px;"
            "}"
            "QComboBox::down-arrow {"
            f"image: url({down_arrow_path});"
            "width: 16px;"
            "height: 16px;"
            "}"
        )
        self.project_name_combo.setStyleSheet(combo_style)

        project_name_layout.addWidget(self.project_name_label)
        project_name_layout.addWidget(self.project_name_combo)
        config_layout.addLayout(project_name_layout)

        # 接口类型选择
        interface_layout = QHBoxLayout()
        interface_layout.setSpacing(15)
        
        self.interface_label = QLabel("接口类型：")
        self.interface_label.setFixedWidth(140)
        self.interface_label.setStyleSheet("font-weight: bold; color: #555;")
        
        self.interface_combo = QComboBox()
        self.interface_combo.setFixedHeight(30)  # 统一高度
        self.interface_combo.addItems(["cemswc", "chassisswc", "irrm", "hcmswc","geely_bsw","supply"])
        saved_interface = self.config.get("interface_type", "chassisswc")
        index = self.interface_combo.findText(saved_interface)
        if index >= 0:
            self.interface_combo.setCurrentIndex(index)
        # 使用同一风格
        self.interface_combo.setStyleSheet(combo_style)
        
        interface_layout.addWidget(self.interface_label)
        interface_layout.addWidget(self.interface_combo)
        config_layout.addLayout(interface_layout)

        # Excel 文件选择
        excel_layout = QHBoxLayout()
        excel_layout.setSpacing(15)
        
        self.excel_file_label = QLabel("选择Excel文件：")
        self.excel_file_label.setFixedWidth(140)
        self.excel_file_label.setStyleSheet("font-weight: bold; color: #555;")
        
        self.excel_file_path = QLabel(self.config.get("excel_file", "未选择"))
        self.excel_file_path.setObjectName("path-label")
        self.excel_file_path.setStyleSheet("""
            QLabel#path-label {
                background-color: #f8f8f8;
                border: 2px solid #a0c5e8;
                border-radius: 8px;
                padding: 5px;
                color: #333;
                font-size: 14px;
                min-height: 30px;  /* 统一高度 */
            }
        """)
        self.excel_file_path.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        
        self.excel_file_button = QPushButton("浏览")
        self.excel_file_button.setFixedHeight(50)  # 增大按钮高度
        self.excel_file_button.setFixedWidth(120)  # 增大按钮宽度
        self.excel_file_button.setStyleSheet("""
            QPushButton {
                background-color: #5b9bd5;
                color: white;
                font-weight: bold;
                border: 2px solid #a0c5e8;  /* 添加边框 */
                border-radius: 8px;
                padding: 8px;  /* 调整内边距 */
            }
            QPushButton:hover {
                background-color: #4a8bc4;
            }
        """)
        self.excel_file_button.clicked.connect(self.browse_excel_file)
        
        excel_layout.addWidget(self.excel_file_label)
        excel_layout.addWidget(self.excel_file_path)
        excel_layout.addWidget(self.excel_file_button)
        config_layout.addLayout(excel_layout)

        main_layout.addWidget(config_frame)

        # 按钮区域
        button_frame = QFrame()
        button_layout = QHBoxLayout(button_frame)
        button_layout.setContentsMargins(0, 0, 0, 0)

        self.import_license_button = QPushButton("导入License")
        self.import_license_button.setFixedSize(140, 40)
        self.import_license_button.setStyleSheet("""
            QPushButton {
                background-color: #ff9800;
                color: white;
                font-weight: bold;
                font-size: 14px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #e68900;
            }
        """)
        self.import_license_button.clicked.connect(self.import_license)

        self.run_button = QPushButton("开始运行")
        self.run_button.setFixedSize(180, 40)  # 调整高度
        self.run_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                font-size: 16px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #888888;
            }
        """)
        self.run_button.clicked.connect(self.run)
        
        self.save_config_button = QPushButton("保存配置")
        self.save_config_button.setFixedSize(180, 40)  # 调整高度
        self.save_config_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-weight: bold;
                font-size: 16px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #0b7dda;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #888888;
            }
        """)
        self.save_config_button.clicked.connect(self.save_config)
        
        # 添加清除日志按钮
        self.clear_log_button = QPushButton("清除日志")
        self.clear_log_button.setFixedSize(120, 40)  # 调整高度
        self.clear_log_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                font-weight: bold;
                font-size: 14px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)
        self.clear_log_button.clicked.connect(self.clear_log)
        
        button_layout.addWidget(self.import_license_button)
        button_layout.addStretch()
        button_layout.addWidget(self.run_button)
        button_layout.addSpacing(20)
        button_layout.addWidget(self.save_config_button)
        button_layout.addStretch()
        button_layout.addWidget(self.clear_log_button)
        main_layout.addWidget(button_frame)

        # 输出区域
        output_frame = QFrame()
        output_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 10px;
                border: 1px solid #d0d0d0;
            }
        """)
        output_layout = QVBoxLayout(output_frame)
        output_layout.setContentsMargins(15, 15, 15, 15)
        
        output_title = QLabel("运行输出信息")
        output_title.setStyleSheet("font-weight: bold; font-size: 16px; color: #1a6baf;")
        output_layout.addWidget(output_title)
        
        self.log_text_edit = QTextEdit()
        self.log_text_edit.setReadOnly(True)
        self.log_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #f5f9ff;
                border: 2px solid #a0c5e8;
                border-radius: 8px;
                padding: 10px;
                font-family: 'Courier New', monospace;
                font-size: 13px;
                color: #333;
            }
        """)
        output_layout.addWidget(self.log_text_edit)
        
        main_layout.addWidget(output_frame, 1)  # 添加拉伸因子使输出区域占据更多空间

        # 显示license到期信息
        license_label = QLabel(f"License有效期至: {self.license_info if self.license_valid else '无效/未导入'}")
        license_label.setStyleSheet("color: #ff9800; font-size: 13px; font-weight: bold;")
        main_layout.addWidget(license_label)

        self.setLayout(main_layout)

        # 根据license状态禁用功能按钮
        self.update_license_ui()

    def load_config(self):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except:
            self.config = {}

    def save_config(self):
        self.config["project_folder"] = self.project_folder_path.text()
        self.config["interface_type"] = self.interface_combo.currentText()
        self.config["excel_file"] = self.excel_file_path.text()
        self.config["project_name"] = self.project_name_combo.currentText()
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=4)
        print(f"[INFO] 配置已保存：{CONFIG_FILE}")

    def append_output(self, text):
        """将输出添加到日志区域"""
        cursor = self.log_text_edit.textCursor()
        cursor.movePosition(cursor.End)
        cursor.insertText(text + "\n")
        self.log_text_edit.ensureCursorVisible()

    def clear_log(self):
        """清除日志内容"""
        self.log_text_edit.clear()
        print("[INFO] 日志已清除")

    def browse_project_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "选择工程文件夹")
        if folder:
            self.project_folder_path.setText(folder)
            print(f"[INFO] 已选择工程文件夹: {folder}")

    def browse_excel_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "选择Excel文件", filter="Excel Files (*.xlsx *.xls)")
        if file:
            self.excel_file_path.setText(file)
            print(f"[INFO] 已选择Excel文件: {file}")

    def update_license_ui(self):
        # 只有license有效时，功能按钮可用
        enable = self.license_valid
        self.run_button.setEnabled(enable)
        self.save_config_button.setEnabled(enable)
        self.clear_log_button.setEnabled(enable)
        self.project_folder_button.setEnabled(enable)
        self.excel_file_button.setEnabled(enable)
        self.project_name_combo.setEnabled(enable)
        self.interface_combo.setEnabled(enable)

    def import_license(self):
        file, _ = QFileDialog.getOpenFileName(self, "选择license文件", filter="License (*.txt)")
        if file:
            try:
                with open(file, "rb") as src:
                    raw = src.read()
                    if raw.startswith(b'\xef\xbb\xbf'):
                        raw = raw[3:]
                    content = raw.decode("utf-8").strip()
                if not content:
                    QMessageBox.critical(self, "License无效", "导入的license文件内容为空。")
                    return
                try:
                    decoded = base64.b64decode(content).decode("utf-8")
                    parts = dict(x.split("=", 1) for x in decoded.split(";") if "=" in x)
                except Exception as e:
                    QMessageBox.critical(self, "License无效", f"导入的license不是合法加密内容: {str(e)}")
                    return
                if parts.get("token") != LICENSE_TOKEN:
                    QMessageBox.critical(self, "License无效", "license token不正确。")
                    return
                with open(LICENSE_FILE, "w", encoding="utf-8") as dst:
                    dst.write(content)
                valid, info = check_license()
                if valid:
                    QMessageBox.information(self, "License导入成功", f"License导入成功，有效期至: {info}\n请重启程序。")
                else:
                    QMessageBox.critical(self, "License无效", info)
            except Exception as e:
                QMessageBox.critical(self, "导入失败", f"导入license失败: {str(e)}")

    def run(self):
        # license再次校验，防止运行时被替换
        valid, info = check_license()
        if not valid:
            QMessageBox.critical(self, "License错误", info)
            return

        project_folder = self.project_folder_path.text()
        interface_type = self.interface_combo.currentText()
        excel_file = self.excel_file_path.text()
        project_name = self.project_name_combo.currentText()

        # 验证输入
        if not project_folder or project_folder == "未选择":
            print("[ERROR] 请先选择工程文件夹")
            return
            
        if not excel_file or excel_file == "未选择":
            print("[ERROR] 请先选择Excel文件")
            return
        
        # 禁用按钮防止重复运行
        self.run_button.setEnabled(False)
        self.project_folder_button.setEnabled(False)
        self.excel_file_button.setEnabled(False)
        
        # 清空日志
        self.log_text_edit.clear()
        print(f"[INFO] 开始运行任务...")
        
        # 创建线程
        self.thread = QThread()
        self.worker = Worker(project_folder, interface_type, excel_file, project_name)
        
        # 将worker移动到线程
        self.worker.moveToThread(self.thread)
        
        # 连接信号
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        
        self.worker.progress.connect(self.append_output)
        self.worker.error.connect(self.append_output)
        
        # 线程结束时启用按钮
        self.thread.finished.connect(lambda: self.run_button.setEnabled(True))
        self.thread.finished.connect(lambda: self.project_folder_button.setEnabled(True))
        self.thread.finished.connect(lambda: self.excel_file_button.setEnabled(True))
        
        # 启动线程
        self.thread.start()

class SplashScreen(QSplashScreen):
    def __init__(self):
        # 确保提供正确的图片路径
        pixmap = QPixmap(resource_path("geely_logo1.png"))
        if pixmap.isNull():
            print("[ERROR] 无法加载启动界面的图片，请检查路径是否正确。")
            pixmap = QPixmap(400, 400)  # 创建一个空白图片
            pixmap.fill(Qt.gray)  # 填充为灰色
        else:
            pixmap = pixmap.scaled(400, 400, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        
        super().__init__(pixmap)
        self.setWindowFlags(Qt.FramelessWindowHint)

        # 创建文字背景区域
        self.text_frame = QLabel(self)
        self.text_frame.setGeometry(0, pixmap.height(), pixmap.width(), 50)  # 设置文字区域大小
        self.text_frame.setStyleSheet("background-color: black;")
        
        # 创建文字标签
        self.text_label = QLabel("欢迎使用吉利汽车工程配置工具", self.text_frame)
        self.text_label.setAlignment(Qt.AlignCenter)
        self.text_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        self.text_label.setGeometry(0, 0, pixmap.width(), 50)  # 设置文字标签大小


if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    # 显示启动界面
    splash = SplashScreen()
    splash.show()
    
    # 延迟启动主界面
    QTimer.singleShot(3000, splash.close)  # 3秒后关闭启动界面
    
    window = MyGUI()
    QTimer.singleShot(3000, window.show)  # 3秒后显示主界面
    
    sys.exit(app.exec_())