#!/usr/bin/python
# -*- coding: UTF-8 -*-
import xml.etree.ElementTree as ET
import getopt
import sys
import os
import GetList
import Generate_Element
import Delete_Element
import Feature
import Process_Excel
import Add_Element
import pickle
from collections import Counter 
import json  
import os  
import pandas as pd 
from datetime import datetime 
# 定义文件名  
Special_interface_file_name = r'Special_interface_data.json'  

Value_Interface_List = []

Application_DataTypeList = []

def print_with_timestamp(message):  
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  
    print(f"{timestamp} - {message}")  
# 从 JSON 文件加载数据  
def load_data_from_file():  
    if os.path.exists(Special_interface_file_name):  
        with open(Special_interface_file_name, 'r') as file:  
            data = json.load(file)  
            return data.get('Value_Interface_List', [])  
    return []  

# 将数据存储到 JSON 文件  
def save_data_to_file(data):  
    with open(Special_interface_file_name, 'w') as file:  
        json.dump({'Value_Interface_List': data}, file, indent=4)  

# 添加新元素到列表，确保不重复  
def add_unique_elements(existing_list, new_list):  
    # 创建一个新列表来保存唯一的元素  
    updated_list = existing_list.copy()  # 复制现有列表  
    for item in new_list:  
        if item not in updated_list:  # 检查新元素是否已存在  
            updated_list.append(item)  # 如果不存在，则添加  
    return updated_list  

def Interface_Config(geely_zcu_path, interface_path, ZCU_type,ZCU_Switch):  

    # print("开始配置接口", geely_zcu_path,interface_path, ZCU_type, ZCU_Switch)
    data = dict()  
    data["Excel_Name"] = interface_path  
    data["ECU_Name"] = ZCU_type  
    # print("开始配置接口", data["ECU_Name"],ZCU_Switch)
    # ==== 路径优化统一定义 ====  
    sdb_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\common", "SDB")  
    # geely_cem_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc", "geelycem") 
    if ZCU_type == "ZCUD":
        if ZCU_Switch == "cemswc":
            print("进入Cemswc分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\SWC") 
            group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\geely_cem.arxml")
            group_swc_name = "geely_cem"
            #解析Geely文件
        elif ZCU_Switch == "chassisswc":
            print("进入chassisswc分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\chassisswc\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\chassisswc\chassis.arxml")
            group_swc_name = "chassis"
        elif ZCU_Switch == "DTMS":
            print("进入supply分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\DTMS\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\DTMS\CDTMS.arxml")
            group_swc_name = "CDTMS"
        elif ZCU_Switch == "hcmswc":
            print("进入hcmswc分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\hcmswc\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\hcmswc\HCM.arxml")
            group_swc_name = "HCM"
        elif ZCU_Switch == "geely_bsw":
            print("进入geely_bsw分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\geely_basetech.arxml")
            group_swc_name = "geely_basetech"
        elif ZCU_Switch == "supply":
            print("进入supply分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\supply.arxml")
            group_swc_name = "supply"
        

        geely_cem_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\geely_cem.arxml")
        chassis_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\chassisswc\chassis.arxml")
        cdtms_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\DTMS\CDTMS.arxml")
        hcm_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\hcmswc\hcm.arxml")
        supply_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\supply.arxml")
        geely_basetech_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\geely_basetech.arxml")

        common_arxml_path = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\common", "Common.arxml")  
    else:
        if ZCU_Switch == "cemswc":
            print("进入Cemswc分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\SWC") 
            group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\geely_cem.arxml")
            group_swc_name = "geely_cem"
            #解析Geely文件
            
        # elif ZCU_Switch == "irrm":
        #     geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\irrm\SWC")  
        #     group_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\irrm\irrm.arxml")
        #     group_swc_name = "irrm"
        elif ZCU_Switch == "geely_bsw":
            print("进入geely_bsw分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\geely_basetech.arxml")
            group_swc_name = "geely_basetech"
        elif ZCU_Switch == "supply":
            print("进入supply分支")
            geelycem_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\SWC")  
            group_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\supply.arxml")
            group_swc_name = "supply"

        geely_cem_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc\geely_cem.arxml")
        # irrm_dir = os.pasth.join(geely_zcu_path, "Workspace\ASW\Arxml\irrm\irrm.arxml")
        supply_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SUP\supply.arxml")
        geely_basetech_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\BSW\geely_basetech.arxml")
        common_arxml_path = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\common", "Common.arxml")  



    # geely_cem_arxml_path = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\cemswc", "geely_cem.arxml")  
    # conti_composition_path = os.path.join(geely_zcu_path, "workspace", "basetech", "basetech.arxml")  
    # hirain_composition_path = os.path.join(geely_zcu_path, "workspace", "hirainswc", "hirain_swc.arxml")  
    # supplyswc_path = os.path.join(geely_zcu_path, "workspace", "supplyswc", "supplyswc.arxml")  

    # SDB中带'Swc'的文件名  
    data["SDB_Name"] = next((f for f in os.listdir(sdb_dir) if 'Swc' in f), None)  

    # 已经添加过的datatype列表，防止重复  
    Add_Data_type_List = []  
    # 已经添加过的port列表，防止重复  
    Add_Port_List = []  

    
    # if group_swc_name == "supply":
    #     if ZCU_type == "ZCUD": 
    #         geelybsw_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SWC")  
    #         geelydtms_swc_dir = os.path.join(geely_zcu_path, "Workspace\ASW\Arxml\DTMS/SWC")  
    #         supply_swc_dir = os.path.join(geely_zcu_path,"Workspace/ASW/Arxml/uaesswc/SWC")  
    #         # 获取两个路径中的文件列表
    #         list1 = [file for file in os.listdir(geelybsw_swc_dir) if '.keep' not in file]
    #         swc_list_path1 = [os.path.join(geelybsw_swc_dir, file) for file in list1]
    #         list2 = [file for file in os.listdir(geelydtms_swc_dir) if '.keep' not in file]
    #         swc_list_path2 = [os.path.join(geelydtms_swc_dir, file) for file in list2]
    #         list3 = [file for file in os.listdir(supply_swc_dir) if '.keep' not in file]
    #         swc_list_path3 = [os.path.join(supply_swc_dir, file) for file in list3]
    #         # 合并两个列表（去除重复项）
    #         SWC_List = list(set(list1 + list2 +list3))
    #         swc_list_path = list(set(swc_list_path1 + swc_list_path2 +swc_list_path3))
    #     else: 
    #         geelybsw_swc_dir = os.path.join(geely_zcu_path, "Workspace\Common_Service\Arxml\SWC")  
    #         supply_swc_dir = os.path.join(geely_zcu_path,"Workspace/ASW/Arxml/uaesswc/SWC")  
    #         # 获取两个路径中的文件列表
    #         list1 = [file for file in os.listdir(geelybsw_swc_dir) if '.keep' not in file]
    #         swc_list_path1 = [os.path.join(geelybsw_swc_dir, file) for file in list1]
    #         list2 = [file for file in os.listdir(supply_swc_dir) if '.keep' not in file]
    #         swc_list_path2 = [os.path.join(supply_swc_dir, file) for file in list2]
    #         # 合并两个列表（去除重复项）
    #         SWC_List = list(set(list1 + list2 ))
    #         swc_list_path = list(set(swc_list_path1  +swc_list_path2))
    # else:
    #     # 获得所有SWC文件名且过滤掉包含.keep的文件  
    #     SWC_List = os.listdir(geelycem_swc_dir)  
    #     SWC_List = [file for file in SWC_List if '.keep' not in file]
    #     swc_list_path = [os.path.join(geelycem_swc_dir, file) for file in SWC_List]  
    SWC_List = os.listdir(geelycem_swc_dir)  
    SWC_List = [file for file in SWC_List if '.keep' not in file]
    swc_list_path = [os.path.join(geelycem_swc_dir, file) for file in SWC_List]  

    print(swc_list_path)
    # 解析Common文件，路径判断保持不变  
    if os.path.exists(common_arxml_path):  
        Common_AUTOSAR = Feature.parse_file(common_arxml_path)  
    else:  
        Common_AUTOSAR = Feature.parse_file(common_arxml_path)  

    # 解析SDB文件  
    SDB_AUTOSAR = Feature.parse_file(os.path.join(sdb_dir, data["SDB_Name"]))  


    group_AUTOSAR = Feature.parse_file(os.path.join(group_dir))


    #######################################删除接口用
    #解析Geely文件  
    Geely_AUTOSAR = Feature.parse_file(geely_cem_dir)  

    if ZCU_type == "ZCUD": 
        #解析chassis文件  
        Chassis_AUTOSAR = Feature.parse_file(chassis_dir)  

        CDTMS_AUTOSAR = Feature.parse_file(cdtms_dir)  

        HCM_AUTOSAR = Feature.parse_file(hcm_dir)  

        #解析hcm文件  
        # Hcm_AUTOSAR = Feature.parse_file(hcm_dir)  
    else:
        #解析irrm文件  
        pass
        # Irrm_AUTOSAR = Feature.parse_file(irrm_dir) 

    #解析supplyswc文件  
    Supplyc_AUTOSAR = Feature.parse_file(supply_dir)  

    Geely_basetech_AUTOSAR = Feature.parse_file(geely_basetech_dir)  
    #######################################

    # 获得接口表DataType Dict的列表  
    Data_Tpye_Dict_List = Process_Excel.Get_Data_Type_Dict(data["Excel_Name"], "DataType Dict")  

    # 获得接口表DataType Dict的列表  
    Array_Data_Tpye_Dict_List = Process_Excel.Get_Array_Data_Type_Dict(data["Excel_Name"], "DataType Dict") 
    print("Array_Data_Tpye_Dict_List",Array_Data_Tpye_Dict_List)
    # 获得接口表array的列表（Receiver + Sender）  
    Array_Dict_List = Process_Excel.Get_Array_Dict(data["Excel_Name"], "Receiver Port")  
    Array_Dict_List.extend(Process_Excel.Get_Array_Dict(data["Excel_Name"], "Sender Port"))
    Array_Dict_List = Array_Dict_List + Array_Data_Tpye_Dict_List
    print("Array_Dict_List",Array_Dict_List)
    # 获得接口表Receiver Port的列表  
    Receiver_Port_Dict_List = Process_Excel.Get_Receiver_Port_Dict(data["Excel_Name"], "Receiver Port")  

    # 获得需要删除的接收接口数据  
    Receiver_Port_Delete_Dict = Process_Excel.Get_Execl_Delete_List(data["Excel_Name"], "Receiver Port")  
    # print("Receiver_Port_Delete_Dict",Receiver_Port_Delete_Dict)  
    # 获得需要删除的发送接口数据  
    Sender_Port_Delete_Dict = Process_Excel.Get_Execl_Delete_List(data["Excel_Name"], "Sender Port")  

    # 获得接口表的Sender port的列表  
    Sender_Port_Dict_List = Process_Excel.Get_Sender_Port_Dict(data["Excel_Name"], "Sender Port")  

    # 获得Common下相关列表  
    CompuMethods_Data_type_List = GetList.Get_CompuMethodsList(Common_AUTOSAR)  
    BaseTypes_Data_type_List = GetList.Get_BaseTypesList(Common_AUTOSAR)  
    DataTypeImplementation_Data_type_List = GetList.Get_DataTypeImplementationList(Common_AUTOSAR)  
    ImplementationDataTypes_Data_type_List = GetList.Get_ImplementationDataTypesList(Common_AUTOSAR)  
    PortInterfaces_List = GetList.Get_PortInterfacesList(Common_AUTOSAR)  
    Port_Dict_Data_Type, Port_Dict_DataElement = GetList.Get_Common_Data_Type(Common_AUTOSAR) 
    #获得Commom下DataConstrs的datatype的列表
    DataConstrs_Data_type_List = GetList.Get_DataConstrsList(Common_AUTOSAR)

    # SDB相关
    SDB_BaseTypes_List = GetList.Get_BaseTypesList(SDB_AUTOSAR)
    ApplicationDataTypes_Data_type_List, Application_DataTypeList = GetList.Get_ApplicationDataTypesList(SDB_AUTOSAR)
    ApplicationDataTypes_Data_type_List_Common, Application_DataTypeList_Common = GetList.Get_ApplicationDataTypesList(Common_AUTOSAR)
    ApplicationDataTypes_Data_type_List += ApplicationDataTypes_Data_type_List_Common
    Application_DataTypeList.update(Application_DataTypeList_Common)

    # 获取SDB DataConstrs
    SDB_DataConstrs_Dict = GetList.Get_SDB_DataConstrs_Dict(SDB_AUTOSAR)
    SDB_DataConstrs_List = GetList.Get_SDB_DataConstrs_List(SDB_AUTOSAR)
    SDB_ComPuMethods_List = GetList.Get_CompuMethodsList(SDB_AUTOSAR)
    SDB_PortInterfaces_List = GetList.Get_PortInterfacesList(SDB_AUTOSAR)

    # # Geely文件中的接口
    # Geely_ReceiverPorts_List = GetList.Get_Geely_ReceiverPorts_List(Geely_AUTOSAR)
    # Geely_SenderPorts_List = GetList.Get_Geely_SenderPorts_List(Geely_AUTOSAR)
    # Geely_Assembly_connector_list = GetList.Get_Geely_assembly_sw_connector_list(Geely_AUTOSAR)
    # Geely_Delegation_connector_list = GetList.Get_Geely_delegation_sw_connector_list(Geely_AUTOSAR)

    # SDB中的连线
    SDB_Assembly_connector_list = GetList.Get_SDB_assembly_sw_connector_list(SDB_AUTOSAR, data["ECU_Name"])
    SDB_Delegation_connector_list = GetList.Get_SDB_delegation_sw_connector_list(SDB_AUTOSAR, data["ECU_Name"])

    # 处理接口数据的初始值字典（序列化存储）
    current_dir = os.path.dirname(os.path.realpath(__file__))
    pickle_filepath = os.path.join(current_dir, f'Interface_Data_Dype_Dict_{data["ECU_Name"]}.pickle')
    with open(pickle_filepath, 'rb') as f:
        Interface_Data_Dype_Dict = pickle.load(f)
    Interface_Data_Dype_Dict = Feature.Interface_Data_Dype(Interface_Data_Dype_Dict, Data_Tpye_Dict_List)
    with open(pickle_filepath, 'wb') as f:
        pickle.dump(Interface_Data_Dype_Dict, f)

    # 初始化值数据类型
    InitValue_DataType_Dict_f = os.path.join(current_dir, f'InitValue_DataType_Dict_{data["ECU_Name"]}.pickle')
    with open(InitValue_DataType_Dict_f, 'rb') as f:
        InitValue_DataType_Dict = pickle.load(f)
    InitValue_DataType_Dict = Feature.InitValue_DataType_Dict(InitValue_DataType_Dict, Data_Tpye_Dict_List)
    with open(InitValue_DataType_Dict_f, 'wb') as f:
        pickle.dump(InitValue_DataType_Dict, f)

    # # 获取所有SWC文件名
    # swc_files = os.listdir(swc_dir)
    # swc_files = [file for file in swc_files if '.keep' not in file]

    # 获取不同SWC中的DataMapping

    DtatMapping_Dict = GetList.Get_SWC_DataMapping(swc_list_path)
 

    # 加载已存在的数据  
    Value_Interface_List = load_data_from_file() 
    # print("Value_Interface_Lis111",Value_Interface_List)
    #####################################################################################################################
    ############################################  备注列新增element       ################################################
    #####################################################################################################################
    #####################################################################################################################
    
    # for Receiver_Port_Dict in Receiver_Port_Dict_List: 
    #     for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
    #         if("新增" == Receiver_Port["Size"]):
    #             if Receiver_Port["Interface"] not in Value_Interface_List: 
    #                 Value_Interface_List.append(Receiver_Port["Interface"])
    #                 # print("size",Receiver_Port["Size"])

    # for Sender_Port_Dict in Sender_Port_Dict_List:
    #     for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:   
    #         if("新增" == Sender_Port["Size"]):
    #             if Sender_Port["Interface"] not in Value_Interface_List: 
    #                 Value_Interface_List.append(Sender_Port["Interface"])
    #                 # print("size",Sender_Port["Size"])   

    #####################################################################################################################
    ################################################    结束   ###########################################################
    #####################################################################################################################            
    # 初始化一个空字典，用于统计每个SWC和接口的接收端口信息  
    Receiver_count = {}  
    # 遍历接收端口字典列表  
    for Receiver_Port_Dict in Receiver_Port_Dict_List:  
        # 遍历每个接收端口字典中的接收端口列表  
        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:  
            swc = Receiver_Port["SWC"]  # 获取SWC  
            interface = Receiver_Port["Interface"]  # 获取接口  
            # receiver_port = Receiver_Port["Receiver_Port"]  # 获取接收端口  
            element = Receiver_Port["Element"]  # 获取Element (新提取的元素) 

            # 如果SWC不在count字典中，初始化一个新的字典  
            if swc not in Receiver_count:  
                Receiver_count[swc] = {}  
            # 如果接口不在SWC的字典中，初始化计数和接收端口列表  
            if interface not in Receiver_count[swc]:   
                Receiver_count[swc][interface] = {"Receiver_count": 0, "receiver_ports": [], "elements": []}   
                # 将接收端口添加到对应接口的接收端口列表中  
                Receiver_count[swc][interface]["receiver_ports"].append(interface) 
                
            # 增加该接口的计数  
            if Receiver_Port["Data_Access_Mode"]  != "IsUpdated" and element not in Receiver_count[swc][interface]["elements"]:
                # print("Receiver_Port",swc,interface,element,Receiver_Port["Data_Access_Mode"])
                Receiver_count[swc][interface]["elements"].append(element)  # 将Element添加到elements列表中  
                Receiver_count[swc][interface]["Receiver_count"] += 1   
    # print("Receiver_count",Receiver_count)
    # 初始化结果列表  
    result = []  
    # 用于跟踪已添加的接口，避免重复添加  
    added_interfaces = set()  

    # 遍历统计结果  
    for swc, interfaces in Receiver_count.items():  
        for interface, Receiver_data in interfaces.items():   
            # 如果该接口的计数大于2且尚未添加  
            if Receiver_data["Receiver_count"] >= 2 and interface not in added_interfaces:  
                # 将该接口及其接收端口添加到结果列表中  
                # print("Receiver_Port",swc,interface,Receiver_data["Receiver_count"])
                for rp in Receiver_data["receiver_ports"]:  
                    result.append((interface, rp))  
                # 标记该接口已添加  
                added_interfaces.add(interface)  

    
    # 使用集合去重，避免重复的结果  
    unique_strings = set()  

    # 遍历结果列表，提取唯一的字符串  
    for sublist in result:  
        for item in sublist:  
            unique_strings.add(item)  
    # print("RXadded_interfaces",list(unique_strings))
    Sender_count  = {}  
 # 遍历接收端口字典列表  
    for Sender_Port_Dict in Sender_Port_Dict_List:
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            swc = Sender_Port["SWC"]  # 获取SWC  
            interface = Sender_Port["Interface"]  # 获取接口  
            # sender_port = Sender_Port["Sender_Port"]  # 获取接收端口  
            element = Sender_Port["Element"]  # 获取Element (新提取的元素) 
            
            # 如果SWC不在count字典中，初始化一个新的字典  
            if swc not in Sender_count:  
                Sender_count[swc] = {}  
            # 如果接口不在SWC的字典中，初始化计数和接收端口列表  
            if interface not in Sender_count[swc]:   
                # Sender_count[swc][interface] = {"Sender_count": 0, "sender_ports": []}   
                Sender_count[swc][interface] = {"Sender_count": 0, "sender_ports": [], "elements": []}
                # 将接收端口添加到对应接口的接收端口列表中  
                Sender_count[swc][interface]["sender_ports"].append(interface)

                # print("Sender_count", Sender_count)    
            # 增加该接口的计数 
            if Sender_Port["Data_Access_Mode"]  != "IsUpdated" and element not in Sender_count[swc][interface]["elements"]:                 
                Sender_count[swc][interface]["elements"].append(element)  # 将Element添加到elements列表中
                Sender_count[swc][interface]["Sender_count"] += 1   
    # 初始化结果列表  
    result = []  
    # 用于跟踪已添加的接口，避免重复添加  
    added_interfaces = set()  

    # 遍历统计结果  
    for swc, interfaces in Sender_count.items():  
        for interface, Sender_data in interfaces.items():   
            # 如果该接口的计数大于2且尚未添加  
            
            if Sender_data["Sender_count"] >= 2 and interface not in added_interfaces:  
                # 将该接口及其接收端口添加到结果列表中  
                for rp in Sender_data["sender_ports"]:  
                    result.append((interface, rp))  
                # 标记该接口已添加  
                added_interfaces.add(interface)  

    # 遍历结果列表，提取唯一的字符串  
    for sublist in result:  
        for item in sublist:  
            unique_strings.add(item)  

    # print("TXadded_interfaces",list(unique_strings))
    # print("Value_Interface_List_OLD",Value_Interface_List)
    # Value_Interface_List = list(unique_strings) 

    # 将现有数据与新数据合并  
    Value_Interface_List = add_unique_elements(Value_Interface_List, list(unique_strings))  
    save_data_to_file(Value_Interface_List)
    print("Data has been updated and saved.")
    # # 检查是否需要保存（如果有变化则保存）  
    # if Value_Interface_List != Value_Interface_List:  
    #     save_data_to_file(Value_Interface_List)  
    #     print("Data has been updated and saved.")  
    # else:  
    #     print("Data is already up to date. No changes were made.")  

    
    if(Value_Interface_List == []):
        print("没有需要配置的接口")
        Common_CarCfg_SHORT_NAME_List = []
        Common_CarCfg_List  = []
    else:
        # print("Value_Interface_List",Value_Interface_List)
        Common_CarCfg_SHORT_NAME_List = GetList.Get_CarCfg_SHORT_NAME_List(Common_AUTOSAR,Value_Interface_List)
        Common_CarCfg_List = GetList.Get_CarCfg_List(Common_AUTOSAR,Value_Interface_List)
        print("Common_CarCfg_List",Common_CarCfg_List)

#    #数据类型添加到include部分功能
#     if group_swc_name == "chassis":
#         #################后续功能##################################################
#         # SWC_DataTYPE_Include_list  = GetList.Get_SWC_Include_DataType(geelycem_swc_dir,SWC_List)
#         # print("DtatMapping_Dict",SWC_DataTYPE_Include_list)
#         ######################################################################################
#         for Data_Tpye_Dict in Data_Tpye_Dict_List:
#             Add_Data_type_List.append(Data_Tpye_Dict["Data_Type"])
#             if "{}.arxml".format(Data_Tpye_Dict["SWC"]) not in SWC_List:
#                 print("缺少SWC文件1","{}.arxml".format(Data_Tpye_Dict["SWC"]), "请检查")
#             else:
#                 SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"])))
#                 # #获得当前SWC引用哪个SWC的DATa mapping
#                 SWC_DataTYPE_Include_list = GetList.Get_SWC_DataTYPE_Ref(SWC_AUTOSAR,Data_Tpye_Dict["SWC"])
#                 print("DaTaMapping_Ref_Field_Name",SWC_DataTYPE_Include_list)
#                 if Data_Tpye_Dict["Data_Type"] not in SWC_DataTYPE_Include_list[Data_Tpye_Dict["SWC"]]:
#                     element = Generate_Element.Process_Include_DataType(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
#                     Add_Element.Add_Include_DataType_Element(SWC_AUTOSAR, element)
                    
#                 ET.indent(SWC_AUTOSAR)
#                 Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"]))) 


   #数据类型添加到include部分功能
        #################后续功能##################################################
        # SWC_DataTYPE_Include_list  = GetList.Get_SWC_Include_DataType(geelycem_swc_dir,SWC_List)
        # print("DtatMapping_Dict",SWC_DataTYPE_Include_list)
        ######################################################################################
    # print("NoInterface111",Data_Tpye_Dict_List)
    # print(NoInterface11)
    for Data_Tpye_Dict in Data_Tpye_Dict_List:
        
        if Data_Tpye_Dict["NoInterface"] == "NoInterface":
            # print("NoInterface111",Data_Tpye_Dict["NoInterface"],Data_Tpye_Dict["SWC"],Data_Tpye_Dict["Data_Type"])
            Add_Data_type_List.append(Data_Tpye_Dict["Data_Type"])
            if "{}.arxml".format(Data_Tpye_Dict["SWC"]) not in SWC_List:
                print("缺少SWC文件1","{}.arxml".format(Data_Tpye_Dict["SWC"]), "请检查")
            else:
                SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"])))
                # #获得当前SWC引用哪个SWC的DATa mapping
                SWC_DataTYPE_Include_list = GetList.Get_SWC_DataTYPE_Ref(SWC_AUTOSAR,Data_Tpye_Dict["SWC"])
                # print("DaTaMapping_Ref_Field_Name",SWC_DataTYPE_Include_list)
                if Data_Tpye_Dict["Data_Type"] not in SWC_DataTYPE_Include_list[Data_Tpye_Dict["SWC"]]:
                    print("NoInterface",Data_Tpye_Dict["NoInterface"],Data_Tpye_Dict["SWC"],Data_Tpye_Dict["Data_Type"])
                    element = Generate_Element.Process_Include_DataType(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                    Add_Element.Add_Include_DataType_Element(SWC_AUTOSAR, element,Data_Tpye_Dict["SWC"])
                    
                ET.indent(SWC_AUTOSAR)
                Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"]))) 

    
    #数据类型部分功能
    # dididi = print1("Data_Tpye_Dict_List")
    for Data_Tpye_Dict in Data_Tpye_Dict_List:
        Add_Data_type_List.append(Data_Tpye_Dict["Data_Type"])
        if "{}.arxml".format(Data_Tpye_Dict["SWC"]) not in SWC_List:
            print("缺少SWC文件1","{}.arxml".format(Data_Tpye_Dict["SWC"]), "请检查")
        else:
            #当datatype的类型为VALUE时
            if Data_Tpye_Dict["Type"] == "VALUE":
                #判断datatype是否在CompuMethods_Data_type_List中
                if Data_Tpye_Dict["Data_Type"] not in SDB_ComPuMethods_List:
                    if Data_Tpye_Dict["Data_Type"] in CompuMethods_Data_type_List or Data_Tpye_Dict["Data_Type"] in Add_Data_type_List:
                        #删除旧的datatype，创建新的
                        Delete_Element.Delete_CompuMethods_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_CompuMethods(Data_Tpye_Dict)
                        Add_Element.Add_CompuMethods_Element(Common_AUTOSAR, element)
                    else:
                        element = Generate_Element.Process_CompuMethods(Data_Tpye_Dict)
                        Add_Element.Add_CompuMethods_Element(Common_AUTOSAR, element)
                    #判断datatype是否在BaseTypes_Data_type_List中
                if Data_Tpye_Dict["Data_Type"] not in SDB_BaseTypes_List:
                    if Data_Tpye_Dict["Data_Type"] in BaseTypes_Data_type_List or Data_Tpye_Dict["Data_Type"] in Add_Data_type_List:
                        Delete_Element.Delete_BaseTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_BaseTypes(Data_Tpye_Dict)
                        Add_Element.Add_BaseTypes_Element(Common_AUTOSAR, element)
                    else:
                        element = Generate_Element.Process_BaseTypes(Data_Tpye_Dict)
                        Add_Element.Add_BaseTypes_Element(Common_AUTOSAR, element)
                #判断datatype是否在DataConstrs中
                if Data_Tpye_Dict["Data_Type"] not in SDB_DataConstrs_List:
                    if Data_Tpye_Dict["Data_Type"] in DataConstrs_Data_type_List or Data_Tpye_Dict["Data_Type"] in Add_Data_type_List:
                        # Delete_Element.Delete_DataConstrs_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])   //当前删除，之后DataConstrs能新建则加上
                        if Data_Tpye_Dict["Data_Type"] in SDB_DataConstrs_Dict:
                            element = SDB_DataConstrs_Dict[Data_Tpye_Dict["Data_Type"]]
                            Add_Element.Add_DataConstrs_Element(Common_AUTOSAR, element)
                        else:
                            pass                   
                    else:
                        if Data_Tpye_Dict["Data_Type"] in SDB_DataConstrs_Dict:
                            element = SDB_DataConstrs_Dict[Data_Tpye_Dict["Data_Type"]]
                            Add_Element.Add_DataConstrs_Element(Common_AUTOSAR, element)
                        else:
                            pass
                #判断DataTypeImplementation是否含有该datatype
                if Data_Tpye_Dict["Data_Type"] in ImplementationDataTypes_Data_type_List or Data_Tpye_Dict["Data_Type"] in Add_Data_type_List:
                    if Data_Tpye_Dict["Data_Type"] in DataTypeImplementation_Data_type_List:
                        Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                        Add_Element.Add_DataTypeImplementation_Element(Common_AUTOSAR, element)
                    else:
                        Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                        Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
                else:
                    element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                    Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
                #SDB的ApplicationDataTypes是否含有该datatype
                if Data_Tpye_Dict["Data_Type"] in ApplicationDataTypes_Data_type_List:
                    # print("SDB的ApplicationDataTypes含有该datatype")
                    #解析对应的SWC文件
                    SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"])))
                    # print(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Data_Tpye_Dict["SWC"])))
                    #获得当前SWC引用哪个SWC的DATa mapping
                    DaTaMapping_Ref_Field_Name = GetList.Get_SWC_DataMapping_Ref(SWC_AUTOSAR)
                    
                    DaTaMapping_Field_Name = DaTaMapping_Ref_Field_Name.split("_")[-1]
                    DaTaMapping_Ref_Name = DaTaMapping_Ref_Field_Name.split("_{}".format(DaTaMapping_Field_Name))[-2]
                    SWC_DataMapping_FileNames = DtatMapping_Dict[DaTaMapping_Ref_Name]
                    
                    for SWC_FileName in SWC_DataMapping_FileNames:
                        SWC_Name = SWC_FileName.split(".arxml")[0]
                        # print("当前SWC为：{}".format(SWC_Name))
                        #在当前SWC下添加DataMapping
                        DataMapping_SWC_SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, SWC_FileName))
                        #产看SWC文件是否含有DataTypeMappings
                        if Feature.contain_package(DataMapping_SWC_SWC_AUTOSAR, "DataTypeMappings"):
                            #获得对应SWC下DataTypeMappings的datatype的列表
                            DataTypeMappings_List = GetList.Get_DataTypeMappingsList(DataMapping_SWC_SWC_AUTOSAR,DaTaMapping_Ref_Name)
                            if Data_Tpye_Dict["Data_Type"] in DataTypeMappings_List:
                                Delete_Element.Delete_DataTypeMappings_DataType(DataMapping_SWC_SWC_AUTOSAR, Data_Tpye_Dict["Data_Type"],DaTaMapping_Ref_Name)
                                element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                # print("删除",SWC_Name,Data_Tpye_Dict["Data_Type"],element,DaTaMapping_Ref_Name)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                            else:
                                element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                # print("添加",SWC_Name,Data_Tpye_Dict["Data_Type"],element,DaTaMapping_Ref_Name)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        else:
                            element = Generate_Element.Process_DataTypeMappings_Top()
                            Add_Element.Add_DataTypeMappings_Top_Element(DataMapping_SWC_SWC_AUTOSAR, element)
                            element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)    
                        ET.indent(DataMapping_SWC_SWC_AUTOSAR)
                        Feature.save_file(DataMapping_SWC_SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))          
            #当datatype的类型为STRUCTURE时
            elif Data_Tpye_Dict["Type"] == "STRUCTURE":
                if Data_Tpye_Dict["Data_Type"] in ImplementationDataTypes_Data_type_List or Data_Tpye_Dict["Data_Type"] in Add_Data_type_List:
                    if Data_Tpye_Dict["Data_Type"] in DataTypeImplementation_Data_type_List:
                        Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                        Add_Element.Add_DataTypeImplementation_Element(Common_AUTOSAR, element)
                    else:
                        Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict["Data_Type"])
                        element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                        Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)

                else:
                    element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                    Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
                #SDB的ApplicationDataTypes是否含有该datatype
                if Data_Tpye_Dict["Data_Type"] in ApplicationDataTypes_Data_type_List:
                    #解析对应的SWC文件
                    
                    SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Data_Tpye_Dict["SWC"])))
                    #获得当前SWC引用哪个SWC的DATa mapping
                    DaTaMapping_Ref_Field_Name = GetList.Get_SWC_DataMapping_Ref(SWC_AUTOSAR)
                    DaTaMapping_Field_Name = DaTaMapping_Ref_Field_Name.split("_")[-1]
                    DaTaMapping_Ref_Name = DaTaMapping_Ref_Field_Name.split("_{}".format(DaTaMapping_Field_Name))[-2]
                    SWC_DataMapping_FileNames = DtatMapping_Dict[DaTaMapping_Ref_Name]
                    for SWC_FileName in SWC_DataMapping_FileNames:
                        SWC_Name = SWC_FileName.split(".arxml")[0]
                        #在当前SWC下添加DataMapping
                        DataMapping_SWC_SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, SWC_FileName))
                        #产看SWC文件是否含有DataTypeMappings
                        if Feature.contain_package(DataMapping_SWC_SWC_AUTOSAR, "DataTypeMappings"):
                            #获得对应SWC下DataTypeMappings的datatype的列表
                            DataTypeMappings_List = GetList.Get_DataTypeMappingsList(DataMapping_SWC_SWC_AUTOSAR,DaTaMapping_Ref_Name)
                            if Data_Tpye_Dict["Data_Type"] in DataTypeMappings_List:
                                Delete_Element.Delete_DataTypeMappings_DataType(DataMapping_SWC_SWC_AUTOSAR, Data_Tpye_Dict["Data_Type"],DaTaMapping_Ref_Name)
                                element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                            else:
                                element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        else:
                            element = Generate_Element.Process_DataTypeMappings_Top()
                            Add_Element.Add_DataTypeMappings_Top_Element(DataMapping_SWC_SWC_AUTOSAR, element)
                            element = Generate_Element.Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)       
                        ET.indent(DataMapping_SWC_SWC_AUTOSAR)
                        Feature.save_file(DataMapping_SWC_SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))        
    
    # 处理数组类型
    for Array_Dict in Array_Dict_List:
        
        array_name = "rt_Array_{}_{}".format(Array_Dict["Data_Type"], str(Array_Dict["Size"]))
        # print("Array_Dict",Array_Dict,"array_name", array_name)
        Add_Data_type_List.append(array_name)
        if "{}.arxml".format(Array_Dict["SWC"]) not in SWC_List:
            print("缺少SWC文件2","{}.arxml".format(Array_Dict["SWC"]))
        else:
            if array_name in ImplementationDataTypes_Data_type_List or array_name in Add_Data_type_List:
                if array_name in DataTypeImplementation_Data_type_List:
                    Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, array_name)
                    element = Generate_Element.Process_ImplementationDataTypes_Array(Array_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                    Add_Element.Add_DataTypeImplementation_Element(Common_AUTOSAR, element)
                else:
                    Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, array_name)
                    element = Generate_Element.Process_ImplementationDataTypes_Array(Array_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                    Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
            else:
                element = Generate_Element.Process_ImplementationDataTypes_Array(Array_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
            #SDB的ApplicationDataTypes是否含有该datatype
            if array_name in ApplicationDataTypes_Data_type_List:
                #解析对应的SWC文件
                SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Array_Dict["SWC"])))
                #获得当前SWC引用哪个SWC的DATa mapping
                DaTaMapping_Ref_Name = GetList.Get_SWC_DataMapping_Ref(SWC_AUTOSAR)
                SWC_FileName = DtatMapping_Dict[DaTaMapping_Ref_Name]
                SWC_Name = SWC_FileName.split(".arxml")[0]
                #在当前SWC下添加DataMapping
                DataMapping_SWC_SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, SWC_FileName))
                #产看SWC文件是否含有DataTypeMappings
                if Feature.contain_package(DataMapping_SWC_SWC_AUTOSAR, "DataTypeMappings"):
                    #获得对应SWC下DataTypeMappings的datatype的列表
                    DataTypeMappings_List = GetList.Get_DataTypeMappingsList(DataMapping_SWC_SWC_AUTOSAR,DaTaMapping_Ref_Name)
                    if Array_Dict["Data_Type"] in DataTypeMappings_List:
                        Delete_Element.Delete_DataTypeMappings_DataType(DataMapping_SWC_SWC_AUTOSAR, array_name ,DaTaMapping_Ref_Name)
                        element = Generate_Element.Process_DataTypeMappings_Array(array_name, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                        Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                    else:
                        element = Generate_Element.Process_DataTypeMappings_Array(array_name, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                        Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                else:
                    element = Generate_Element.Process_DataTypeMappings_Top()
                    Add_Element.Add_DataTypeMappings_Top_Element(DataMapping_SWC_SWC_AUTOSAR, element)
                    element = Generate_Element.Process_DataTypeMappings_Array(array_name, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                    Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name) 
                ET.indent(DataMapping_SWC_SWC_AUTOSAR)
                Feature.save_file(DataMapping_SWC_SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))

            
    #删除common中在SDB中已存在的接口
    for portinface in PortInterfaces_List:
        if portinface in SDB_PortInterfaces_List:
            Delete_Element.Delete_PortInterfaces_port(Common_AUTOSAR,portinface)
            
    #删除需要删除的接口和内部行为
    for swc in Receiver_Port_Delete_Dict:
        Delete_Receiver_Ports = {}
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(swc)))
        
        runnable_name = GetList.Get_SWC_Receive_Runnable_Entity(SWC_AUTOSAR)
        Delete_Receiver_Ports = Delete_Element.Search_variable_access_Receiver_port(SWC_AUTOSAR, swc,runnable_name)
        # print("Delete_Receiver_Ports_list",Delete_Receiver_Ports)
        for port in Receiver_Port_Delete_Dict[swc]:
            # print("port",port["Port"])
            if port["Port"] in Delete_Receiver_Ports and port["Element"]in Delete_Receiver_Ports[port["Port"]]:
                print("Delete_Receiver_Ports_access",Delete_Receiver_Ports[port["Port"]])
                Delete_Element.Delete_SwComponentType_variable_access_Receiver_port(SWC_AUTOSAR, swc,port["Port"],port["Element"],runnable_name)
                        
                Delete_Receiver_Ports[port["Port"]].remove(port["Element"])
                if len(Delete_Receiver_Ports[port["Port"]]) == 0:
                    print("Delete_Receiver_Ports",port["Port"])
                    Delete_Element.Delete_SwComponentType_Receiver_port(SWC_AUTOSAR,swc,port["Port"])

        ET.indent(SWC_AUTOSAR)
        Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(swc))) 
    
    for Value_Interface in Value_Interface_List:
        found = False
        if Value_Interface not in SDB_PortInterfaces_List:
            if Value_Interface not in Common_CarCfg_SHORT_NAME_List:
                for Receiver_Port_Dict in Receiver_Port_Dict_List:
                    for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
                        if Receiver_Port["Interface"] == Value_Interface:
                            element = Generate_Element.Process_especially_PortInterfaces(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
                            Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
                            element = Generate_Element.Process_Common_CarCfg_Element(Receiver_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Receiver_Port)
                            Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Receiver_Port["Interface"])
                            Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                            ET.indent(Common_AUTOSAR)
                            Feature.save_file(Common_AUTOSAR, common_arxml_path)
                            Common_AUTOSAR = Feature.parse_file(common_arxml_path)
                            found = True
                            break
                        if found:  
                            break 

    
    #接口创建,接受接口
    for Receiver_Port_Dict in Receiver_Port_Dict_List:
        #解析对应的SWC文件
        print("path",os.path.join(geelycem_swc_dir, "{}.arxml".format(Receiver_Port_Dict["SWC"])))
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Receiver_Port_Dict["SWC"])))
        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
            #如果SDB中已经有接口了，那么在common中不需要创建
            if Receiver_Port["Data_Access_Mode"] != "IsUpdated":
                if Receiver_Port["Interface"] not in SDB_PortInterfaces_List:
                    # print("Receiver_Port", Receiver_Port,Receiver_Port_Dict["SWC"],element_Invaladation)
                    # 判断数组中所有元素是否与变量相同  
                    if any(item == Receiver_Port["Interface"] for item in Value_Interface_List):  
                    # if Receiver_Port["Interface"] == "CarCfg":
                            
                            # print("Common_CarCfg_List",Common_CarCfg_List)
                            if Receiver_Port["Element"] in Common_CarCfg_List or Receiver_Port["Element"] in Add_Port_List:
                                Delete_Element.Delete_Common_CarCfg_Element(Common_AUTOSAR,Receiver_Port)
                                Delete_Element.Delete_Common_CarCfg_invalidation_Element(Common_AUTOSAR,Receiver_Port)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Receiver_Port)
                                element = Generate_Element.Process_Common_CarCfg_Element(Receiver_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Receiver_Port["Interface"])
                                # print("Receiver_Port", Receiver_Port,Receiver_Port_Dict["SWC"],element_Invaladation)
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                            else:
                                Add_Port_List.append(Receiver_Port["Element"])
                                element = Generate_Element.Process_Common_CarCfg_Element(Receiver_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Receiver_Port)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Receiver_Port["Interface"])
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                    # 当前Interface是否有对应的Data Type, 或者 Interface 的 Data Type 不等于 当前 Interface 的 Data Type
                    # if Receiver_Port["Interface"] not in Port_Dict_Data_Type or Port_Dict_Data_Type[Receiver_Port["Interface"]] != Receiver_Port["Data_Type"]or Port_Dict_Data_Type[Receiver_Port["Interface"]] != Receiver_Port["Data_Type"]:
                    if Receiver_Port["Interface"] not in Port_Dict_Data_Type or Port_Dict_DataElement[Receiver_Port["Interface"]] != Receiver_Port["Element"] or Port_Dict_Data_Type[Receiver_Port["Interface"]] != Receiver_Port["Data_Type"]:
                        if any(item == Receiver_Port["Interface"] for item in Value_Interface_List):
                        # if Receiver_Port["Interface"] == "CarCfg":
                            
                            if Receiver_Port["Element"] in Common_CarCfg_List or Receiver_Port["Element"] in Add_Port_List:     
                                Delete_Element.Delete_Common_CarCfg_Element(Common_AUTOSAR,Receiver_Port)
                                Delete_Element.Delete_Common_CarCfg_invalidation_Element(Common_AUTOSAR,Receiver_Port)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Receiver_Port)
                                element = Generate_Element.Process_Common_CarCfg_Element(Receiver_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Receiver_Port["Interface"])
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                            else:
                                Add_Port_List.append(Receiver_Port["Element"])
                                element = Generate_Element.Process_Common_CarCfg_Element(Receiver_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Receiver_Port)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Receiver_Port["Interface"])
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                        else:
                            
                                       
                            if Receiver_Port["Interface"] in PortInterfaces_List or Receiver_Port["Interface"] in Add_Port_List:
                                # print("Delete_PortInterfaces_port",Receiver_Port["Interface"])
                                Delete_Element.Delete_PortInterfaces_port(Common_AUTOSAR,Receiver_Port["Interface"])
                                element = Generate_Element.Process_PortInterfaces(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
                            else:
                                Add_Port_List.append(Receiver_Port["Interface"])
                                element = Generate_Element.Process_PortInterfaces(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
                    
        # ET.indent(SWC_AUTOSAR)
        # Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Receiver_Port_Dict["SWC"])))
        #删除SWC中，SDB已经创建过的接口
        # SwComponentType_Portinterfaces_List = GetList.Get_PortInterfacesList(SWC_AUTOSAR)
        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
            if Receiver_Port["Interface"] in SDB_PortInterfaces_List:
                Delete_Element.Delete_PortInterfaces_port(SWC_AUTOSAR,Receiver_Port["Interface"])
        #创建端口
        
        Port_Dict = GetList.Get_Common_type_ref(Common_AUTOSAR)
        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
            if Receiver_Port["Data_Access_Mode"] == "IsUpdated":
                print("IsUpdated",SWC_AUTOSAR,Receiver_Port["Receiver_Port"])
                Generate_Element.Set_Enable_Update_Value_Receiver(SWC_AUTOSAR,Receiver_Port["Receiver_Port"])
            else:
                SwComponentType_Receiver_Port_List = GetList.Get_SwComponentType_Receiver_Port_List(SWC_AUTOSAR)
                if Receiver_Port["Receiver_Port"] in SwComponentType_Receiver_Port_List:
                    if any(item == Receiver_Port["Receiver_Port"] for item in Value_Interface_List):
                    # if Receiver_Port["Receiver_Port"] == "rCarcfg" or Receiver_Port["Receiver_Port"] == "CarCfg":
                        # print("Delete_Port",SWC_AUTOSAR,Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
                        print("Create_Port1",Receiver_Port["Receiver_Port"])
                        Delete_Element.Delete_SwComponentType_Receiver_port(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], Receiver_Port["Receiver_Port"])
                        element = Generate_Element.Process_SwComponentType_Receiveport_CarCfg(Receiver_Port)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], element)
                    else:
                        print("Create_Port2",Receiver_Port["Receiver_Port"])
                        # print("Delete_Port1",SWC_AUTOSAR,Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
                        Delete_Element.Delete_SwComponentType_Receiver_port(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], Receiver_Port["Receiver_Port"])
                        element = Generate_Element.Process_SwComponentType_Receiveport(Receiver_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], element)
                else:
                    # print("Create_Port",Receiver_Port["Receiver_Port"])
                    if any(item == Receiver_Port["Receiver_Port"] for item in Value_Interface_List):
                    # if Receiver_Port["Receiver_Port"] == "rCarcfg" or Receiver_Port["Receiver_Port"] == "CarCfg":
                        print("Create_Port3",Receiver_Port["Receiver_Port"])
                        element = Generate_Element.Process_SwComponentType_Receiveport_CarCfg(Receiver_Port)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], element)
                    else:
                        print("Create_Port4",Receiver_Port["Receiver_Port"])
                        element = Generate_Element.Process_SwComponentType_Receiveport(Receiver_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"], element)
        
        # ET.indent(SWC_AUTOSAR)
        # Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Receiver_Port_Dict["SWC"])))
        #内部行为
        #获取SWC下内部行为VARIABLE-ACCESS的内容


        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
            if Receiver_Port["Data_Access_Mode"] == "IsUpdated":
                continue
            else:
                #获取SWC下内部行为VARIABLE-ACCESS的内容
                print("Receiver_Port",Receiver_Port["Receiver_Port"])
                runnable_name = GetList.Get_SWC_Receive_Runnable_Entity(SWC_AUTOSAR)
                # print("runnable_name",runnable_name)
                SwComponentType_variable_access_List = GetList.Get_SwComponentType_variable_access_Receiver_Port_List(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],runnable_name)
                if any(item == Receiver_Port["Interface"] for item in Value_Interface_List):
                    print("Create_Port55",Receiver_Port["Receiver_Port"],Receiver_Port["Element"])

                    if Receiver_Port["Receiver_Port"] + "_" + Receiver_Port["Element"] in SwComponentType_variable_access_List:
                        Delete_Element.Delete_SwComponentType_variable_access_Receiver_port(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"] ,Receiver_Port["Element"],runnable_name)
                        element = Generate_Element.Process_SwComponentType_Variable_Access_Receiver_Port_CarCfg(Receiver_Port, Receiver_Port_Dict["SWC"])
                        Add_Element.Add_SwComponentType_Variable_Access_Receiver_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],element,runnable_name,Receiver_Port["Data_Access_Mode"])
                    else:
                        element = Generate_Element.Process_SwComponentType_Variable_Access_Receiver_Port_CarCfg(Receiver_Port, Receiver_Port_Dict["SWC"])
                        Add_Element.Add_SwComponentType_Variable_Access_Receiver_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],element,runnable_name,Receiver_Port["Data_Access_Mode"])
                else:
                    # print("Create_Port5",Receiver_Port["Receiver_Port"])
                    # print("Create_Port6",Receiver_Port["Element"])
                    print("Create_Port6",Receiver_Port["Receiver_Port"],Receiver_Port["Element"])

                    if Receiver_Port["Receiver_Port"] + "_" + Receiver_Port["Element"] in SwComponentType_variable_access_List:
                        print("Create_Port7",Receiver_Port["Receiver_Port"],Receiver_Port["Element"])

                        Delete_Element.Delete_SwComponentType_variable_access_Receiver_port(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"], Receiver_Port["Element"],runnable_name)
                        element = Generate_Element.Process_SwComponentType_Variable_Access_Receiver_Port(Receiver_Port, Receiver_Port_Dict["SWC"])
                        Add_Element.Add_SwComponentType_Variable_Access_Receiver_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],element,runnable_name,Receiver_Port["Data_Access_Mode"])
                    else:
                        print("Create_Port8",Receiver_Port["Receiver_Port"],Receiver_Port["Element"])
                        element = Generate_Element.Process_SwComponentType_Variable_Access_Receiver_Port(Receiver_Port, Receiver_Port_Dict["SWC"])
                        Add_Element.Add_SwComponentType_Variable_Access_Receiver_Port_Element(SWC_AUTOSAR, Receiver_Port_Dict["SWC"],element,runnable_name,Receiver_Port["Data_Access_Mode"])

        ET.indent(SWC_AUTOSAR)
        # print("save_file", os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Receiver_Port_Dict["SWC"])))
        Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(Receiver_Port_Dict["SWC"])))




        #接口涉及的数据类型进行映射
        for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
            SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Receiver_Port_Dict["SWC"])))
            if Receiver_Port["Data_Access_Mode"] != "IsUpdated":
                if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
                    #获得当前SWC引用哪个SWC的DATa mapping
                    DaTaMapping_Ref_Field_Name = GetList.Get_SWC_DataMapping_Ref(SWC_AUTOSAR)
                    DaTaMapping_Field_Name = DaTaMapping_Ref_Field_Name.split("_")[-1]
                    DaTaMapping_Ref_Name = DaTaMapping_Ref_Field_Name.split("_{}".format(DaTaMapping_Field_Name))[-2]
                    SWC_DataMapping_FileNames = DtatMapping_Dict[DaTaMapping_Ref_Name]
                    for SWC_FileName in SWC_DataMapping_FileNames:
                        SWC_Name = SWC_FileName.split(".arxml")[0]
                        #在当前SWC下添加DataMapping
                        DataMapping_SWC_SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, SWC_FileName))
                        #产看SWC文件是否含有DataTypeMappings
                        if Feature.contain_package(DataMapping_SWC_SWC_AUTOSAR, "DataTypeMappings"):
                            #获得对应SWC下DataTypeMappings的datatype的列表
                            DataTypeMappings_List = GetList.Get_DataTypeMappingsList(DataMapping_SWC_SWC_AUTOSAR,DaTaMapping_Ref_Name)
                            if Receiver_Port["Data_Type"] not in DataTypeMappings_List:
                                element = Generate_Element.Process_DataTypeMappings(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        else:
                            element = Generate_Element.Process_DataTypeMappings_Top()
                            Add_Element.Add_DataTypeMappings_Top_Element(DataMapping_SWC_SWC_AUTOSAR, element)
                            element = Generate_Element.Process_DataTypeMappings(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        ET.indent(DataMapping_SWC_SWC_AUTOSAR)
                        Feature.save_file(DataMapping_SWC_SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))


    # for Value_Interface in Value_Interface_List:
    #     found = False
    #     # print("Value_Interface",Value_Interface)
    #     # print("Common_CarCfg_List", Common_CarCfg_SHORT_NAME_List)
    #     if Value_Interface not in Common_CarCfg_SHORT_NAME_List:
    #         for Sender_Port_Dict in Sender_Port_Dict_List:
    #             for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
    #                 if Sender_Port["Interface"] == Value_Interface:
    #                     print("Value_Interface",Value_Interface)
    #                     element = Generate_Element.Process_especially_PortInterfaces_Sender_Port(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List)
    #                     Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
    #                     ET.indent(Common_AUTOSAR)
    #                     Feature.save_file(Common_AUTOSAR, os.path.join(geely_zcu_path,geely_cem_path, "Common.arxml"))
    #                     Common_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path,geely_cem_path,"Common.arxml"))
    #                     found = True
    #                     break
    #                 if found:  
    #                     break 

    
    #删除需要删除的发送接口和内部行为  
    for swc in Sender_Port_Delete_Dict:
        Delete_Sender_Ports = {}
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(swc)))
        runnable_name = GetList.Get_SWC_Sender_Runnable_Entity(SWC_AUTOSAR)
        Delete_Sender_Ports = Delete_Element.Search_variable_access_Sender_port(SWC_AUTOSAR, swc,runnable_name)
        for port in Sender_Port_Delete_Dict[swc]:
            if port["Port"] in Delete_Sender_Ports and port["Element"]in Delete_Sender_Ports[port["Port"]]:
                Delete_Element.Delete_SwComponentType_variable_access_Sender_port(SWC_AUTOSAR, swc,port["Port"],port["Element"],runnable_name)
            
            
                Delete_Sender_Ports[port["Port"]].remove(port["Element"])
                if len(Delete_Sender_Ports[port["Port"]]) == 0:
                    print("Delete_Sender_port",port["Port"])
                    Delete_Element.Delete_SwComponentType_Sender_port(SWC_AUTOSAR,swc,port["Port"])
                

        ET.indent(SWC_AUTOSAR)
        Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(swc))) 
    for Value_Interface in Value_Interface_List:
        found = False
        if Value_Interface not in SDB_PortInterfaces_List:
            if Value_Interface not in Common_CarCfg_SHORT_NAME_List:
                for Sender_Port_Dict in Sender_Port_Dict_List:
                    for Sender_Port in Sender_Port_Dict['Sender_Port_List']:
                        if Sender_Port["Interface"] == Value_Interface:
                            element = Generate_Element.Process_especially_PortInterfaces(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
                            element = Generate_Element.Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Sender_Port)
                            Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Sender_Port["Interface"])
                            Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)

                            ET.indent(Common_AUTOSAR)
                            Feature.save_file(Common_AUTOSAR, common_arxml_path)
                            Common_AUTOSAR = Feature.parse_file(common_arxml_path)
                            found = True
                            break
                        if found:  
                            break 



    #发送接口
    for Sender_Port_Dict in Sender_Port_Dict_List:
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Sender_Port_Dict["SWC"])))
        # print("SWC_AUTOSAR",SWC_AUTOSAR)
        #在common中创建接口
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            if Sender_Port["Data_Access_Mode"] != "IsUpdated":
                
                if Sender_Port["Interface"] not in SDB_PortInterfaces_List:
                #处理CarCfg接口
                    
                    if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
                    # if Sender_Port["Interface"] == "CarCfg":
                            # print("send_interface1",Sender_Port["Interface"])
                            if Sender_Port["Element"] in Common_CarCfg_List or Sender_Port["Element"] in Add_Port_List:
                                Delete_Element.Delete_Common_CarCfg_Element(Common_AUTOSAR,Sender_Port)
                                Delete_Element.Delete_Common_CarCfg_invalidation_Element(Common_AUTOSAR,Sender_Port)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Sender_Port)
                                element = Generate_Element.Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Sender_Port["Interface"])
                            else:
                                # print("send_interface2",Sender_Port["Interface"])
                                Add_Port_List.append(Sender_Port["Element"])
                                element = Generate_Element.Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Sender_Port)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Sender_Port["Interface"])
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                    # if Sender_Port["Interface"] not in Port_Dict_Data_Type or Port_Dict_Data_Type[Sender_Port["Interface"]] != Sender_Port["Data_Type"]:
                    if Sender_Port["Interface"] not in Port_Dict_Data_Type or Port_Dict_DataElement[Sender_Port["Interface"]] != Sender_Port["Element"] or Port_Dict_Data_Type[Sender_Port["Interface"]] != Sender_Port["Data_Type"]:
                        
                        # if Sender_Port["Interface"] == "CarCfg":
                        if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
                            
                            if Sender_Port["Element"] in Common_CarCfg_List or Sender_Port["Element"] in Add_Port_List:
                                # print("send_interface3",Sender_Port["Interface"])
                                Delete_Element.Delete_Common_CarCfg_Element(Common_AUTOSAR,Sender_Port)
                                Delete_Element.Delete_Common_CarCfg_invalidation_Element(Common_AUTOSAR,Sender_Port)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Sender_Port)
                                element = Generate_Element.Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Sender_Port["Interface"])
                            else:
                                # print("send_interface4",Sender_Port["Interface"])
                                Add_Port_List.append(Sender_Port["Element"])
                                element = Generate_Element.Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                element_Invaladation = Generate_Element.Process_Common_CarCfg_Invaladation_Element(Sender_Port)
                                Add_Element.Add_Common_CarCfg_Element(Common_AUTOSAR,element,Sender_Port["Interface"])
                                Add_Element.Add_Common_CarCfg_invalidation_Element(Common_AUTOSAR,element_Invaladation)
                        else:
                            
                            if Sender_Port["Interface"] in PortInterfaces_List or Sender_Port["Interface"] in Add_Port_List:
                                # print("send_interface5",Sender_Port["Interface"])
                                Delete_Element.Delete_PortInterfaces_port(Common_AUTOSAR,Sender_Port["Interface"])
                                element = Generate_Element.Process_PortInterfaces_Sender_Port(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
                            else:
                                # print("send_interface6",Sender_Port["Interface"])
                                Add_Port_List.append(Sender_Port["Interface"])
                                element = Generate_Element.Process_PortInterfaces_Sender_Port(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
        # ET.indent(SWC_AUTOSAR)
        # Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Sender_Port_Dict["SWC"])))    
        #删除SWC中，SDB已经创建过的接口   
        # SwComponentType_Portinterfaces_List = GetList.Get_PortInterfacesList(SWC_AUTOSAR)  
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            if Sender_Port["Interface"] in SDB_PortInterfaces_List:
                Delete_Element.Delete_PortInterfaces_port(SWC_AUTOSAR,Sender_Port["Interface"])

        #获得common下接口的引用数据类型
        Port_Dict = GetList.Get_Common_type_ref(Common_AUTOSAR)
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            if Sender_Port["Data_Access_Mode"] == "IsUpdated":
                print("Sender_Port_IsUpdata",Sender_Port["Interface"])
                Generate_Element.Set_Enable_Update_Value_Sender(SWC_AUTOSAR,Sender_Port["Interface"])
            else:
                #在swc中创建端口
                SwComponentType_Sender_Port_List = GetList.Get_SwComponentType_Sender_Port_List(SWC_AUTOSAR)
                if Sender_Port["Sender_Port"] in SwComponentType_Sender_Port_List:
                    if any(item == Sender_Port["Sender_Port"] for item in Value_Interface_List):
                    # if Sender_Port["Sender_Port"] == "CarCfg" or Sender_Port["Sender_Port"] == "rCarCfg":
                        print("Sender_Port1",Sender_Port["Sender_Port"])
                        Delete_Element.Delete_SwComponentType_Sender_port(SWC_AUTOSAR,Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"])
                        element = Generate_Element.Process_SwComponentType_Sendport_CarCfg(Sender_Port)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR,Sender_Port_Dict["SWC"],element)
                    else:
                        print("Sender_Port2",Sender_Port["Sender_Port"])
                        Delete_Element.Delete_SwComponentType_Sender_port(SWC_AUTOSAR,Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"])
                        element = Generate_Element.Process_SwComponentType_Sendport(Sender_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR,Sender_Port_Dict["SWC"],element)
                else:
                    if any(item == Sender_Port["Sender_Port"] for item in Value_Interface_List):
                        print("Sender_Port3",Sender_Port["Sender_Port"])
                        element = Generate_Element.Process_SwComponentType_Sendport_CarCfg(Sender_Port)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR,Sender_Port_Dict["SWC"],element)
                    else:
                        print("sender_port4",Sender_Port["Sender_Port"])
                        element = Generate_Element.Process_SwComponentType_Sendport(Sender_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
                        Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR,Sender_Port_Dict["SWC"],element)
        # ET.indent(SWC_AUTOSAR)
        # Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Sender_Port_Dict["SWC"]))) 
        # #处理内部行为    
        # 
        # 
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            runnable_name = GetList.Get_SWC_Sender_Runnable_Entity(SWC_AUTOSAR)
            # print("runnable_name", runnable_name,Sender_Port_Dict["SWC"])
            SwComponentType_variable_access_Sender_Port_List = GetList.Get_SwComponentType_variable_access_Sender_Port_List(SWC_AUTOSAR, Sender_Port_Dict["SWC"],runnable_name)
            # print("SwComponentType_variable_access_List", Sender_Port_Dict["SWC"], SwComponentType_variable_access_Sender_Port_List)
            if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
                if Sender_Port["Sender_Port"]  + "_" +  Sender_Port["Element"] in SwComponentType_variable_access_Sender_Port_List:
                    Delete_Element.Delete_SwComponentType_variable_access_Sender_port(SWC_AUTOSAR, Sender_Port_Dict["SWC"], Sender_Port["Sender_Port"], Sender_Port["Element"],runnable_name)
                    element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port_CarCfg(Sender_Port, Sender_Port_Dict["SWC"])
                    Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name,Sender_Port["Data_Access_Mode"])
                else:
                    element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port_CarCfg(Sender_Port, Sender_Port_Dict["SWC"])
                    Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name,Sender_Port["Data_Access_Mode"])
            else:
                # print("SwComponentType_variable_access_List", SwComponentType_variable_access_Sender_Port_List)
                if Sender_Port["Sender_Port"]  + "_" + Sender_Port["Element"] in SwComponentType_variable_access_Sender_Port_List:
                    print("Sender_Port6", Sender_Port["Sender_Port"])
                    print("Sender_Port6", Sender_Port["Element"])
                    Delete_Element.Delete_SwComponentType_variable_access_Sender_port(SWC_AUTOSAR, Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"], Sender_Port["Element"],runnable_name)
                    element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port(Sender_Port, Sender_Port_Dict["SWC"])
                    Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name,Sender_Port["Data_Access_Mode"])
                else:
                    element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port(Sender_Port,Sender_Port_Dict["SWC"])
                    Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name,Sender_Port["Data_Access_Mode"])


        # for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
        #     runnable_name = GetList.Get_SWC_Runnable_Entity(SWC_AUTOSAR)
        #     SwComponentType_variable_access_Sender_Port_List = GetList.Get_SwComponentType_variable_access_Sender_Port_List(SWC_AUTOSAR, Sender_Port_Dict["SWC"],runnable_name)
        #     if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
        #         if Sender_Port["Element"] in SwComponentType_variable_access_Sender_Port_List:
        #             print("Value_delete Sender_Port",Sender_Port["Interface"])  
        #             Delete_Element.Delete_SwComponentType_variable_access_Sender_port(SWC_AUTOSAR, Sender_Port_Dict["SWC"], Sender_Port["Sender_Port"], Sender_Port["Element"],runnable_name)
        #             element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port_CarCfg(Sender_Port, Sender_Port_Dict["SWC"])
        #             Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name)
        #         else:
        #             print("Value_Sender_Port",Sender_Port["Interface"])
        #             element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port_CarCfg(Sender_Port, Sender_Port_Dict["SWC"])
        #             Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name)
        #     else:
        #         if Sender_Port["Interface"] in SwComponentType_variable_access_Sender_Port_List: 
        #             print("delete Sender_Port",Sender_Port["Interface"])                   
        #             Delete_Element.Delete_SwComponentType_variable_access_Sender_port(SWC_AUTOSAR, Sender_Port_Dict["SWC"], Sender_Port["Sender_Port"],Sender_Port["Interface"],runnable_name)
        #             element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port(Sender_Port, Sender_Port_Dict["SWC"])
        #             Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name)
        #         else:
        #             print("Sender_Port",Sender_Port["Interface"])  
        #             element = Generate_Element.Process_SwComponentType_Variable_Access_Sender_Port(Sender_Port,Sender_Port_Dict["SWC"])
        #             Add_Element.Add_SwComponentType_Variable_Access_Sender_Port_Element(SWC_AUTOSAR, Sender_Port_Dict["SWC"],element,runnable_name)


        ET.indent(SWC_AUTOSAR)
        # print(type(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Sender_Port_Dict["SWC"]))))
        Feature.save_file(SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(Sender_Port_Dict["SWC"]))) 






#接口涉及的数据类型进行映射        
        for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:
            SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(Sender_Port_Dict["SWC"])))
            if Sender_Port["Data_Access_Mode"] != "IsUpdated":
                if Sender_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
                    #获得当前SWC引用哪个SWC的DATa mapping
                    DaTaMapping_Ref_Field_Name = GetList.Get_SWC_DataMapping_Ref(SWC_AUTOSAR)
                    DaTaMapping_Field_Name = DaTaMapping_Ref_Field_Name.split("_")[-1]
                    DaTaMapping_Ref_Name = DaTaMapping_Ref_Field_Name.split("_{}".format(DaTaMapping_Field_Name))[-2]
                    SWC_DataMapping_FileNames = DtatMapping_Dict[DaTaMapping_Ref_Name]
                    for SWC_FileName in SWC_DataMapping_FileNames:
                        SWC_Name = SWC_FileName.split(".arxml")[0]
                        #在当前SWC下添加DataMapping
                        DataMapping_SWC_SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, SWC_FileName))
                        #产看SWC文件是否含有DataTypeMappings
                        if Feature.contain_package(DataMapping_SWC_SWC_AUTOSAR, "DataTypeMappings"):
                            #获得对应SWC下DataTypeMappings的datatype的列表
                            DataTypeMappings_List = GetList.Get_DataTypeMappingsList(DataMapping_SWC_SWC_AUTOSAR,DaTaMapping_Ref_Name)
                            if Sender_Port["Data_Type"] not in DataTypeMappings_List:
                                element = Generate_Element.Process_DataTypeMappings(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                                Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        else:
                            element = Generate_Element.Process_DataTypeMappings_Top()
                            Add_Element.Add_DataTypeMappings_Top_Element(DataMapping_SWC_SWC_AUTOSAR, element)
                            element = Generate_Element.Process_DataTypeMappings(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList)
                            Add_Element.Add_DataTypeMappings_Element(DataMapping_SWC_SWC_AUTOSAR, element, DaTaMapping_Ref_Name)
                        ET.indent(DataMapping_SWC_SWC_AUTOSAR)
                        Feature.save_file(DataMapping_SWC_SWC_AUTOSAR, os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))     


    # #在geely_cem文件下添加数据接口
    # #接收接口
    # Port_Dict = GetList.Get_Common_type_ref(Common_AUTOSAR)
    # for Receiver_Port_Dict in Receiver_Port_Dict_List:
    #     for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
    #         if Receiver_Port["Sig_From"] == "Network" or Receiver_Port["Sig_From"] == "Basetech" or Receiver_Port["Sig_From"] == "SUP":
    #         # if Receiver_Port["Sig_From"] == "Network" :
    #             if Receiver_Port["Data_Access_Mode"] == "IsUpdated":
    #                 Generate_Element.Set_Enable_Update_Value_Receiver(Geely_AUTOSAR,Receiver_Port["Receiver_Port"])
    #             else:
    #                 if Receiver_Port["Receiver_Port"] in Geely_ReceiverPorts_List:
    #                     if any(item == Receiver_Port["Interface"] for item in Value_Interface_List):
    #                     # if Receiver_Port["Interface"] == "CarCfg":
    #                         Delete_Element.Delete_Geely_Receiver_port(Geely_AUTOSAR, Receiver_Port["Receiver_Port"])
    #                         element = Generate_Element.Process_SwComponentType_Receiveport_CarCfg(Receiver_Port)
    #                         Add_Element.Add_Geely_ReceiverPort_Element(Geely_AUTOSAR, element)
    #                     else:
    #                         Delete_Element.Delete_Geely_Receiver_port(Geely_AUTOSAR, Receiver_Port["Receiver_Port"])
    #                         element = Generate_Element.Process_SwComponentType_Receiveport(Receiver_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
    #                         Add_Element.Add_Geely_ReceiverPort_Element(Geely_AUTOSAR, element)
    #                 else:
    #                     if any(item == Receiver_Port["Interface"] for item in Value_Interface_List):
    #                     # if Receiver_Port["Interface"] == "CarCfg":
    #                         element = Generate_Element.Process_SwComponentType_Receiveport_CarCfg(Receiver_Port)
    #                         Add_Element.Add_Geely_ReceiverPort_Element(Geely_AUTOSAR, element)
    #                     else:
    #                         element = Generate_Element.Process_SwComponentType_Receiveport(Receiver_Port, SDB_PortInterfaces_List, Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
    #                         Add_Element.Add_Geely_ReceiverPort_Element(Geely_AUTOSAR, element)
    #                     Geely_ReceiverPorts_List.append(Receiver_Port["Receiver_Port"])

    # # #发送接口
    # for Sender_Port_Dict in Sender_Port_Dict_List:
    #     for Sender_Port in Sender_Port_Dict["Sender_Port_List"]:            
    #         if Sender_Port["Sig_From"] == "Network" or Sender_Port["Sig_From"] == "Basetech" or Sender_Port["Sig_From"] == "SUP":
    #         # if Sender_Port["Sig_From"] == "Network" :
    #             if Sender_Port["Data_Access_Mode"] == "IsUpdated":
    #                 Generate_Element.Set_Enable_Update_Value_Sender(Geely_AUTOSAR,Sender_Port["Sender_Port"])
    #             else:
    #                 if Sender_Port["Sender_Port"] in Geely_SenderPorts_List:
    #                     if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
    #                     # if Sender_Port["Interface"] == "CarCfg":
    #                         Delete_Element.Delete_Geely_Sender_port(Geely_AUTOSAR,Sender_Port["Sender_Port"])
    #                         element = Generate_Element.Process_SwComponentType_Sendport_CarCfg(Sender_Port)
    #                         Add_Element.Add_Geely_SenderPort_Element(Geely_AUTOSAR,element)
    #                     else:
    #                         Delete_Element.Delete_Geely_Sender_port(Geely_AUTOSAR,Sender_Port["Sender_Port"])
    #                         element = Generate_Element.Process_SwComponentType_Sendport(Sender_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
    #                         Add_Element.Add_Geely_SenderPort_Element(Geely_AUTOSAR,element)
    #                 else:
    #                     if any(item == Sender_Port["Interface"] for item in Value_Interface_List):
    #                     # if Sender_Port["Interface"] == "CarCfg":
    #                         element = Generate_Element.Process_SwComponentType_Sendport_CarCfg(Sender_Port)
    #                         Add_Element.Add_Geely_SenderPort_Element(Geely_AUTOSAR,element)
    #                     else:
    #                         element = Generate_Element.Process_SwComponentType_Sendport(Sender_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict)
    #                         Add_Element.Add_Geely_SenderPort_Element(Geely_AUTOSAR,element)
    #                     Geely_SenderPorts_List.append(Sender_Port["Sender_Port"])
    if data["ECU_Name"] == "ZCU":
        pass
    else:
        # print("Geely_Delegation_connector_list", Geely_Delegation_connector_list)

    #     #接受接口连线
    #     for Receiver_Port_Dict in Receiver_Port_Dict_List:
    #         for Receiver_Port in Receiver_Port_Dict['Receiver_Port_List']:
    #             if Receiver_Port["Sig_From"] == "Network":
    #                 #获得SDB下PortInterfaces的接口列表
    #                 GeelyComponentType_SenderPorts_List = GetList.Get_PortInterfacesList(SDB_AUTOSAR)
    #                 # print("Receiver_Port",Receiver_Port["Receiver_Port"],Receiver_Port_Dict["SWC"],Receiver_Port["Interface"])
    #                 if Receiver_Port["Interface"] in GeelyComponentType_SenderPorts_List:
    #                     SDB_Receiver_Port = Receiver_Port["Interface"]
    #                 else:
    #                     SDB_Receiver_Port = Receiver_Port["Receiver_Port"]

    #                 port_line_name_geely = "dc_{}_its{}{}".format(Receiver_Port["Receiver_Port"],Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
    #                 # print("port_line_name_geely",port_line_name_geely)
    #                 port_line_name_sdb = "dc_{}_geely_cem{}".format(SDB_Receiver_Port,Receiver_Port["Receiver_Port"])
    #                 # print("port_line_name_sdb",port_line_name_sdb)
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Receiver_Port_Element(Receiver_Port,Receiver_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR ,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 if port_line_name_sdb not in SDB_Delegation_connector_list:
    #                     SDB_Delegation_connector_list.append(port_line_name_sdb)
    #                     element = Generate_Element.Process_SDB_Delegation_Receiver_Port_Element(SDB_Receiver_Port,Receiver_Port,data["ECU_Name"])
    #                     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                     Geely_Assembly_connector_list.append(port_line_name_sdb)
                    
    #             elif Receiver_Port["Sig_From"] == "Basetech":
    #                 Geelycem_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/basetech/basetech.arxml"))
    #                 GeelycemComponentType_Receiver_Port_List = GetList.Get_SwComponentType_Sender_Port_Interface_List(Geelycem_AUTOSAR)
    #                 SWC_Receiver_Port = Receiver_Port["Receiver_Port"]
    #                 for ComponentType_Sender_Port in GeelycemComponentType_Receiver_Port_List:  
    #                     if ComponentType_Sender_Port['interface_name'] == Receiver_Port["Interface"]:  
    #                         SWC_Receiver_Port = ComponentType_Sender_Port['short_name']
    #                         break                   
    #                 port_line_name_geely = "dc_{}_its{}{}".format(Receiver_Port["Receiver_Port"],Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
    #                 port_line_name_sdb = "ac_basetech{}_geely_cem{}".format(SWC_Receiver_Port,Receiver_Port["Receiver_Port"])
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Receiver_Port_Element(Receiver_Port,Receiver_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 if port_line_name_sdb not in SDB_Assembly_connector_list:
    #                     SDB_Assembly_connector_list.append(port_line_name_sdb)
    #                     element = Generate_Element.Process_SDB_Assembly_Receiver_Port_Element(SWC_Receiver_Port,Receiver_Port,data["ECU_Name"])
    #                     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                     Geely_Assembly_connector_list.append(port_line_name_sdb)
    #             elif Receiver_Port["Sig_From"] == "SUP":
    #                 # Geelycem_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/basetech/basetech.arxml"))
    #                 # GeelycemComponentType_Receiver_Port_List = GetList.Get_SwComponentType_Sender_Port_Interface_List(Geelycem_AUTOSAR)
    #                 # SWC_Receiver_Port = Receiver_Port["Receiver_Port"]
    #                 # for ComponentType_Sender_Port in GeelycemComponentType_Receiver_Port_List:  
    #                 #     if ComponentType_Sender_Port['interface_name'] == Receiver_Port["Interface"]:  
    #                 #         SWC_Receiver_Port = ComponentType_Sender_Port['short_name']
    #                 #         break                   
    #                 port_line_name_geely = "dc_{}_its{}{}".format(Receiver_Port["Receiver_Port"],Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
    #                 # port_line_name_sdb = "ac_basetech{}_geely_cem{}".format(SWC_Receiver_Port,Receiver_Port["Receiver_Port"])
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Receiver_Port_Element(Receiver_Port,Receiver_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 # if port_line_name_sdb not in SDB_Assembly_connector_list:
    #                 #     SDB_Assembly_connector_list.append(port_line_name_sdb)
    #                 #     element = Generate_Element.Process_SDB_Assembly_Receiver_Port_Element(SWC_Receiver_Port,Receiver_Port,data["ECU_Name"])
    #                 #     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                 #     Geely_Assembly_connector_list.append(port_line_name_sdb)
    #             elif pd.isna(Receiver_Port["Sig_From"]):
    #                 print("no connector Receiver_Port", Receiver_Port["Receiver_Port"])
    #             else:
    #                 SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Receiver_Port["Sig_From"])))
    #                 SwComponentType_Receiver_Port_List = GetList.Get_SwComponentType_Sender_Port_Interface_List(SWC_AUTOSAR)
    #                 # print("SwComponentType_Sender_Port_List",SwComponentType_Receiver_Port_List)
    #                 # print("Receiver_Port",Receiver_Port["Receiver_Port"],Receiver_Port_Dict["SWC"],Receiver_Port["Interface"])
    #                 # if(Receiver_Port["Interface"] == "pTrSts" or Receiver_Port["Interface"] == "TrSts" ):     
    #                 #     print("port_name_sender",Receiver_Port["Interface"],Receiver_Port["Sig_From"],Receiver_Port_Dict["SWC"],SwComponentType_Receiver_Port_List) 


    #                 SWC_Receiver_Port = Receiver_Port["Receiver_Port"]
    #                 for SwComponentType_Receiver_Port in SwComponentType_Receiver_Port_List:  
    #                     if SwComponentType_Receiver_Port['interface_name'] == Receiver_Port["Interface"]:  
    #                         # print(Receiver_Port['short_name'])  
    #                         SWC_Receiver_Port = SwComponentType_Receiver_Port['short_name']
    #                         # print("SWC_Receiver_Port",SWC_Receiver_Port)
    #                         break
    #                 # if Receiver_Port["Interface"] in SwComponentType_Receiver_Port_List:
    #                 #     SWC_Receiver_Port = SwComponentType_Receiver_Port_List["short_name"]
    #                 # else:
    #                 #     SWC_Receiver_Port = Receiver_Port["Receiver_Port"]
                    
    #                 port_line_name = "ac_its{}{}_its{}{}".format(Receiver_Port["Sig_From"],SWC_Receiver_Port,Receiver_Port_Dict["SWC"],Receiver_Port["Receiver_Port"])
    #                 if port_line_name not in Geely_Assembly_connector_list:
    #                     Geely_Assembly_connector_list.append(port_line_name)
    #                     element = Generate_Element.Process_Geely_Assembly_Receiver_Port_Element(SWC_Receiver_Port,Receiver_Port,Receiver_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name)
    #     #发送接口连线
    #     for Sender_Port_Dict in Sender_Port_Dict_List:
    #         for Sender_Port in Sender_Port_Dict['Sender_Port_List']:
    #             if Sender_Port["Sig_From"] == "Network":
    #                 #获得geely_cem文件下接收接口的列表
    #                 GeelyComponentType_ReceiverPorts_List = GetList.Get_PortInterfacesList(SDB_AUTOSAR)
    #                 if Sender_Port["Interface"] in GeelyComponentType_ReceiverPorts_List:
    #                     SDB_Sender_Port = Sender_Port["Interface"]
    #                 else:
    #                     SDB_Sender_Port = Sender_Port["Sender_Port"]

    #                 port_line_name_geely = "dc_{}_its{}{}".format(Sender_Port["Sender_Port"],Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"])
    #                 port_line_name_sdb = "dc_{}_geely_cem{}".format(SDB_Sender_Port,Sender_Port["Sender_Port"])
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Sender_Port_Element(Sender_Port,Sender_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 if port_line_name_sdb not in SDB_Delegation_connector_list:
    #                     SDB_Delegation_connector_list.append(port_line_name_sdb)
    #                     element = Generate_Element.Process_SDB_Delegation_Sender_Port_Element(SDB_Sender_Port,Sender_Port,data["ECU_Name"])
    #                     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                     Geely_Assembly_connector_list.append(port_line_name_sdb)
    #             elif Sender_Port["Sig_From"] == "Basetech":
    #                 Geelycem_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/basetech/basetech.arxml"))
    #                 GeelycemComponentType_Sender_Port_List = GetList.Get_SwComponentType_Receiver_Port_Interface_List(Geelycem_AUTOSAR)
    #                 SWC_Sender_Port = Sender_Port["Sender_Port"]
    #                 for ComponentType_Sender_Port in GeelycemComponentType_Sender_Port_List:  
    #                     if ComponentType_Sender_Port['interface_name'] == Sender_Port["Interface"]:  
    #                         # print(Receiver_Port['short_name'])  
    #                         SWC_Sender_Port = ComponentType_Sender_Port['short_name']
    #                         break
    #                 port_line_name_geely = "dc_{}_its{}{}".format(Sender_Port["Sender_Port"],Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"])
    #                 port_line_name_sdb = "ac_geely_cem{}_basetech{}".format(Sender_Port["Sender_Port"],SWC_Sender_Port)
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Sender_Port_Element(Sender_Port,Sender_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 if port_line_name_sdb not in SDB_Assembly_connector_list:
    #                     SDB_Assembly_connector_list.append(port_line_name_sdb)
    #                     element = Generate_Element.Process_SDB_Assembly_Sender_Port_Element(SWC_Sender_Port,Sender_Port,data["ECU_Name"])
    #                     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                     Geely_Assembly_connector_list.append(port_line_name_sdb)
    #             elif Sender_Port["Sig_From"] == "SUP":
    #                 # Geelycem_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/basetech/basetech.arxml"))
    #                 # GeelycemComponentType_Sender_Port_List = GetList.Get_SwComponentType_Receiver_Port_Interface_List(Geelycem_AUTOSAR)
    #                 # SWC_Sender_Port = Sender_Port["Sender_Port"]
    #                 # for ComponentType_Sender_Port in GeelycemComponentType_Sender_Port_List:  
    #                 #     if ComponentType_Sender_Port['interface_name'] == Sender_Port["Interface"]:  
    #                 #         # print(Receiver_Port['short_name'])  
    #                 #         SWC_Sender_Port = ComponentType_Sender_Port['short_name']
    #                 #         break
    #                 port_line_name_geely = "dc_{}_its{}{}".format(Sender_Port["Sender_Port"],Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"])
    #                 # port_line_name_sdb = "ac_geely_cem{}_basetech{}".format(Sender_Port["Sender_Port"],SWC_Sender_Port)
    #                 if port_line_name_geely not in Geely_Delegation_connector_list:
    #                     Geely_Delegation_connector_list.append(port_line_name_geely)
    #                     element = Generate_Element.Process_Geely_Delegation_Sender_Port_Element(Sender_Port,Sender_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name_geely)
    #                 # if port_line_name_sdb not in SDB_Assembly_connector_list:
    #                 #     SDB_Assembly_connector_list.append(port_line_name_sdb)
    #                 #     element = Generate_Element.Process_SDB_Assembly_Sender_Port_Element(SWC_Sender_Port,Sender_Port,data["ECU_Name"])
    #                 #     Add_Element.Add_SDB_sw_connector_element(SDB_AUTOSAR,element,data["ECU_Name"])
    #                 #     Geely_Assembly_connector_list.append(port_line_name_sdb)        
    #             elif pd.isna(Sender_Port["Sig_From"]):
    #                 print("no connector Sender_Port", Sender_Port["Sender_Port"])
    #             else:
    #                 # SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Sender_Port["Sig_From"])))

    #                 #在swc中创建端口
    #                 # SwComponentType_Sender_Port_List = GetList.Get_SwComponentType_Sender_Port_List(SWC_AUTOSAR)
    #                 # print("SwComponentType_Sender_Port_List",SwComponentType_Sender_Port_List)
    #                 # print("Sender_Port",Sender_Port["Sender_Port"],Sender_Port_Dict["SWC"])
    #                 # # if Sender_Port["Sender_Port"] in SwComponentType_Sender_Port_List:
    #                 # print("Sender_Port",Sender_Port["Sig_From"],Sender_Port["Interface"])
    #                 SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "{}.arxml".format(Sender_Port["Sig_From"])))

    #                 SwComponentType_Sender_Port_List = GetList.Get_SwComponentType_Receiver_Port_Interface_List(SWC_AUTOSAR)
    #                 SWC_Sender_Port = Sender_Port["Sender_Port"]
    #                 for SwComponentType_Sender_Port in SwComponentType_Sender_Port_List:  
    #                     if SwComponentType_Sender_Port['interface_name'] == Sender_Port["Interface"]:  
    #                         # print(Receiver_Port['short_name'])  
    #                         SWC_Sender_Port = SwComponentType_Sender_Port['short_name']
    #                         break
    #                 # if Sender_Port["Interface"] in SwComponentType_Sender_Port_List:
    #                 #     SWC_Sender_Port = Sender_Port["Interface"]
    #                 # else:
    #                 #     SWC_Sender_Port = Sender_Port["Sender_Port"]

    #                 port_line_name = "ac_its{}{}_its{}{}".format(Sender_Port_Dict["SWC"],Sender_Port["Sender_Port"],Sender_Port["Sig_From"],SWC_Sender_Port)
    #                 if port_line_name not in Geely_Assembly_connector_list:
    #                     Geely_Assembly_connector_list.append(port_line_name)
    #                     element = Generate_Element.Process_Geely_Assembly_Sender_Port_Element(SWC_Sender_Port,Sender_Port,Sender_Port_Dict["SWC"])
    #                     Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
    #                     Geely_Assembly_connector_list.append(port_line_name)   
        #删除多于连线
        #获得各个文件的端口列表
        # old_filename = ""
        # for filename in SWC_List:
        #     if filename.split('_')[-1] == "SleepRequestHandler.arxml":
        #         old_filename = filename
        #         os.rename(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", filename), os.path.join(geely_zcu_path, "workspace/geelycem/SWC", "SleepRequestHandler.arxml"))
        #         SWC_List = ["SleepRequestHandler.arxml" if x.endswith("SleepRequestHandler.arxml") else x for x in SWC_List]
        #         break
        # Swc_Filenames = os.listdir(os.path.join(geely_zcu_path, "workspace/geelycem/SWC"))
        SWC_port_Dict = {}

        for filename_path in swc_list_path:
            filename = os.path.basename(filename_path)
            SWC_AUTOSAR = Feature.parse_file(filename_path)
            SWC_Ports_List = []
            SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(SWC_AUTOSAR)
            SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(SWC_AUTOSAR)
            SWC_Ports_List.append(SWC_Receiverport_List)
            SWC_Ports_List.append(SWC_Senderport_List)
            SWC_port_Dict[filename] = SWC_Ports_List

        SWC_Ports_List = []
        SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Geely_AUTOSAR)
        SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Geely_AUTOSAR)
        SWC_Ports_List.append(SWC_Receiverport_List)
        SWC_Ports_List.append(SWC_Senderport_List)
        SWC_port_Dict["geely_cem.arxml"] = SWC_Ports_List

        if ZCU_type == "ZCUD": 
            SWC_Ports_List = []
            SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Chassis_AUTOSAR)
            SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Chassis_AUTOSAR)
            SWC_Ports_List.append(SWC_Receiverport_List)
            SWC_Ports_List.append(SWC_Senderport_List)
            SWC_port_Dict["chassis.arxml"] = SWC_Ports_List

            SWC_Ports_List = []
            SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(CDTMS_AUTOSAR)
            SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(CDTMS_AUTOSAR)
            SWC_Ports_List.append(SWC_Receiverport_List)
            SWC_Ports_List.append(SWC_Senderport_List)
            SWC_port_Dict["CDTMS.arxml"] = SWC_Ports_List

            SWC_Ports_List = []
            SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(HCM_AUTOSAR)
            SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(HCM_AUTOSAR)
            SWC_Ports_List.append(SWC_Receiverport_List)
            SWC_Ports_List.append(SWC_Senderport_List)
            SWC_port_Dict["HCM.arxml"] = SWC_Ports_List
            
        else: 
            pass
            # SWC_Ports_List = []
            # SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Irrm_AUTOSAR)
            # SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Irrm_AUTOSAR)
            # SWC_Ports_List.append(SWC_Receiverport_List)
            # SWC_Ports_List.append(SWC_Senderport_List)
            # SWC_port_Dict["irrm.arxml"] = SWC_Ports_List
        # SWC_Ports_List = []
        # SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Hcm_AUTOSAR)
        # SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Hcm_AUTOSAR)
        # SWC_Ports_List.append(SWC_Receiverport_List)
        # SWC_Ports_List.append(SWC_Senderport_List)
        # SWC_port_Dict[group_swc_name + ".arxml"] = SWC_Ports_List
    
        SWC_Ports_List = []
        SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Supplyc_AUTOSAR)
        SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Supplyc_AUTOSAR)
        SWC_Ports_List.append(SWC_Receiverport_List)
        SWC_Ports_List.append(SWC_Senderport_List)
        SWC_port_Dict["supply.arxml"] = SWC_Ports_List

        SWC_Ports_List = []
        SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(Geely_basetech_AUTOSAR)
        SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(Geely_basetech_AUTOSAR)
        SWC_Ports_List.append(SWC_Receiverport_List)
        SWC_Ports_List.append(SWC_Senderport_List)
        SWC_port_Dict["geely_basetech.arxml"] = SWC_Ports_List


        SWC_Ports_List = []
        SWC_Receiverport_List = GetList.Get_SwComponentType_Receiver_Port_List(SDB_AUTOSAR)
        SWC_Senderport_List = GetList.Get_SwComponentType_Sender_Port_List(SDB_AUTOSAR)
        SWC_Ports_List.append(SWC_Receiverport_List)
        SWC_Ports_List.append(SWC_Senderport_List)
        SWC_port_Dict["SDB"] = SWC_Ports_List
        #删除geely下的连线
        #处理ac连线
        geely_ac_list = group_AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
        for ac in geely_ac_list:
            provide_iref = ac.find("./{http://autosar.org/schema/r4.0}PROVIDER-IREF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF").text
            SwComponentType_sender = provide_iref.split("/")[1]
            swc_name_sender = provide_iref.split("/")[-2]
            port_name_sender = provide_iref.split("/")[-1]
            requester_iref = ac.find("./{http://autosar.org/schema/r4.0}REQUESTER-IREF/{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF").text
            SwComponentType_receiver = requester_iref.split("/")[1]
            swc_name_receiver = requester_iref.split("/")[-2]
            port_name_receiver = requester_iref.split("/")[-1]
            
            if SwComponentType_sender == "SwComponentType" and SwComponentType_receiver == "SwComponentType":
                # print("Deletegeely_ac111","{}.arxml".format(swc_name_sender),"{}.arxml".format(swc_name_receiver))
                # print("Deletegeely_ac112",port_name_sender,port_name_receiver)
                # print("Deletegeely_ac113",SWC_port_Dict["{}.arxml".format(swc_name_sender)][1])
                # print("Deletegeely_ac114",SWC_port_Dict["{}.arxml".format(swc_name_receiver)][0])
                # print("SWC_List",SWC_List)
                if "{}.arxml".format(swc_name_sender) not in SWC_List or "{}.arxml".format(swc_name_receiver) not in SWC_List or port_name_sender not in SWC_port_Dict["{}.arxml".format(swc_name_sender)][1] or port_name_receiver not in SWC_port_Dict["{}.arxml".format(swc_name_receiver)][0]:
                    print("Deletegeely_ac",ac.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                    Delete_Element.Delete_Geely_Assembly_Element(group_AUTOSAR,ac,group_swc_name)
        #处理dc连线
        geely_dc_list = group_AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
        for dc in  geely_dc_list:
            if dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF") is None:
                target_p_port_ref = dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}P-PORT-IN-COMPOSITION-INSTANCE-REF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF").text
                swc_name = target_p_port_ref.split("/")[-2]
                port_name = target_p_port_ref.split("/")[-1]
                outer_port_ref = dc.find("./{http://autosar.org/schema/r4.0}OUTER-PORT-REF").text
                port_name_outer = outer_port_ref.split("/")[-1]
                if ("{}.arxml".format(swc_name) not in SWC_List or port_name not in SWC_port_Dict["{}.arxml".format(swc_name)][1] or port_name_outer not in SWC_port_Dict[group_swc_name + ".arxml"][1]):
                    print("Deletegeely_dc_PPORT",dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                    Delete_Element.Delete_Geely_Delegation_Element(group_AUTOSAR,dc,group_swc_name)
            else:
                target_r_port_ref = dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF/{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF").text
                swc_name = target_r_port_ref.split("/")[-2]
                port_name = target_r_port_ref.split("/")[-1]
                outer_port_ref = dc.find("./{http://autosar.org/schema/r4.0}OUTER-PORT-REF").text
                port_name_outer = outer_port_ref.split("/")[-1]
                if ("{}.arxml".format(swc_name) not in SWC_List or port_name not in SWC_port_Dict["{}.arxml".format(swc_name)][0] or port_name_outer not in SWC_port_Dict[group_swc_name + ".arxml"][0]):
                    print("Deletegeely_dc_RPORT",dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                    Delete_Element.Delete_Geely_Delegation_Element(group_AUTOSAR,dc,group_swc_name)
        #处理SDB下的连线
        #处理ac连线
        AR_PACKAGES =SDB_AUTOSAR[0]
        for child in AR_PACKAGES:
            if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
                SWCPkg = child
                break
        sdb_ac_list = SWCPkg.findall(".//{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
        for ac in sdb_ac_list:
            # print(ac.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            provide_iref = ac.find("./{http://autosar.org/schema/r4.0}PROVIDER-IREF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF").text
            swc_name_sender = provide_iref.split("/")[-2]
            port_name_sender = provide_iref.split("/")[-1]
            requester_iref = ac.find("./{http://autosar.org/schema/r4.0}REQUESTER-IREF/{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF").text
            swc_name_receiver = requester_iref.split("/")[-2]
            port_name_receiver = requester_iref.split("/")[-1]
            if swc_name_receiver == "CCM_Internal" or swc_name_sender == "CCM_Internal":
                pass
            else:
                # print("SDB_ac_RPORT",swc_name_sender,swc_name_receiver,port_name_sender,port_name_receiver,group_swc_name,swc_name)
                # print("{}.arxml".format(swc_name_sender),"{}.arxml".format(swc_name_receiver))
                if(port_name_sender not in SWC_port_Dict["{}.arxml".format(swc_name_sender)][1] or port_name_receiver not in SWC_port_Dict["{}.arxml".format(swc_name_receiver)][0])and group_swc_name == swc_name:
                    Delete_Element.Delete_SDB_Assembly_Element(SDB_AUTOSAR,ac)
                    print("DeleteSDB_ac_RPORT",ac.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            # if swc_name_sender == "Conti_SWC":
            #     if port_name_sender not in SWC_port_Dict["Conti_Compositon.arxml"][1] or port_name_receiver not in SWC_port_Dict["geely_cem.arxml"][0]:
            #         print(ac.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            #         Delete_Element.Delete_SDB_Assembly_Element(SDB_AUTOSAR,ac)
            # elif swc_name_sender == "geely_cem":
            #     if port_name_sender not in SWC_port_Dict["geely_cem.arxml"][1] or port_name_receiver not in SWC_port_Dict["Conti_Compositon.arxml"][0]:
            #         print(ac.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            #         Delete_Element.Delete_SDB_Assembly_Element(SDB_AUTOSAR,ac)
        # print("SWC_portSDB_Dict",SWC_port_Dict["SDB"][1])
        # print("SWC_portgeely_cem_Dict",SWC_port_Dict["geely_cem.arxml"][1])
        #处理dc连线
        sdb_dc_list = SWCPkg.findall(".//{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
        for dc in sdb_dc_list:
            if dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF") is None:
                target_p_port_ref = dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}P-PORT-IN-COMPOSITION-INSTANCE-REF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF").text
                swc_name = target_p_port_ref.split("/")[-2]
                port_name = target_p_port_ref.split("/")[-1]
                outer_port_ref = dc.find("./{http://autosar.org/schema/r4.0}OUTER-PORT-REF").text
                port_name_outer = outer_port_ref.split("/")[-1]
                # print("port_name",port_name, port_name_outer,swc_name)
                if swc_name == "CCM_Internal":
                    pass
                else:
                    if (port_name not in SWC_port_Dict["{}.arxml".format(swc_name)][1] or port_name_outer not in SWC_port_Dict["SDB"][1]) and group_swc_name == swc_name:
                        # print("{}.arxml".format(swc_name))
                        print("DeleteSDB_dc_PPORT",dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                        Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
                # if swc_name == "geely_cem":
                #     if port_name not in SWC_port_Dict["geely_cem.arxml"][1] or port_name_outer not in SWC_port_Dict["SDB"][1]:
                #         print(dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                #         Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
                # elif swc_name == "Conti_SWC":
                #     if port_name not in SWC_port_Dict["Conti_SWC.arxml"][1] or port_name_outer not in SWC_port_Dict["SDB"][1]:
                #         print(dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                #         Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
            else:
                target_r_port_ref = dc.find("./{http://autosar.org/schema/r4.0}INNER-PORT-IREF/{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF/{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF").text
                swc_name = target_r_port_ref.split("/")[-2]
                port_name = target_r_port_ref.split("/")[-1]
                outer_port_ref = dc.find("./{http://autosar.org/schema/r4.0}OUTER-PORT-REF").text
                port_name_outer = outer_port_ref.split("/")[-1]
                if swc_name == "CCM_Internal":
                    pass
                else:
                    if( port_name not in SWC_port_Dict["{}.arxml".format(swc_name)][0] or port_name_outer not in SWC_port_Dict["SDB"][0])and group_swc_name == swc_name:
                        print("DeleteSDB_dc_RPORT",dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                        Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
                # if swc_name == "geely_cem":
                #     if port_name not in SWC_port_Dict["geely_cem.arxml"][0] or port_name not in SWC_port_Dict["SDB"][0]:
                #         # print(dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                #         Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
                # elif swc_name == "Conti_SWC":
                #     if port_name not in SWC_port_Dict["Conti_SWC.arxml"][0] or port_name not in SWC_port_Dict["SDB"][0]:
                #         # print(dc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
                #         Delete_Element.Delete_SDB_Delegation_Element(SDB_AUTOSAR,dc)
        
        # print(old_filename)
        # for filename in SWC_List:
        #     if filename == "SleepRequestHandler.arxml":
        #         os.rename(os.path.join(geely_zcu_path, "workspace/geelycem/SWC", filename), os.path.join(geely_zcu_path, "workspace/geelycem/SWC", old_filename))
        #         break
    ET.indent(group_AUTOSAR)
    Feature.save_file(group_AUTOSAR, os.path.join(group_dir))
    ET.indent(SDB_AUTOSAR)
    Feature.save_file(SDB_AUTOSAR, os.path.join(sdb_dir, data["SDB_Name"]))
    # if os.path.exists(os.path.join(os.getcwd(), "Common.arxml")): 
    #     ET.indent(Common_AUTOSAR)
    #     Feature.save_file(Common_AUTOSAR, os.path.join(geely_zcu_path,geely_cem_path, "Common.arxml"))
    # else:
    #     ET.indent(Common_AUTOSAR)
    #     Feature.save_file(Common_AUTOSAR, os.path.join(geely_zcu_path,geely_cem_path, "Common.arxml"))

    if os.path.exists(os.path.join(os.getcwd(), "Common.arxml")): 
        ET.indent(Common_AUTOSAR)
        Feature.save_file(Common_AUTOSAR, common_arxml_path)
    else:
        ET.indent(Common_AUTOSAR)
        Feature.save_file(Common_AUTOSAR, common_arxml_path)
    # 使用自定义打印函数  
print_with_timestamp("这是带有时间戳的打印信息")  
#*****************************************test*******************************************************
    # print(Data_Tpye_Dict_List[10])
    # print(len(GetList.Get_ImplementationDataTypesList(Common_AUTOSAR)))
    # root = Delete_Element.Delete_ImplementationDataTypes_DataType(Common_AUTOSAR, Data_Tpye_Dict_List[10]["Data_Type"])
    # print(len(GetList.Get_ImplementationDataTypesList(root)))
    # element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict_List[10],ImplementationDataTypes_Data_type_List)
    # # root=Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR, element)
    # AR_PACKAGES =root[0]
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
    #         CompuMethodsPkg = child
    #         break
    # Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    # test = []
    # for child in Elements:
    #     test.append(child)
    # print(len(test))
    # Elements.append(element)
    # test = []
    # for child in Elements:
    #     test.append(child)
    # print(len(test))
    
    # # AR_PACKAGES =root[0]
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
    #         ImplementationDataTypesPkg = child
    #         break
    # Elements = ImplementationDataTypesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    # ImplementationDataTypesList =ImplementationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    # print(len(ImplementationDataTypesList))
    # for child in Elements:
    #     test.append(child)
    # print(len(test))
    # element = Generate_Element.Process_ImplementationDataTypes(Data_Tpye_Dict_List[10],ImplementationDataTypes_Data_type_List)
    # Add_Element.Add_ImplementationDataTypes_Element(Common_AUTOSAR,element)
    # Common_AUTOSAR = Delete_Element.Delete_ImplementationDataTypes_DataType(root, Data_Tpye_Dict_List[10]["Data_Type"])
    # # element = Generate_Element.Process_BaseTypes(Data_Tpye_Dict_List[1])
    # # ET.indent(element)
    # # print(ET.tostring(element, encoding='utf-8').decode())
    # # # Add_Element.Add_CompuMethods_Element(Common_AUTOSAR,element)
    
    # ET.indent(Common_AUTOSAR)
    # # # Delete_Element.Delete_CompuMethods_DataType(Common_AUTOSAR, Data_Tpye_Dict_List[1]["Data_Type"])
    # Feature.save_file(Common_AUTOSAR, os.path.join(os.getcwd(), "Common.arxml")) 
# if __name__ == "__main__":

#     Interface_Config("D:/Zcu/ZcuD/Intergration_Temp1/ZCU_H_EB", "D:/HIRAIN/ZCU全栈自研/接口表汇总_ZCU_H_23R3U2_01_01_W31D5/驱动接口表汇总_ZCUD_H_23R3U2_01_01_W31D5/接口表汇总_ZCUDS_24R2_03_01_W31D5.xlsx", "ZCUD")