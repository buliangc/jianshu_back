import xml.etree.ElementTree as ET
import os
import Feature
import SDB_Interface_Configuration


def Delete_DataTypeMappings_DataType(root,dataType,DaTaMapping_Ref_Name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    data_mapping_set_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
    for child in data_mapping_set_list:
        if child.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text == DaTaMapping_Ref_Name:
            data_mapping_set_pkg = child
            break
    Element = data_mapping_set_pkg.find("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS")
    DataTypeMapList = data_mapping_set_pkg.findall("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    for data_type_child in DataTypeMapList:
        application_data_type_ref = data_type_child.find("./{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF").text
        if application_data_type_ref.split("/")[-1] == dataType:
            Element.remove(data_type_child)
        
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeMappings":
    #         DataTypeMappingsPkg = child
    #         break
    # DataTypeMappingsList = DataTypeMappingsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
    # for child in DataTypeMappingsList:
    #     short_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
    #     if short_name.split("DataTypeMappingsSet")[0] == swc or short_name.split("_DataTMappingSet")[0] == swc or short_name.split("DataTMappingSet")[0] == swc or short_name.split("MappingSet")[0] == swc:
    #         Element = child.find("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS")
    #         DataTypeMapList = child.findall("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    #         for data_type_child in DataTypeMapList:
    #             application_data_type_ref = data_type_child.find("./{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF").text
    #             if application_data_type_ref.split("/")[-1] == dataType:
    #                 Element.remove(data_type_child)
            
            
def Delete_CompuMethods_DataType(root, dataType):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "CompuMethods":
            CompuMethodsPkg = child
            break
    Element = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    CompuMethodsList = CompuMethodsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPU-METHOD")
    for child in CompuMethodsList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == dataType:
            Element.remove(child)
  
    
def Delete_BaseTypes_DataType(root, dataType):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "BaseTypes":
            BaseTypesPkg = child
            break
    Element = BaseTypesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    BaseTypesList = BaseTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SW-BASE-TYPE")
    for child in BaseTypesList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == dataType:
            Element.remove(child)


def Delete_DataConstrs_DataType(root, dataType):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataConstrs":
            DataConstrsPkg = child
            break
    Element = DataConstrsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    DataConstrsList = DataConstrsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-CONSTR")
    for child in DataConstrsList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == dataType:
            Element.remove(child)


def Delete_ImplementationDataTypes_DataType(root, dataType):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
            ImplementationDataTypesPkg = child
            break
    Element = ImplementationDataTypesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    ImplementationDataTypesList =ImplementationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in ImplementationDataTypesList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == dataType:
            Element.remove(child)
            
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeImplementation":
            DataTypeImplementationPkg = child
            break
    Element = DataTypeImplementationPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    DataTypeImplementationList =DataTypeImplementationPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in DataTypeImplementationList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == dataType:
            Element.remove(child)
            
def Delete_PortInterfaces_port(root,port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    Element = PortInterfacesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    PortInterfacesList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in PortInterfacesList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)
            

def Delete_Geely_Receiver_port(root, port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for child in ports_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)


def Delete_Geely_Sender_port(root, port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for child in ports_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)
            
            
def Delete_SwComponentType_Receiver_port(root, swc, port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    Application_List = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in Application_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationPkg = child
            break
    Element = ApplicationPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Port_Prototype_List = ApplicationPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for child in Port_Prototype_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)


def Delete_SwComponentType_Sender_port(root, swc, port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    Application_List = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in Application_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationPkg = child
            break
    Element = ApplicationPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Port_Prototype_List = ApplicationPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for child in Port_Prototype_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)
            
            
def Delete_SwComponentType_variable_access_Receiver_port(root,swc,port, element,runnable_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS")
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        # port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        if element_name == (port + "_" + element):
            # print("delete_rport",swc,element_name,element,port + "_" + element)
            Elements.remove(child)
        # elif element_name == port:
        #     Elements.remove(child)
        # elif element_name == element:
        #     Elements.remove(child)
    Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS")
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        # port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        if element_name == (port + "_" + element):
            # print("delete_rport",swc,element_name,element,port + "_" + element)
            Elements.remove(child)


def Delete_SwComponentType_variable_access_Sender_port(root,swc,port, element,runnable_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviors_list = ApplicationTypePkg.findall("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    for child in swc_internal_behaviors_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            swc_internal_behaviorsPkg = child
            break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS")
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        # port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        if element_name == (port + "_" + element) :
            # print("delete_sport",swc,element_name,element,port + "_" + element)
            Elements.remove(child)
        # elif element_name == port:
        #     Elements.remove(child)
        # elif element_name == element:
        #     Elements.remove(child)
    Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-WRITE-ACCESSS")
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-WRITE-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        # port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        if element_name == (port + "_" + element) :
            # print("delete_sport",swc,element_name,element,port + "_" + element)
            Elements.remove(child)
            
            
def Delete_Common_CarCfg_Element(root,Receiver_Port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        # if any(item == child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text for item in SDB_Interface_Configuration.Value_Interface_List):
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == Receiver_Port["Interface"]:
            CarCfgPkg = child
            break
    Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    CarCfg_Elements_List = CarCfgPkg.findall("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS/{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    for child in CarCfg_Elements_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == Receiver_Port["Element"]:
            Elements.remove(child)
            
def Delete_Common_CarCfg_invalidation_Element(root,Receiver_Port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        # if any(item == child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text for item in SDB_Interface_Configuration.Value_Interface_List):
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == Receiver_Port["Interface"]:
            CarCfgPkg = child
            break
    Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")
    
    invalidation_list = CarCfgPkg.findall("./{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS/{http://autosar.org/schema/r4.0}INVALIDATION-POLICY")
    
    for child in invalidation_list:
        if child.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF").text.split("/")[-1] == Receiver_Port["Element"]:
            Elements.remove(child)
            
            
def Delete_Geely_Assembly_Element(root,element,group_swc_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == group_swc_name:
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == group_swc_name:
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}CONNECTORS")
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    for child in ports_list:
        if child == element:
            Element.remove(child)

def Delete_Geely_Delegation_Element(root,element,group_swc_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == group_swc_name:
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == group_swc_name:
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}CONNECTORS")
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    for child in ports_list:
        if child == element:
            Element.remove(child)


def Delete_SDB_Assembly_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SWCPkg = child
            break
    Element = SWCPkg.find(".//{http://autosar.org/schema/r4.0}CONNECTORS")
    ports_list = root.findall(".//{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    for child in ports_list:
        if child == element:
            Element.remove(child)
          
def Delete_SDB_Delegation_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SWCPkg = child
            break
    Element = SWCPkg.find(".//{http://autosar.org/schema/r4.0}CONNECTORS")
    ports_list = root.findall(".//{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    for child in ports_list:
        if child == element:
            Element.remove(child)
# root = Feature.parse_file(r"SWC/ImobEPBLockMgr.arxml")
# list = Delete_PortInterfaces_port(root,"DrvrStrtReq")
# ET.indent(root)
# Feature.save_file(root, os.path.join(os.getcwd(), "SWC", "{}.arxml".format("ImobEPBLockMgr"))) 



def Search_variable_access_Sender_port(root,swc,runnable_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    Sender_ports = {}
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviors_list = ApplicationTypePkg.findall("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    for child in swc_internal_behaviors_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            swc_internal_behaviorsPkg = child
            break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        Sender_ports[port_name] = []

    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        element_name = child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF").text.split("/")[-1]
        if element_name not in Sender_ports[port_name]: 
            Sender_ports[port_name].append(element_name)

    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-WRITE-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        Sender_ports[port_name] = []

    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "")
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        element_name = child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF").text.split("/")[-1]
        if element_name not in Sender_ports[port_name]: 
            Sender_ports[port_name].append(element_name)

    return Sender_ports

def Search_variable_access_Receiver_port(root,swc,runnable_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    Receiver_ports = {}
    
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        Receiver_ports[port_name] = []
    # print("Receiver_ports1", Receiver_ports)
        
    for child in variable_access_list:
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        element_name = child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF").text.split("/")[-1]
        if element_name not in Receiver_ports[port_name]:  
            Receiver_ports[port_name].append(element_name)
    # print("Receiver_ports2", Receiver_ports)

    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        Receiver_ports[port_name] = []
    # print("Receiver_ports1", Receiver_ports)
        
    for child in variable_access_list:
        # element_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        port_name =  child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF").text.split("/")[-1]
        # print("port",port)
        element_name = child.find("./{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE/{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF/{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF").text.split("/")[-1]
        if element_name not in Receiver_ports[port_name]:  
            Receiver_ports[port_name].append(element_name)
    # print("Receiver_ports2", Receiver_ports)
        
        # Receiver_ports.append(port_name)
    # print("Receiver_ports", Receiver_ports)
    return Receiver_ports
