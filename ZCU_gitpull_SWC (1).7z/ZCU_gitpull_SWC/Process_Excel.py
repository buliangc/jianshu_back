import pandas as pd
import openpyxl
import numpy as np  

def Get_Data_Type_Dict(filepath,sheetname):
    Data_Tpye_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname) 
    i = 0
    print(len(df.values))
    while i < len(df.values):
        
        print(df.values[i][2])
        if df.values[i][2] == "Primitive Data Type":
            # print(i)
            if pd.notna(df.values[i][4]) and df.values[i][4] != "/" and pd.notna(df.values[i][5]) == False and df.values[i][5] != "/": #基本类型
                
                Data_Tpye_Dict = {}
                Data_Tpye_Dict["SWC"] = df.values[i][0]
                Data_Tpye_Dict["Data_Type"] = df.values[i][1]
                Data_Tpye_Dict["Type"] = "VALUE"
                Data_Tpye_Dict["Value_Type"] = "IDENTICAL"
                Data_Tpye_Dict["Data_Type_Name"] = df.values[i][4]
                Data_Tpye_Dict["NoInterface"] = df.values[i][14]
                Data_Tpye_Dict_List.append(Data_Tpye_Dict)
                i = i + 1
            elif df.values[i][4] != "/" and pd.notna(df.values[i][5]) and df.values[i][5] != "/": #线性
                # print("Data_Type",df.values[i][1])
                if isinstance(df.values[i][6], float):
                    if df.values[i][6].is_integer():
                        min_values = int(df.values[i][6])
                        # print(int(df.values[i][6]))
                    else:
                        min_values = (df.values[i][6])
                        # print(df.values[i][6])
                else:
                    min_values = (df.values[i][6])
                    # print(df.values[i][6])
                Data_Tpye_Dict = {}
                Data_Tpye_Dict["SWC"] = df.values[i][0]
                Data_Tpye_Dict["Data_Type"] = df.values[i][1]
                Data_Tpye_Dict["Type"] = "VALUE"
                Data_Tpye_Dict["Value_Type"] = "LINEAR"
                Data_Tpye_Dict["Size"] = df.values[i][5]
                Data_Tpye_Dict["Min"] = min_values #df.values[i][6]
                Data_Tpye_Dict["Max"] = df.values[i][7]
                Data_Tpye_Dict["Factor"] = df.values[i][10]
                Data_Tpye_Dict["Offset"] = df.values[i][11]
                Data_Tpye_Dict["Unit"] = df.values[i][12]
                Data_Tpye_Dict["Native Declaration"] = df.values[i][4]
                Data_Tpye_Dict["NoInterface"] = df.values[i][14]
                Data_Tpye_Dict_List.append(Data_Tpye_Dict)
                i = i + 1
            elif pd.notna(df.values[i][9]) and df.values[i][9] != "/": #枚举
                print("Data_Type",df.values[i][1],df.values[i][0])
                Data_Tpye_Dict = {}
                Data_Tpye_Dict["SWC"] = df.values[i][0]
                Data_Tpye_Dict["Data_Type"] = df.values[i][1]
                Data_Tpye_Dict["Type"] = "VALUE"
                Data_Tpye_Dict["Value_Type"] = "TEXTTABLE"
                Data_Tpye_Dict["Constant_List"] = [{"Min":int(df.values[i][6]),"Max":int(df.values[i][7]),"Value":int(df.values[i][8]),"Constant":df.values[i][9]}]
                Data_Tpye_Dict["Unit"] = df.values[i][12]
                Data_Tpye_Dict["NoInterface"] = df.values[i][14]
                i = i + 1
                while i < len(df.values) and pd.isna(df.values[i][1]):
                    Data_Tpye_Dict["Constant_List"].append({"Min":int(df.values[i][6]),"Max":int(df.values[i][7]),"Value":int(df.values[i][8]),"Constant":df.values[i][9]})
                    i = i + 1
                
                # if df.values[i][1] == "SunRoofAndCurtActrPre":
                #     print("Data_Tpye_Dict",Data_Tpye_Dict)

                Data_Tpye_Dict_List.append(Data_Tpye_Dict)
                # if df.values[i][1] == "SunRoofAndCurtActrPre":
                #     print("Data_Tpye_Dict_List",Data_Tpye_Dict_List)
                
        elif df.values[i][2] == "Record Data Type":
            # print(i)
            Data_Tpye_Dict = {}
            Data_Tpye_Dict["SWC"] = df.values[i][0]
            Data_Tpye_Dict["Data_Type"] = df.values[i][1]
            Data_Tpye_Dict["Type"] = "STRUCTURE"
            Data_Tpye_Dict["Struct_List"] = [{"Record_Data_element":df.values[i][3], "Data_Type_Name":df.values[i][4]}]
            Data_Tpye_Dict["NoInterface"] = df.values[i][14]
            i = i + 1
            print(i)
            while i < len(df.values) and pd.isna(df.values[i][1]):
                if df.values[i][2] == "Record Data Type":
                    Data_Tpye_Dict["Struct_List"].append({"Record_Data_element":df.values[i][3], "Data_Type_Name":df.values[i][4]})
                    i = i + 1
                else: i = i + 1
            
            Data_Tpye_Dict_List.append(Data_Tpye_Dict)
        else:
            i = i + 1
    # print("Data_Tpye_Dict_List",Data_Tpye_Dict_List)
    # print(NoInterface11)
    return Data_Tpye_Dict_List

def Get_Array_Data_Type_Dict(filepath,sheetname):
    Array_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname) 
    i = 0
    print(len(df.values))
    for i in df.values:
        if i[2] == "Array Data Type":
            # print("Array",i[4])
            Array_Dict = {}
            Array_Dict["SWC"] = i[0]
            Array_Dict["Data_Type"] = i[4]
            Array_Dict["Size"] = int(i[5])
            Array_Dict_List.append(Array_Dict)
    return Array_Dict_List

def Get_Array_Dict(filepath,sheetname):
    Array_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname)
    
    for i in df.values:
        print("Array",i[3],i[4])
        if i[3] == "Array":
            # print("Array",i[4])
            Array_Dict = {}
            Array_Dict["SWC"] = i[0]
            Array_Dict["Data_Type"] = i[2]
            Array_Dict["Size"] = int(i[13])
            Array_Dict_List.append(Array_Dict)
    return Array_Dict_List


def Get_Receiver_Port_Dict(filepath,sheetname):

    Receiver_Port_Dict_List = []  
    
    # 使用 openpyxl 加载 Excel 文件  
    workbook = openpyxl.load_workbook(filepath)  
    sheet = workbook[sheetname]  

    # 获取所有行的数据，过滤掉带删除线的整行和空行  
    rows = []  
    for row in sheet.iter_rows(min_row=2):  
        # 检查整行是否有带删除线的单元格  
        if any(cell.font.strike for cell in row):  
            continue  

        # 检查整行是否为空  
        row_data = [cell.value if cell.value is not None else np.nan for cell in row]  # 替换为空值为 NaN  
        if all(pd.isna(value) for value in row_data):  # 如果行全为空，跳过  
            continue 
        rows.append(row_data)  

    # 使用 pandas 创建 DataFrame  
    df = pd.DataFrame(rows)  
    i = 0
    while i < len(df.values):
        Receiver_Port_Dict = {}
        Receiver_Port_Dict["SWC"] = df.values[i][0]
        Receiver_Port_Dict["Receiver_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4], "Interface":df.values[i][5], "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":int(df.values[i][13]) if isinstance(df.values[i][13], (int, float)) and not np.isnan(df.values[i][13]) else df.values[i][13]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Receiver_Port_Dict["Receiver_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4], "Interface":df.values[i][5], "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":int(df.values[i][13]) if isinstance(df.values[i][13], (int, float)) and not np.isnan(df.values[i][13]) else df.values[i][13]})
            i = i + 1
        Receiver_Port_Dict_List.append(Receiver_Port_Dict)
    return Receiver_Port_Dict_List

# def Get_Receiver_Port_Dict(filepath,sheetname):
#     Receiver_Port_Dict_List = []
#     df = pd.read_excel(filepath, sheet_name=sheetname)
#     i = 0
#     while i < len(df.values):
#         Receiver_Port_Dict = {}
#         Receiver_Port_Dict["SWC"] = df.values[i][0]
#         Receiver_Port_Dict["Receiver_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4], "Interface":df.values[i][5], "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]}]
#         i = i + 1
#         while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
#             Receiver_Port_Dict["Receiver_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4], "Interface":df.values[i][5], "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]})
#             i = i + 1
#         Receiver_Port_Dict_List.append(Receiver_Port_Dict)
#     return Receiver_Port_Dict_List

def Get_Sender_Port_Dict(filepath,sheetname):
    Sender_Port_Dict_List = []
    # 使用 openpyxl 加载 Excel 文件  
    workbook = openpyxl.load_workbook(filepath)  
    sheet = workbook[sheetname]  
    # 获取所有行的数据，过滤掉带删除线的整行和空行  
    rows = []  
    for row in sheet.iter_rows(min_row=2):  
        # 检查整行是否有带删除线的单元格  
        if any(cell.font.strike for cell in row):  
            continue  
        # 检查整行是否为空  
        row_data = [cell.value if cell.value is not None else np.nan for cell in row]  # 替换为空值为 NaN  
        if all(pd.isna(value) for value in row_data):  # 如果行全为空，跳过  
            continue 
        rows.append(row_data)  
    # 使用 pandas 创建 DataFrame  
    df = pd.DataFrame(rows) 
    i = 0
    while i < len(df.values):
        Sender_Port_Dict = {}
        Sender_Port_Dict["SWC"] = df.values[i][0]
        Sender_Port_Dict["Sender_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4], "Interface":df.values[i][5],"Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":int(df.values[i][13]) if isinstance(df.values[i][13], (int, float)) and not np.isnan(df.values[i][13]) else df.values[i][13]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Sender_Port_Dict["Sender_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4], "Interface":df.values[i][5],"Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":int(df.values[i][13]) if isinstance(df.values[i][13], (int, float)) and not np.isnan(df.values[i][13]) else df.values[i][13]})
            i = i + 1
        # print("Sender_Port_Dict",Sender_Port_Dict,"\n")
        Sender_Port_Dict_List.append(Sender_Port_Dict)
    return Sender_Port_Dict_List

# def Get_Sender_Port_Dict(filepath,sheetname):
#     Sender_Port_Dict_List = []
#     df = pd.read_excel(filepath, sheet_name=sheetname)
#     i = 0
#     while i < len(df.values):
#         Sender_Port_Dict = {}
#         Sender_Port_Dict["SWC"] = df.values[i][0]
#         Sender_Port_Dict["Sender_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4], "Interface":df.values[i][5],"Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]}]
#         i = i + 1
#         while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
#             Sender_Port_Dict["Sender_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4], "Interface":df.values[i][5],"Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]})
#             i = i + 1
#         print("Sender_Port_Dict",Sender_Port_Dict,"\n")
#         Sender_Port_Dict_List.append(Sender_Port_Dict)
#     return Sender_Port_Dict_List


def Get_Execl_Delete_List(filepath,sheetname):
    dict_temp = {}
    delete_Port_Dict = {}
    book = openpyxl.load_workbook(filepath)
    for row in book.get_sheet_by_name(sheetname).rows:
        if(row[4].font.strike):
            delete_Port_Dict = {"Port":row[4].value,"Interface":row[5].value,"Element":row[6].value}
            dict_temp.setdefault(row[0].value,[]).append(delete_Port_Dict)
    # print("dict_temp",dict_temp)
    return dict_temp
# def Get_Datatyoe_List(filepath,sheetname):
#     DataTyoe_List = []
#     df = pd.read_excel(filepath, sheet_name=sheetname)
#     for i in df.values:
        
# list = Get_Data_Type_Dict("test1.xlsx","DataType Dict")      
# for i in list:
#     print(i)                        