# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
from gitandcopy import run
import configparser
from tkinter import messagebox
import os

# 创建控件的封装
class CreatWidget(object):
    # 文件夹选择并将名字插入到entry中
    def select_folder(self,entry):
        folder_path = filedialog.askdirectory()
        entry.delete(0, tk.END)
        entry.insert(0, folder_path)
    # 文件选择并将名字插入到entry中
    def select_file(self,entry):
        file_path = filedialog.askopenfilename()
        entry.delete(0, tk.END)
        entry.insert(0, file_path)
    # 创建文本
    def create_label(self,window, text, x, y):
        label = tk.Label(window, fg="black", bg="white", text=text)
        label.place(x=x, y=y)
        return label
    # 创建输入框
    def create_entry(self,window, text, width, x, y):
        entry = tk.Entry(window, width=width)
        entry.insert(0, text)
        entry.place(x=x, y=y)
        return entry
    # 创建按钮并绑定函数
    def create_button(self,window, text, command, x, y,width):
        button = tk.Button(window, fg="black", bg="white", command=command, text=text, width=width, height=1)
        button.place(x=x, y=y)
        return button
    # 设置选择框的值
    def set_combobox_value(self,combobox, value):
        if value in combobox['values']:
            index = combobox['values'].index(value)
            combobox.current(index)
    # 创建选择框，配置可选配置及初始值
    def create_combobox(self,window, values, current, x, y,width=40):
        combobox = ttk.Combobox(window, width=width, textvariable=tk.StringVar(), state="readonly")
        combobox['values'] = values
        combobox.place(x=x, y=y)
        self.set_combobox_value(combobox,current)
        return combobox

class ConfigurationGUI(CreatWidget): 
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("便捷小工具")
        self.window.geometry('1000x800')
        self.window.configure(background="white")
        self.create_widgets()

    def on_drag(self,event):
        global prev_x, prev_y
        x, y = event.x, event.y
        self.canvas.create_line(prev_x, prev_y, x, y, fill="black", width=2)
        
        prev_x, prev_y = x, y

    def on_click(self, event):
        global prev_x, prev_y
        prev_x, prev_y = event.x, event.y

    def popup_message(self):
        # messagebox.showinfo("弹窗", "您点击了按钮！")
        # 创建新窗口
        canvas_window = tk.Toplevel(self.window)
        canvas_window.title("随便画画")

        # 创建Canvas画布
        self.canvas = tk.Canvas(canvas_window, width=500, height=200)
        self.canvas.pack()
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<Button-1>", self.on_click)
        prev_x, prev_y = 0, 0

    
    def create_widgets(self):
        # 初始化配置
        self.load_config()
        options = self.config.sections()
        self.geely_path = self.config[options[0]]["geely_path"]
        self.conti_path = self.config[options[0]]["conti_path"]
        self.ccm_path = self.config[options[0]]["ccm_path"]
        self.geely_branch = self.config[options[0]]["geely_branch"]
        self.conti_branch = self.config[options[0]]["conti_branch"]
        self.ccm_branch = self.config[options[0]]["ccm_branch"]
        self.release_type = self.config[options[0]]["release_type"]
        self.ZCU_type = self.config[options[0]]["ZCU_type"]
        self.compare_path = self.config[options[0]]["compare_path"]
        self.geely_swc = self.config[options[0]]["geely_swc"]
        self.geely_template_swc = self.config[options[0]]["geely_template_swc"]
        self.interface_path = self.config[options[0]]["interface_path"]
        self.ZCU_Switch = self.config[options[0]]["ZCU_Switch"]

        # 配置项组件
        self.configframe = tk.Frame(self.window, width=950, height=350, bg='lightgray') 
        self.configframe.place(x=40,y=35,anchor="nw")
        # =========================geely仓库 y = 50=======================
        # geey仓库路径
        self.label_geely_path = self.create_label(self.window, "选择Geely仓库文件夹:", 50, 50)
        self.entry_geely_path = self.create_entry(self.window, self.geely_path, 40, 200, 50)
        self.button_geely_path = self.create_button(self.window, "...", lambda: self.select_folder(self.entry_geely_path), 500, 50,2)
        # geely_branch 
        self.label_geely_branch = self.create_label(self.window, "输入Geely分支:", 550, 50)
        self.entry_geely_branch = self.create_entry(self.window, self.geely_branch, 40, 660, 50)
        # =========================conti仓库 y = 100=======================
        # conti仓库路径
        self.label_conti_path = self.create_label(self.window, "选择Conti仓库文件夹:", 50, 100)
        self.entry_conti_path = self.create_entry(self.window, self.conti_path, 40, 200, 100)
        self.button_conti_path = self.create_button(self.window, "...", lambda: self.select_folder(self.entry_conti_path), 500, 100,2)
        # conti_branch 
        self.label_conti_branch = self.create_label(self.window, "输入Conti分支:", 550, 100)
        self.entry_conti_branch = self.create_entry(self.window, self.conti_branch, 40, 660, 100)
		# ==========================ccm 仓库 y = 150===========================
        # CCM仓库路径
        self.label_ccm_path = self.create_label(self.window, "选择CCM仓库文件夹:", 50, 150)
        self.entry_ccm_path = self.create_entry(self.window, self.ccm_path, 40, 200, 150)
        self.button_ccm_path = self.create_button(self.window, "...", lambda: self.select_folder(self.entry_ccm_path), 500, 150,2)
        # CCM_branch 
        self.label_ccm_branch = self.create_label(self.window, "输入CCM分支:", 550, 150)
        self.entry_ccm_branch = self.create_entry(self.window, self.ccm_branch, 40, 660, 150)
        # ======================y = 200 =====================================
        # beyondcompare 路径
        self.label_compare_path = self.create_label(self.window, "选择Compare.exe:", 50, 200)
        self.entry_compare_path = self.create_entry(self.window, self.compare_path, 40, 200, 200)
        self.button_compare_path = self.create_button(self.window, "...", lambda: self.select_file(self.entry_compare_path), 500, 200,2)
        # 选择ZCU类型
        self.label_ZCU = self.create_label(self.window, "选择ZCU类型:", 550, 200)
        self.select_ZCU = self.create_combobox(self.window, ["ZCUD", "ZCUDS", "ZCUDM", "ZCUP"], self.ZCU_type, 660, 200, 40)
        # =========================y = 250 ===============================
        # geely swc文件夹路径
        self.label_geely_swc = self.create_label(self.window, "选择Geely SWC文件夹:", 50, 250)
        self.entry_geely_swc = self.create_entry(self.window, self.geely_swc, 40, 200, 250)
        self.button_geely_swc = self.create_button(self.window, "...", lambda: self.select_folder(self.entry_geely_swc), 500, 250,2)
        # 选择预编译释放还是总集成
        self.label_release = self.create_label(self.window, "选择Release类型:", 550, 250)
        self.select_release = self.create_combobox(self.window, ["Full", "Pre"], self.release_type, 660, 250, 40)
        # =========================y = 300 ===============================
        # 选择接口配置表格
        self.label_interface_path = self.create_label(self.window, "选择接口配置表:", 50, 300)
        self.entry_interface_path = self.create_entry(self.window, self.interface_path, 40, 200, 300)
        self.button_interface_path = self.create_button(self.window, "...", lambda: self.select_file(self.entry_interface_path), 500, 300,2)

        # 选择ZCU类型
        self.label_Switch = self.create_label(self.window, "选择配置接口类型:", 50, 350)
        self.select_ZCU_Switch = self.create_combobox(self.window, ["cemswc", "chassisswc", "hcmswc","geely_bsw","supply"], self.ZCU_Switch, 200, 350, 40)
        # 选择配置项控件
        self.label_Config = self.create_label(self.window, "选择配置项:", 550, 300)
        self.select_Config = self.create_combobox(self.window, options, options[0], 660, 300, 20)
        self.select_Config.bind("<<ComboboxSelected>>", self.on_config_select)
        # 保存配置项按钮
        self.button_config = self.create_button(self.window, "保存配置页", lambda: self.save_config(False), 850, 300,10)
        # ================================操作选项=================================
        # 选择控件
        self.chooseframe = tk.Frame(self.window, width=950, height=400, bg='lightgray') 
        self.chooseframe.place(x=40,y=390,anchor="nw")
        #选择是否拉取代码切换分支
        self.gitvar = tk.IntVar()
        # self.gitvar.set(1)
        checkbutton_git = tk.Checkbutton(self.window, text="1、是否拉取仓库，选中：拉取", variable=self.gitvar)
        checkbutton_git.place(x=50, y=400, anchor="nw")
        # 选择是否清空当前仓库
        self.cleanvar = tk.IntVar()
        # self.cleanvar.set(1)
        checkbutton_clean = tk.Checkbutton(self.window, text="1.1、是否清空仓库，选中：清空", variable=self.cleanvar)
        checkbutton_clean.place(x=300, y=400, anchor="nw")
        # 选择是否拷贝文件
        self.copyvar = tk.IntVar()
        # self.copyvar.set(1)
        checkbutton_copy = tk.Checkbutton(self.window, text="2、是否拷贝文件，选中：拷贝", variable=self.copyvar)
        checkbutton_copy.place(x=50, y=450, anchor="nw")
		# 选择是否更新CCM代码
        self.ccmUpdatevar = tk.IntVar()
        checkbutton_ccmUpdate = tk.Checkbutton(self.window, text="3、是否更新CCM文件，选中：更新", variable=self.ccmUpdatevar)
        checkbutton_ccmUpdate.place(x=50, y=500, anchor="nw")
        # 选择是否配置接口
        self.interfacevar = tk.IntVar()
        self.interfacevar.set(1)
        checkbutton_interface = tk.Checkbutton(self.window, text="4、配置接口，选中：配置", variable=self.interfacevar)
        checkbutton_interface.place(x=50, y=550, anchor="nw")
        # 选择是否编译
        self.genvar = tk.IntVar()
        # self.genvar.set(1)
        checkbutton_generate = tk.Checkbutton(self.window, text="5、是否编译代码，选中：编译", variable=self.genvar)
        checkbutton_generate.place(x=50, y=600, anchor="nw")
        # 选择是否比较conti和geely的仓库
        self.compvar = tk.IntVar()
        # self.compvar.set(1)
        checkbutton_comp = tk.Checkbutton(self.window, text="6、是否比较文件，选中：比较", variable=self.compvar)
        checkbutton_comp.place(x=50, y=650, anchor="nw")
        # 启动
        button_run = tk.Button(self.window, text="RUN", command=lambda: self.button_click(),width=5)
        button_run.place(x=500, y=710, anchor="nw")
        # 别点
        button_run = tk.Button(self.window, text="别点", command=lambda: self.popup_message(),width=5)
        button_run.place(x=10, y=800, anchor="nw")
        # 退出保存配置
        self.window.protocol("WM_DELETE_WINDOW", lambda: self.save_config(True))
        

    def load_config(self):
        self.config = configparser.ConfigParser()
        self.config.read('config.ini',encoding='UTF-8')
    
    # 保存当前配置到配置文件
    def save_config(self,close):
        config_sheet = self.select_Config.get()
        self.config[config_sheet]["geely_path"] = self.entry_geely_path.get()
        self.config[config_sheet]["conti_path"] = self.entry_conti_path.get()
        self.config[config_sheet]["ccm_path"] = self.entry_ccm_path.get()
        self.config[config_sheet]["geely_branch"] =self.entry_geely_branch.get()
        self.config[config_sheet]["conti_branch"] = self.entry_conti_branch.get()
        self.config[config_sheet]["ccm_branch"] = self.entry_ccm_branch.get()
        self.config[config_sheet]["release_type"] = self.select_release.get()
        self.config[config_sheet]["ZCU_type"] = self.select_ZCU.get()
        self.config[config_sheet]["compare_path"] = self.entry_compare_path.get()
        self.config[config_sheet]["geely_swc"] = self.entry_geely_swc.get()
        self.config[config_sheet]["interface_path"] = self.entry_interface_path.get()
        self.config[config_sheet]["ZCU_Switch"] = self.select_ZCU_Switch.get()
        current_folder = os.path.dirname(os.path.realpath(__file__))
        # print(current_folder,os.getcwd())
        with open(os.path.join(current_folder,'config.ini'), 'w', encoding='utf-8') as configfile:
            self.config.write(configfile)
        if(close):
            self.window.destroy()
    # 配置项选择并初始化控件值
    def on_config_select(self,event):
        selected_option = self.select_Config.get()

        self.geely_path = self.config[selected_option]["geely_path"]
        self.entry_geely_path.delete(0, tk.END)
        self.entry_geely_path.insert(0, self.geely_path)

        self.conti_path = self.config[selected_option]["conti_path"]
        self.entry_conti_path.delete(0, tk.END)
        self.entry_conti_path.insert(0, self.conti_path)

        self.ccm_path = self.config[selected_option]["ccm_path"]
        self.entry_ccm_path.delete(0, tk.END)
        self.entry_ccm_path.insert(0, self.ccm_path)

        self.geely_branch = self.config[selected_option]["geely_branch"]
        self.entry_geely_branch.delete(0, tk.END)
        self.entry_geely_branch.insert(0, self.geely_branch)

        self.conti_branch = self.config[selected_option]["conti_branch"]
        self.entry_conti_branch.delete(0, tk.END)
        self.entry_conti_branch.insert(0, self.conti_branch)

        self.ccm_branch = self.config[selected_option]["ccm_branch"]
        self.entry_ccm_branch.delete(0, tk.END)
        self.entry_ccm_branch.insert(0, self.ccm_branch)

        self.release_type = self.config[selected_option]["release_type"]
        self.set_combobox_value(self.select_release,self.release_type)

        self.ZCU_type = self.config[selected_option]["ZCU_type"]
        self.set_combobox_value(self.select_ZCU,self.ZCU_type)

        self.ZCU_Switch = self.config[selected_option]["ZCU_Switch"]
        self.set_combobox_value(self.select_ZCU_Switch,self.ZCU_Switch)

        self.compare_path = self.config[selected_option]["compare_path"]
        self.entry_compare_path.delete(0, tk.END)
        self.entry_compare_path.insert(0, self.compare_path)

        self.geely_swc = self.config[selected_option]["geely_swc"]
        self.geely_template_swc = self.config[selected_option]["geely_template_swc"]
        
        self.entry_geely_swc.delete(0, tk.END)
        self.entry_geely_swc.insert(0, self.geely_swc)

        self.interface_path = self.config[selected_option]["interface_path"]
        self.entry_interface_path.delete(0, tk.END)
        self.entry_interface_path.insert(0,self.interface_path)
    # 启动按钮
    def button_click(self):
        print("按钮被点击了！")
        run_config = {}
        run_config["geely_path"] = self.entry_geely_path.get()
        run_config["conti_path"] = self.entry_conti_path.get()
        run_config["ccm_path"] = self.entry_ccm_path.get()
        run_config["geely_branch"] = self.entry_geely_branch.get()
        run_config["conti_branch"]= self.entry_conti_branch.get()
        run_config["ccm_branch"]= self.entry_ccm_branch.get()
        run_config["release_type"] = self.select_release.get()
        run_config["ZCU_type"] = self.select_ZCU.get()
        run_config["compare_path"] = self.entry_compare_path.get()
        run_config["geely_swc"] = self.entry_geely_swc.get()
        run_config["git_choose"] = self.gitvar.get()
        run_config["clean_choose"] = self.cleanvar.get()
        run_config["copy_choose"] = self.copyvar.get()
        run_config["comp_choose"] = self.compvar.get()
        run_config["ccmUpdate_choose"] = self.ccmUpdatevar.get()
        run_config["geely_template_swc"] = self.geely_template_swc
        run_config["interface_choose"] = self.interfacevar.get()
        run_config["interface_path"] = self.entry_interface_path.get()
        run_config["gennrate_choose"] = self.genvar.get()
        run_config["ZCU_Switch"] = self.select_ZCU_Switch.get()
        run(run_config)


    def start(self):
        self.window.mainloop()

if __name__ == "__main__":
    config_gui = ConfigurationGUI()
    config_gui.start()
