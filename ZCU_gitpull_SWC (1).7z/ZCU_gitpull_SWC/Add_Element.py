import GetList
import SDB_Interface_Configuration
import xml.etree.ElementTree as ET
import Feature

def Add_CompuMethods_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "CompuMethods":
            CompuMethodsPkg = child
            break
    Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)
    

def Add_BaseTypes_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "BaseTypes":
            CompuMethodsPkg = child
            break
    Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)
    

def Add_DataConstrs_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataConstrs":
            CompuMethodsPkg = child
            break
    Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)
    

def Add_ImplementationDataTypes_Element(root,element):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
            CompuMethodsPkg = child
            break
    Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)
    
def Add_DataTypeImplementation_Element(root,element):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeImplementation":
            CompuMethodsPkg = child
            break
    Elements = CompuMethodsPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)
    
    
    
def Add_DataTypeMappings_Top_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    AR_PACKAGES.append(element)

import xml.etree.ElementTree as ET
from datetime import datetime, timezone
import argparse

def convert_to_datetime():
    """获取当前时间并格式化为 ISO 8601 字符串"""
    return datetime.now(timezone.utc).astimezone().isoformat()

def Add_Include_DataType_Element(root,element,SWC_Name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    swc_internal_behaviors = root.findall(".//{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
        
    if not swc_internal_behaviors:
        print("警告：未找到 SWC-INTERNAL-BEHAVIOR 节点")
        return
    
    for behavior in swc_internal_behaviors:
        # 检查是否存在 INCLUDED-DATA-TYPE-SETS 节点
        data_type_sets = behavior.find("{http://autosar.org/schema/r4.0}INCLUDED-DATA-TYPE-SETS")
        
    if data_type_sets is None:
        # 创建 INCLUDED-DATA-TYPE-SETS 节点
        data_type_sets = ET.Element("{http://autosar.org/schema/r4.0}INCLUDED-DATA-TYPE-SETS")
        
        # 创建 INCLUDED-DATA-TYPE-SET 节点并设置时间戳
        data_type_set = ET.SubElement(data_type_sets, "{http://autosar.org/schema/r4.0}INCLUDED-DATA-TYPE-SET")
        data_type_set.set('T', convert_to_datetime())
        
        # 创建 DATA-TYPE-REFS 节点
        data_type_refs = ET.SubElement(data_type_set, "{http://autosar.org/schema/r4.0}DATA-TYPE-REFS")
        
        # 将新创建的节点添加到 SWC-INTERNAL-BEHAVIOR
        behavior.append(data_type_sets)
        print("已向 SWC-INTERNAL-BEHAVIOR 添加 INCLUDED-DATA-TYPE-SETS",SWC_Name)
        data_type_refs.append(element)
    else:
        data_type_list = data_type_sets.findall(".//{http://autosar.org/schema/r4.0}INCLUDED-DATA-TYPE-SET")
        for child in data_type_list:
            data_type_set = child.find("./{http://autosar.org/schema/r4.0}DATA-TYPE-REF")
        data_type_set = AR_PACKAGES.find(".//{http://autosar.org/schema/r4.0}DATA-TYPE-REFS")
        data_type_set.append(element)

def Add_DataTypeMappings_Element(root,element,DaTaMapping_Ref_Name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    data_mapping_set_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
    for child in data_mapping_set_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == DaTaMapping_Ref_Name:
            data_mapping_set_pkg = child
    Elements = data_mapping_set_pkg.find("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS")
    Elements.append(element)
    

def Add_PortInterfaces_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    Elements = PortInterfacesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)

def Add_SwComponentType_Port_Element(root,swc,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    Elements = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Elements.append(element)
    
def Add_Geely_ReceiverPort_Element(root, element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Element.append(element)


def Add_Geely_SenderPort_Element(root, element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Element = GeelyPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Element.append(element)
    
    
def Add_SwComponentType_Variable_Access_Receiver_Port_Element(root,swc,element,runnable_name,Data_Access_Mode_Type):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        # Elements = child.find("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS")
        # print("swc",swc,element,runnable_name)
        # if Elements is None:
        #     print("未找到DATA-RECEIVE-POINT-BY-ARGUMENTS元素。")
        #     continue

        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    # print("123",Data_Access_Mode_Type)
    if Data_Access_Mode_Type == "ExplicitReceive":
        Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS")
    elif Data_Access_Mode_Type == "ImplicitReceive":
        Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS")
    elif Data_Access_Mode_Type == "IsUpdated":
        print("Receiver_Port_Data_Access_Mode_Type输入错误","IsUpdated")
        return None
    else:
        print("Receiver_Port_Data_Access_Mode_Type输入错误",Data_Access_Mode_Type)
        return None
    # print("1234",Elements)
    Elements.append(element)
    

def Add_SwComponentType_Variable_Access_Sender_Port_Element(root,swc,element,runnable_name,Data_Access_Mode_Type):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        # Elements = child.find("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS")
        # print("Sender_Portswc",swc,element,runnable_name)
        # if(Elements == 'NoneType'):
        #     print("未找到DATA-SEND-POINTS元素。")
        #     continue
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    if Data_Access_Mode_Type == "ExplicitSend":
        Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS")
    elif Data_Access_Mode_Type == "ImplicitSend":
        Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}DATA-WRITE-ACCESSS")
    else:
        print("Sender_Port_Data_Access_Mode_Type输入错误",Data_Access_Mode_Type)
        return None
    Elements.append(element)
    
    
def Add_Common_CarCfg_Element(root, element, element_item):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        # if any(item == child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text for item in SDB_Interface_Configuration.Value_Interface_List):
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == element_item:
            CarCfgPkg = child
            break
    # print("element_item",element_item)
    Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    Elements.append(element)
    # if Elements is not None:  
    #     # print("找到INVALIDATION-POLICYS元素。") 
    #     Elements.append(element) 
    #     # 在这里可以处理找到的元素  
    # else:  
    #     print("未找到DATA-ELEMENTS元素。") 
    #     INVALIDATION_POLICYS = ET.Element("{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    #     INVALIDATION_POLICYS.append(element)
    #     CarCfgPkg.append(INVALIDATION_POLICYS)
    #     Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS")


def Add_Common_CarCfg_invalidation_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        # print("CarCfgPkg",child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        # print("element",element.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF").text.split('/')[2])
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == element.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF").text.split('/')[2]:
            CarCfgPkg = child
            
            break
    # print("CarCfgPkg",element.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF").text)  
    Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")
    # print("Elements",Elements,element)
    # Elements.append(element)   
    if Elements is not None:  
        # print("找到INVALIDATION-POLICYS元素。") 
        Elements.append(element) 
        # 在这里可以处理找到的元素  
    else:  
        # print("未找到INVALIDATION-POLICYS元素。") 
        INVALIDATION_POLICYS = ET.Element("{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")
        INVALIDATION_POLICYS.append(element)
        CarCfgPkg.append(INVALIDATION_POLICYS)
        Elements = CarCfgPkg.find("./{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")

    
    
def Add_Geely_sw_connector_element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Elements = GeelyPkg.find("./{http://autosar.org/schema/r4.0}CONNECTORS")
    Elements.append(element)
    
def Add_SDB_sw_connector_element(root,element,ECU_Name):
    ECU_Name = 'ZCUD'
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == ECU_Name:
            GeelyPkg = child
            break
    Elements = GeelyPkg.find("./{http://autosar.org/schema/r4.0}CONNECTORS")
    Elements.append(element)