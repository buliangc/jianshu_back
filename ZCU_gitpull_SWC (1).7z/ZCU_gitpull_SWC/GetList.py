import xml.etree.ElementTree as ET
import Feature
import os
#获得BaseTypes中的datatype列表：
def Get_BaseTypesList(root):
    DataTypeList = []
    AUTOSAR = root                                             #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "BaseTypes":
            BaseTypesPkg = child
            break
    BaseTypesList = BaseTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SW-BASE-TYPE")
    for child in BaseTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList


#获得CompuMethods中的datatype列表：
def Get_CompuMethodsList(root):
    DataTypeList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "CompuMethods":
            BaseTypesPkg = child
            break
    BaseTypesList = BaseTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPU-METHOD")
    for child in BaseTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList

def Get_ImplementationDataTypesList_only(root):
    DataTypeList = []
    AUTOSAR = root                                              #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
            ImplementationDataTypesPkg = child
            break
    ImplementationDataTypesList = ImplementationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in ImplementationDataTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList
        
def Get_DataTypeImplementationList(root):
    DataTypeList = []
    AUTOSAR = root                                              #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeImplementation":
            DataTypeImplementationPkg = child
            break
    DataTypeImplementationList = DataTypeImplementationPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in DataTypeImplementationList:
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList

#获得ImplementationDataTypes中的datatype列表：    
def Get_ImplementationDataTypesList(root):
    DataTypeList = []
    AUTOSAR = root                                              #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ImplementationDataTypes":
            ImplementationDataTypesPkg = child
            break
    ImplementationDataTypesList = ImplementationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in ImplementationDataTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeImplementation":
            DataTypeImplementationPkg = child
            break
    DataTypeImplementationList = DataTypeImplementationPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    for child in DataTypeImplementationList:
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList

# def Get_BaseTypesList(root):
#     DataTypeList = []
#     AUTOSAR = root                                               #最顶层标签AUTOSAR
#     AR_PACKAGES =AUTOSAR[0]
#     for child in AR_PACKAGES:
#         if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "BaseTypes":
#             BaseTypesPkg = child
#             break
#     BaseTypesPkgList = BaseTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SW-BASE-TYPE")
#     for child in BaseTypesPkgList:
#         DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
#     return DataTypeList  
        
#获得ApplicationDataTypes中的datatype列表：
def Get_ApplicationDataTypesList(root):
    DataTypeList = []
    Application_DataTypeList = {}
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "ApplicationDataTypes":
            ApplicationDataTypesPkg = child
            break
    ApplicationDataTypesList = ApplicationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-PRIMITIVE-DATA-TYPE")
    for child in ApplicationDataTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        Application_DataTypeList[child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text]= "APPLICATION-PRIMITIVE-DATA-TYPE"
    ApplicationDataTypesList = ApplicationDataTypesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-RECORD-DATA-TYPE")
    for child in ApplicationDataTypesList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        Application_DataTypeList[child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text]= "APPLICATION-RECORD-DATA-TYPE"
    return DataTypeList,Application_DataTypeList


#获得DataConstrsList中的datatype列表：
def Get_DataConstrsList(root):
    DataTypeList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataConstrs":
            DataConstrsPkg = child
            break
    DataConstrsList = DataConstrsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-CONSTR")
    for child in DataConstrsList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        DataTypeList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return DataTypeList


#获得DataTypeMappings中的datatype列表：
def Get_DataTypeMappingsList(root,DaTaMapping_Ref_Name):
    DataTypeList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    data_mapping_set_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
    for child in data_mapping_set_list:
        if child.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text == DaTaMapping_Ref_Name:
            data_mapping_set_pkg = child
            break
    DataTypeMapList = data_mapping_set_pkg.findall("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    for data_type_child in DataTypeMapList:
        application_data_type_ref = data_type_child.find("./{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF").text
        DataTypeList.append(application_data_type_ref.split("/")[-1])
    return DataTypeList
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataTypeMappings":
    #         DataTypeMappingsPkg = child
    #         break
    # DataTypeMappingsList = DataTypeMappingsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
    # for child in DataTypeMappingsList:
    #     short_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
    #     if short_name.split("DataTypeMappingsSet")[0] == swc or short_name.split("_DataTMappingSet")[0] == swc or short_name.split("DataTMappingSet")[0] == swc or short_name.split("MappingSet")[0] == swc:
    #         DataTypeMapList = child.findall("./{http://autosar.org/schema/r4.0}DATA-TYPE-MAPS/{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    #         for data_type_child in DataTypeMapList:
    #             application_data_type_ref = data_type_child.find("./{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF").text
    #             DataTypeList.append(application_data_type_ref.split("/")[-1])
    

def Get_PortInterfacesList(root):
    PortInterfacesList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        PortInterfacesList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return PortInterfacesList




def Get_CarCfg_List(root,Value_Interface_List):
    CarCfgList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in InterfacessList:
        if any(item == child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text for item in Value_Interface_List):
        # if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "CarCfg":
            CarCfgPkg = child
            
            CarCfg_Elements_List = CarCfgPkg.findall("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS/{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
            for child in CarCfg_Elements_List:
                CarCfgList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return CarCfgList
    
def Get_SDB_DataConstrs_Dict(root):
    SDB_DataConstrs_Dict = {}
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataConstrs":
            DataTypeMappingsPkg = child
            break
    DataTypeMappingsList = DataTypeMappingsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-CONSTR")
    for child in DataTypeMappingsList:
        Short_Name= child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
        SDB_DataConstrs_Dict[Short_Name] = child
    return SDB_DataConstrs_Dict

def Get_SDB_DataConstrs_List(root):
    SDB_DataConstrs_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "DataConstrs":
            DataTypeMappingsPkg = child
            break
    DataTypeMappingsList = DataTypeMappingsPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}DATA-CONSTR")
    for child in DataTypeMappingsList:
        SDB_DataConstrs_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return SDB_DataConstrs_List

def Get_SwComponentType_Sender_Port_List(root):
    SwComponentType_List = []
    Receivertemp_list = root.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE/{http://autosar.org/schema/r4.0}SHORT-NAME")
    for i in Receivertemp_list:
        SwComponentType_List.append(i.text)
    return SwComponentType_List
    # SwComponentType_List = []
    # AUTOSAR = root                                               #最顶层标签AUTOSAR
    # AR_PACKAGES =AUTOSAR[0]
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
    #         SwComponentTypePkg = child
    #         break
    # ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    # for child in ApplicationTypeList:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         ApplicationTypePkg = child
    #         break
    # Ports_List = ApplicationTypePkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    # for child in Ports_List:
    #     # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    #     SwComponentType_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    # return SwComponentType_List


def Get_SwComponentType_Receiver_Port_List(root):
    SwComponentType_List = []
    Receivertemp_list = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE/{http://autosar.org/schema/r4.0}SHORT-NAME")
    for i in Receivertemp_list:
        SwComponentType_List.append(i.text)
    return SwComponentType_List
    # AUTOSAR = root                                               #最顶层标签AUTOSAR
    # AR_PACKAGES =AUTOSAR[0]
    # for child in AR_PACKAGES:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
    #         SwComponentTypePkg = child
    #         break
    # ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    # for child in ApplicationTypeList:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         ApplicationTypePkg = child
    #         break
    # Ports_List = ApplicationTypePkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    # for child in Ports_List:
    #     # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    #     SwComponentType_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    # return SwComponentType_List




def Get_SwComponentType_variable_access_Receiver_Port_List(root,swc,runnable_name):
    SwComponentType_variable_access_Receiver_Port_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        # print(runnable_name)
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        port_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        # print("port_name",port_name)
        SwComponentType_variable_access_Receiver_Port_List.append(port_name)
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        port_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("drparg_", "") 
        # print("port_name",port_name)
        SwComponentType_variable_access_Receiver_Port_List.append(port_name)
    return SwComponentType_variable_access_Receiver_Port_List

def Get_Geely_ReceiverPorts_List(root):
    Ports_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for child in ports_list:
        Ports_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return Ports_List


def Get_Geely_SenderPorts_List(root):
    Ports_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    ports_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for child in ports_list:
        Ports_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return Ports_List

def Get_SwComponentType_variable_access_Sender_Port_List(root,swc,runnable_name):
    SwComponentType_variable_access_Sender_Port_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    # for child in swc_internal_behaviors_list:
    #     if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
    #         swc_internal_behaviorsPkg = child
    #         break
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables_entityPkg = child
            break
    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        port_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "") 
        # print("port_name",port_name)
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        SwComponentType_variable_access_Sender_Port_List.append(port_name)

    variable_access_list = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}DATA-READ-ACCESSS/{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    for child in variable_access_list:
        port_name =  child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.replace("dsp_", "") 
        # print("port_name",port_name)
        # port_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.split("_")[-1]
        SwComponentType_variable_access_Sender_Port_List.append(port_name)
    return SwComponentType_variable_access_Sender_Port_List


def Get_Geely_assembly_sw_connector_list(root):
    connector_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    connectors_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    for child in connectors_list:
        connector_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return connector_List

def Get_Geely_delegation_sw_connector_list(root):
    connector_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    connectors_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    for child in connectors_list:
        connector_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return connector_List

def Get_SDB_assembly_sw_connector_list(root,ECU_Name):
    connector_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == ECU_Name:
            GeelyPkg = child
            break
    connectors_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    for child in connectors_list:
        connector_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return connector_List


def Get_SDB_delegation_sw_connector_list(root,ECU_Name):
    connector_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == ECU_Name:
            GeelyPkg = child
            break
    connectors_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    for child in connectors_list:
        connector_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return connector_List

#获得Common下接口的引用的数据类型是application还是idt
def Get_Common_type_ref(root):
    port_dict = {}
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacePkg = child
            break
    Sender_Receiver_List = PortInterfacePkg.findall(".//{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in Sender_Receiver_List:
        portname = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
        port_dict[portname] = child.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF").get("DEST")
    return port_dict
#获得Common下接口引用的数据类型
def Get_Common_Data_Type(root):
    port_dict = {}
    dataElement_dict = {}
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacePkg = child
            break
    Sender_Receiver_List = PortInterfacePkg.findall(".//{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    for child in Sender_Receiver_List:
        portname = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
        
        elementname = child.find("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS/{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE/{http://autosar.org/schema/r4.0}SHORT-NAME").text
        # print("portname",portname,elementname)
        port_dict[portname] = child.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF").text.split("/")[-1]
        dataElement_dict[portname] = elementname
    return port_dict,dataElement_dict
# #获得Common下接口引用的数据类型
# def Get_Common_Data_Type(root):
#     port_dict = {}
#     AUTOSAR = root                                               #最顶层标签AUTOSAR
#     AR_PACKAGES =AUTOSAR[0]
#     for child in AR_PACKAGES:
#         if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
#             PortInterfacePkg = child
#             break
#     Sender_Receiver_List = PortInterfacePkg.findall(".//{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
#     for child in Sender_Receiver_List:
#         portname = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
#         port_dict[portname] = child.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF").text.split("/")[-1]
#     return port_dict
#获得不同SWC下Datamappings放在那个SWC下的数据
def Get_SWC_DataMapping(swc_filenames):
    datamapping_dict = {}
    for filename in swc_filenames:
        AUTOSAR = Feature.parse_file(filename)
        AR_PACKAGES =AUTOSAR[0]
        data_mapping_set_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-SET")
        for child in data_mapping_set_list:
            short_name = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
            if short_name.endswith("Set") or short_name == "MirrPosnAdjmt":
                if short_name not in datamapping_dict:
                    temp = []
                    temp.append(filename)
                    datamapping_dict[short_name] = temp
                else:
                    datamapping_dict[short_name].append(filename)
    return datamapping_dict

def Get_SWC_Include_DataType(geelycem_swc_dir,SWC_List):

    for SWC_Name in SWC_List:  # 遍历每个文件名（字符串）
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geelycem_swc_dir, "{}.arxml".format(SWC_Name)))
                #获得当前SWC引用哪个SWC的DATa mapping
        Data_Type_Dict = {SWC_Name: []}
        AUTOSAR = SWC_AUTOSAR                                               #最顶层标签AUTOSAR
        AR_PACKAGES =AUTOSAR[0]
        for child in AR_PACKAGES:
            if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
                SwComponentTypePkg = child
                break
        # print(SwComponentTypePkg)

        data_type_ref_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-REF")
        for child in data_type_ref_list:
            datatype_ref_name = child.text.split("/")[-1]
            Data_Type_Dict[SWC_Name].append(datatype_ref_name)

    return Data_Type_Dict
        

# def Get_SWC_Include_DataType(swc_filenames):
#     datamapping_dict = {}
#     for filename in swc_filenames:
#         Data_Type_Dict = {filename: []}
#         AUTOSAR = Feature.parse_file(filename)
#         AR_PACKAGES =AUTOSAR[0]
#         data_type_ref_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-REF")
#         for child in data_type_ref_list:
#             datatype_ref_name = child.text.split("/")[-1]
#             Data_Type_Dict[swc_filenames].append(datatype_ref_name)
#     return Data_Type_Dict
#获得当前SWC引用哪个SWC的DATa mapping
def Get_SWC_DataMapping_Ref(root):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    # print(SwComponentTypePkg)

    data_type_mapping_ref_list = SwComponentTypePkg.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-REF")
    for child in data_type_mapping_ref_list:
        short_name = child.text.split("/")[-1]
        # print("short_name",short_name)
        # print(child.text.split("/")[-2])
        # print(child.text.split("/")[-1])
        # print(child.text.split("/")[-1].endswith("Set"))
        if (child.text.split("/")[-2] == "DataTypeMappings" or child.text.split("/")[-2] == "SwComponentType")and (child.text.split("/")[-1].endswith("Set") or child.text.split("/")[-1] == "MirrPosnAdjmt") :
            datamapping_ref_name = short_name+"_"+child.text.split("/")[-2]
            # print("datamapping_ref_name",datamapping_ref_name)
    return datamapping_ref_name

def Get_SWC_DataTYPE_Ref(root,swc_filenames):
    Data_Type_Dict = {swc_filenames: []}
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    # print(SwComponentTypePkg)

    data_type_ref_list = AR_PACKAGES.findall(".//{http://autosar.org/schema/r4.0}DATA-TYPE-REF")
    for child in data_type_ref_list:
        datatype_ref_name = child.text.split("/")[-1]
        Data_Type_Dict[swc_filenames].append(datatype_ref_name)

        # print("datatype_ref_name",child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        # print("short_name",datatype_ref_name)
        # print(child.text.split("/")[-2])
        # print(child.text.split("/")[-1])
        # # print(child.text.split("/")[-1].endswith("Set"))
        # # if (child.text.split("/")[-2] == "DataTypeMappings" or child.text.split("/")[-2] == "SwComponentType")and (child.text.split("/")[-1].endswith("Set") or child.text.split("/")[-1] == "MirrPosnAdjmt") :
        # #     datamapping_ref_name = short_name+"_"+child.text.split("/")[-2]
        #     # print("datamapping_ref_name",datamapping_ref_name)
    return Data_Type_Dict

def Get_SWC_Receive_Runnable_Entity(root):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ruannables_list = SwComponentTypePkg.findall(".//{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in ruannables_list:
        Elements = child.find("./{http://autosar.org/schema/r4.0}DATA-RECEIVE-POINT-BY-ARGUMENTS")
        if Elements is None:
            # print("NO find DATA-RECEIVE-POINT-BY-ARGUMENTS 。")
            continue
        
        temp = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.lower()
        # print(temp)
        if temp.endswith("step"):
            # print("find RUNNABLE-ENTITY" ,child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            return child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
        # if temp.startswith("RUN_") and temp.endswith("ms"):
        if temp.endswith("ms"):
            return child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
            

def Get_SWC_Sender_Runnable_Entity(root):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ruannables_list = SwComponentTypePkg.findall(".//{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in ruannables_list:
        Elements = child.find("./{http://autosar.org/schema/r4.0}DATA-SEND-POINTS")
        if Elements is None:
            # print("NO find DATA-RECEIVE-POINT-BY-ARGUMENTS 。")
            continue
        
        temp = child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text.lower()
        if temp.endswith("step"):
            # print("find RUNNABLE-ENTITY" ,child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            return child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text    
        if temp.endswith("ms"):
            return child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
# Swc_Filenames = os.listdir(os.path.join(os.getcwd(), "SWC"))
#root = Feature.parse_file(r"SWC/VisyMechWiprCtrl.arxml")
# portdict = Get_SWC_DataMapping(Swc_Filenames)
# print(portdict)
# print("LockgTrDoorCtrl_DataTMappingSet_DataTypeMappings".split("_DataTypeMappings")[-2])
# list1 = root.findall(".//{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR/{http://autosar.org/schema/r4.0}PROVIDER-IREF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
# list2 = root.findall(".//{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR/{http://autosar.org/schema/r4.0}PROVIDER-IREF/{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")

def Get_CarCfg_SHORT_NAME_List(root,Value_Interface_List):
    CarCfgList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    # print("Value_Interface_List",Value_Interface_List)
    for child in InterfacessList:
        # print("12231",child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        # if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text  == "DiagCtrlSubstLockingWrpr":
        #     print("12231",child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        if any(item == child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text for item in Value_Interface_List):
        # if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "CarCfg":
            CarCfgPkg = child
            CarCfgList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
            
    # CarCfg_Elements_List = CarCfgPkg.findall("./{http://autosar.org/schema/r4.0}DATA-ELEMENTS/{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    # for child in CarCfg_Elements_List:
        
    return CarCfgList



def Get_SwComponentType_Receiver_Port_Interface_List(root):
    SwComponentType_List = []
    
    # Receivertemp_list = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE/{http://autosar.org/schema/r4.0}SHORT-NAME")
    # print("Receivertemp_list",Receivertemp_list.text,"\n")
    # SwComponentType_List1 = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE/{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
    RPort_list = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for i in RPort_list:
        short_name = i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text 
        interface_name = i.find("./{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF").text.split("/")[-1]
        SwComponentType_List.append({"short_name":short_name,"interface_name":interface_name})

    return SwComponentType_List

    
def Get_SwComponentType_Sender_Port_Interface_List(root):
    SwComponentType_List = []
    PPort_list = root.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for i in PPort_list:
        short_name = i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text 
        interface_name = i.find("./{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF").text.split("/")[-1]
        SwComponentType_List.append({"short_name":short_name,"interface_name":interface_name})

        # SwComponentType_List.append(i.text)
    return SwComponentType_List
