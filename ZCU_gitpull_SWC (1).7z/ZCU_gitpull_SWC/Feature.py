
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
import xml.dom.minidom as md

#解析文件
def parse_file(filepath):
    try:
        tree = ET.parse(filepath)
    except ET.ParseError as e:
        print(f"XML解析错误：{e}")
    AUTOSAR = tree.getroot()                                               #最顶层标签AUTOSAR
    return AUTOSAR
#判断是否含有最外层的目录：
def contain_package(root, package):
    AUTOSAR = root                                             #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == package:
            return True
    return False   


##保存文件
def save_file(root, OutFile):
    ET.register_namespace('', "http://autosar.org/schema/r4.0")
    tree = ET.ElementTree(root)
    tree.write(OutFile, encoding='utf-8', short_empty_elements=False)
    with open(OutFile, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        lines.insert(0, '<?xml version="1.0" encoding="UTF-8"?>\n')
        s = ''.join(lines)
    with open(OutFile, 'w', encoding='utf-8') as f:
        f.write(s)  


def convert_to_datetime():
    current_time = datetime.now()
    tz = timezone(timedelta(hours=8))
    formatted_time = current_time.replace(tzinfo=timezone.utc).astimezone(tz).strftime('%Y-%m-%dT%H:%M:%S%z')
    formatted_time = formatted_time[:-2] + ':' + formatted_time[-2:]
    return formatted_time

def Interface_Data_Dype(Interface_Data_Dype_Dict,Data_Tpye_Dict_List):
    for Data_Tpye_Dict in Data_Tpye_Dict_List:
        if Data_Tpye_Dict["Type"] == "VALUE":
            if Data_Tpye_Dict["Value_Type"] == "IDENTICAL":
                temp = {}
                temp["SWC"] = Data_Tpye_Dict["SWC"]
                temp["Data_Type"] = Data_Tpye_Dict["Data_Type"]
                temp["Type"] = Data_Tpye_Dict["Type"]
                temp["Value_Type"] = Data_Tpye_Dict["Value_Type"]
                temp["Data_Type_Name"] = Data_Tpye_Dict["Data_Type_Name"]
                Interface_Data_Dype_Dict[Data_Tpye_Dict["Data_Type"]] = temp
            elif Data_Tpye_Dict["Value_Type"] == "LINEAR":
                temp = {}
                temp["SWC"] = Data_Tpye_Dict["SWC"]
                temp["Data_Type"] = Data_Tpye_Dict["Data_Type"]
                temp["Type"] = Data_Tpye_Dict["Type"]
                temp["Value_Type"] = Data_Tpye_Dict["Value_Type"]
                temp["Size"] = Data_Tpye_Dict["Size"]
                temp["Min"] = Data_Tpye_Dict["Min"]
                temp["Max"] = Data_Tpye_Dict["Max"]
                temp["Factor"] = Data_Tpye_Dict["Factor"]
                temp["Offset"] = Data_Tpye_Dict["Offset"]
                temp["Unit"] = Data_Tpye_Dict["Unit"]
                Interface_Data_Dype_Dict[Data_Tpye_Dict["Data_Type"]] = temp
            elif Data_Tpye_Dict["Value_Type"] == "TEXTTABLE":
                Interface_Data_Dype_Dict[Data_Tpye_Dict["Data_Type"]] = Data_Tpye_Dict["Constant_List"]
        elif Data_Tpye_Dict["Type"] == "STRUCTURE":
            Interface_Data_Dype_Dict[Data_Tpye_Dict["Data_Type"]] = Data_Tpye_Dict["Struct_List"]
        elif Data_Tpye_Dict["Type"] == "ARRAY":
            pass
    return Interface_Data_Dype_Dict

#获得初始值所需数据类型的类型
def InitValue_DataType_Dict(InitValue_DataType_Dict,Data_Tpye_Dict_List):
    for Data_Tpye_Dict in Data_Tpye_Dict_List:
        InitValue_DataType_Dict[Data_Tpye_Dict["Data_Type"]] = Data_Tpye_Dict["Type"]
    return InitValue_DataType_Dict


#用来处理接口创建是excel表中的的初始值，将其转换为列表
def Convert_InitValue(s):
    result = []  # 用于存储最终结果的列表
    temp = ''  # 用于暂存当前数字的字符串
    stack = []  # 用于模拟堆栈的列表，存储外层大括号的结果

    for char in s:
        if char.isdigit():
            temp += char  # 如果字符是数字，则将其添加到暂存的字符串中
        elif char == ',':
            if temp:
                result.append(temp)  # 如果遇到逗号，将暂存的字符串转换为整数并添加到结果列表中
                temp = ''  # 清空暂存的字符串
        elif char == '{':
            stack.append(result)  # 如果遇到左大括号，将当前结果列表存入堆栈中
            result = []  # 创建一个新的空列表来存储内部大括号中的内容
        elif char == '}':
            if temp:
                result.append(temp)  # 如果遇到右大括号之前还有暂存的字符串，将其转换为整数并添加到结果列表中
                temp = ''  # 清空暂存的字符串
            if result:
                stack[-1].append(result)  # 将内部列表添加到外部列表中
                result = stack.pop()  # 将外部列表恢复为之前的状态
    if temp:
        result.append(temp)  # 将最后一个暂存的字符串转换为整数并添加到结果列表中
    return result[0]

