import xml.etree.ElementTree as ET
import xml.dom.minidom as md
import Feature
import uuid
import re 

def Process_CompuMethods(Data_Tpye_Dict):
    compu = ET.Element("{http://autosar.org/schema/r4.0}COMPU-METHOD")
    compu.set('T',str(Feature.convert_to_datetime()))
    compu.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(compu,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Data_Tpye_Dict["Data_Type"]
    category = ET.SubElement(compu,"{http://autosar.org/schema/r4.0}CATEGORY")
    category.text = Data_Tpye_Dict["Value_Type"]
    unit_ref = ET.SubElement(compu,"{http://autosar.org/schema/r4.0}UNIT-REF")
    unit_ref.set("DEST", "UNIT")
    unit_ref.text = "/Units/NoUnit"
    # unit_ref.text = "/Units/{}".format(Data_Tpye_Dict["Unit"])
    compu_internal = ET.SubElement(compu,"{http://autosar.org/schema/r4.0}COMPU-INTERNAL-TO-PHYS")
    compu_internal.set('T',str(Feature.convert_to_datetime()))
    compu_scales = ET.SubElement(compu_internal,"{http://autosar.org/schema/r4.0}COMPU-SCALES")
    if Data_Tpye_Dict["Value_Type"] == "TEXTTABLE":
        for constant in Data_Tpye_Dict["Constant_List"]:
            compu_scale = ET.SubElement(compu_scales, "{http://autosar.org/schema/r4.0}COMPU-SCALE")
            compu_scale.set('T',str(Feature.convert_to_datetime()))
            lower_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}LOWER-LIMIT")
            lower_limit.text = str(constant["Min"])
            upper_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}UPPER-LIMIT")
            upper_limit.text = str(constant["Max"])
            compu_const = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}COMPU-CONST")
            vt = ET.SubElement(compu_const, "{http://autosar.org/schema/r4.0}VT")
            vt.text = str(constant["Constant"])
    elif Data_Tpye_Dict["Value_Type"] == "LINEAR":
        compu_scale = ET.SubElement(compu_scales, "{http://autosar.org/schema/r4.0}COMPU-SCALE")
        compu_scale.set('T',str(Feature.convert_to_datetime()))
        short_label = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}SHORT-LABEL")
        short_label.text = Data_Tpye_Dict["Data_Type"]
        lower_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}LOWER-LIMIT")
        lower_limit.set('T',str(Feature.convert_to_datetime()))
        lower_limit.set("INTERVAL-TYPE", "CLOSED")
        lower_limit.text = str(Data_Tpye_Dict["Min"])
        upper_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}UPPER-LIMIT")
        upper_limit.set('T',str(Feature.convert_to_datetime()))
        upper_limit.set("INTERVAL-TYPE", "CLOSED")
        upper_limit.text = str(Data_Tpye_Dict["Max"])
        compu_rational_coeffs = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}COMPU-RATIONAL-COEFFS")
        compu_numerator = ET.SubElement(compu_rational_coeffs, "{http://autosar.org/schema/r4.0}COMPU-NUMERATOR")
        v = ET.SubElement(compu_numerator, "{http://autosar.org/schema/r4.0}V")
        v.set('T',str(Feature.convert_to_datetime()))
        v.text = str(Data_Tpye_Dict["Offset"])
        v1 = ET.SubElement(compu_numerator, "{http://autosar.org/schema/r4.0}V")
        v1.set('T',str(Feature.convert_to_datetime()))
        v1.text = str(Data_Tpye_Dict["Factor"])
        compu_denominator = ET.SubElement(compu_rational_coeffs, "{http://autosar.org/schema/r4.0}COMPU-DENOMINATOR")
        v2 = ET.SubElement(compu_denominator, "{http://autosar.org/schema/r4.0}V")
        v2.set('T',str(Feature.convert_to_datetime()))
        v2.text = "1.0"
    elif Data_Tpye_Dict["Value_Type"] == "IDENTICAL":
        compu_scale = ET.SubElement(compu_scales, "{http://autosar.org/schema/r4.0}COMPU-SCALE")
        compu_scale.set('T',str(Feature.convert_to_datetime()))
        lower_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}LOWER-LIMIT")
        lower_limit.text = ""
        upper_limit = ET.SubElement(compu_scale, "{http://autosar.org/schema/r4.0}UPPER-LIMIT")
        upper_limit.text = ""
    return compu


def Process_DataConstrs(Data_Tpye_Dict):
    data_constr = ET.Element("{http://autosar.org/schema/r4.0}DATA-CONSTR")
    data_constr.set('T',str(Feature.convert_to_datetime()))
    data_constr.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(data_constr,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Data_Tpye_Dict["Data_Type"]
    data_constr_rules = ET.SubElement(data_constr,"{http://autosar.org/schema/r4.0}DATA_CONSTR_RULES")
    data_constr_rule = ET.SubElement(data_constr_rules,"{http://autosar.org/schema/r4.0}DATA_CONSTR_RULE")
    phys_constrs = ET.SubElement(data_constr_rule, "{http://autosar.org/schema/r4.0}PHYS-CONSTRS")
    lower_limit = ET.SubElement(phys_constrs,"{http://autosar.org/schema/r4.0}LOWER-LIMIT")
    lower_limit.set("INTERVAL-TYPE","CLOSED")
    lower_limit.text = "0"
    upper_limit = ET.SubElement(phys_constrs,"{http://autosar.org/schema/r4.0}UPPER-LIMIT")
    upper_limit.set("INTERVAL-TYPE","CLOSED")
    upper_limit.text = "2"
    internal_constrs = ET.SubElement(data_constr_rule,"{http://autosar.org/schema/r4.0}INTERNAL-CONSTRS")
    lower_limit = ET.SubElement(internal_constrs,"{http://autosar.org/schema/r4.0}LOWER-LIMIT")
    lower_limit.set("INTERVAL-TYPE","CLOSED")
    lower_limit.text = "0"
    upper_limit = ET.SubElement(internal_constrs,"{http://autosar.org/schema/r4.0}UPPER-LIMIT")
    upper_limit.set("INTERVAL-TYPE","CLOSED")
    upper_limit.text = "2"
    return data_constr


def Process_BaseTypes(Data_Tpye_Dict):
    sw_base_type = ET.Element("{http://autosar.org/schema/r4.0}SW-BASE-TYPE")
    sw_base_type.set("UUID",str(uuid.uuid4()))
    short_name= ET.SubElement(sw_base_type,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Data_Tpye_Dict['Data_Type']
    category = ET.SubElement(sw_base_type,"{http://autosar.org/schema/r4.0}CATEGORY")
    category.text = "FIXED_LENGTH"
    base_type_size = ET.SubElement(sw_base_type,"{http://autosar.org/schema/r4.0}BASE-TYPE-SIZE")
    base_type_encoding = ET.SubElement(sw_base_type,"{http://autosar.org/schema/r4.0}BASE-TYPE-ENCODING")
    base_type_encoding.text = "NONE"
    native_declaration = ET.SubElement(sw_base_type,"{http://autosar.org/schema/r4.0}NATIVE-DECLARATION")

    
    if Data_Tpye_Dict['Value_Type'] == "LINEAR":
        base_type_size.text = str(Data_Tpye_Dict['Size'])
        native_declaration.text = str(Data_Tpye_Dict['Native Declaration'])
        # print("native_declaration.text",Data_Tpye_Dict['Native Declaration'],short_name.text)
        # print("111",native_declaration.text)
    elif Data_Tpye_Dict['Value_Type'] == "TEXTTABLE":
        base_type_size.text = str(len(Data_Tpye_Dict["Constant_List"]))
    elif Data_Tpye_Dict['Value_Type'] == "IDENTICAL":
        if re.search(r'\d$', Data_Tpye_Dict['Data_Type_Name']):
            num = re.findall(r'\d+', Data_Tpye_Dict['Data_Type_Name'])[0]
            base_type_size.text = str(num)
        else:
            base_type_size.text = "8"
    
    if native_declaration.text == "int8" or native_declaration.text == "Int8":
        base_type_size.text = "8"
        base_type_encoding.text = "2C"
        native_declaration.text = "signed char"

    elif native_declaration.text == "int16"or native_declaration.text == "Int16":
        base_type_size.text = "16"
        base_type_encoding.text = "2C"
        native_declaration.text = "signed short"

    elif native_declaration.text == "int32" or native_declaration.text == "Int32":
        base_type_size.text = "32"
        base_type_encoding.text = "2C"
        native_declaration.text = "signed long"

    elif native_declaration.text == "uint8" or native_declaration.text == "UInt8":
        base_type_size.text = "8"
        native_declaration.text = "signed char"

    elif native_declaration.text == "uint16" or native_declaration.text == "UInt16":
        base_type_size.text = "16"
        native_declaration.text = "unsigned short"

    elif native_declaration.text == "uint32"or native_declaration.text == "UInt32":
        base_type_size.text = "32"
        native_declaration.text = "unsigned long"

    elif native_declaration.text == "uint64"or native_declaration.text == "UInt64":
        base_type_size.text = "64"
        native_declaration.text = "uint64"

    elif native_declaration.text == "int64"or native_declaration.text == "Int64":
        base_type_size.text = "64"
        native_declaration.text = "int64"
        
    elif native_declaration.text == "float"or native_declaration.text == "Float":
        base_type_size.text = "32"
        base_type_encoding.text = "IEEE745"
        native_declaration.text = "float"
    else:
        if int(base_type_size.text) <= 8:
            base_type_size.text = "8"
            native_declaration.text = "unsigned char"
        elif int(base_type_size.text) <= 16 and int(base_type_size.text) > 8:
            base_type_size.text = "16"
            native_declaration.text = "unsigned short"
        elif int(base_type_size.text) <= 32 and int(base_type_size.text) > 16:
            base_type_size.text = "32"
            native_declaration.text = "unsigned long"
        else:
            base_type_size.text = "64"
            native_declaration.text = "uint64"
    return sw_base_type
    
    
def Process_ImplementationDataTypes(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
    if Data_Tpye_Dict["Type"] == "VALUE":
        implementation_data_type = ET.Element("{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
        implementation_data_type.set('T',str(Feature.convert_to_datetime()))
        implementation_data_type.set("UUID",str(uuid.uuid4()))
        short_name = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SHORT-NAME")
        short_name.text = Data_Tpye_Dict["Data_Type"]
        category = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}CATEGORY")
        category.text = Data_Tpye_Dict["Type"]
        sw_data_def_props = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
        sw_data_def_props.set('T',str(Feature.convert_to_datetime()))
        sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
        sw_data_def_props_contitional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
        sw_data_def_props_contitional.set('T',str(Feature.convert_to_datetime()))
        base_type_ref = ET.SubElement(sw_data_def_props_contitional, "{http://autosar.org/schema/r4.0}BASE-TYPE-REF")
        base_type_ref.set("DEST", "SW-BASE-TYPE")
        base_type_ref.text = "/BaseTypes/{}".format(Data_Tpye_Dict["Data_Type"])
        compu_method_ref = ET.SubElement(sw_data_def_props_contitional, "{http://autosar.org/schema/r4.0}COMPU-METHOD-REF")
        compu_method_ref.set("DEST", "COMPU-METHOD")
        compu_method_ref.text = "/CompuMethods/{}".format(Data_Tpye_Dict["Data_Type"])
        # data_constr_ref = ET.SubElement(sw_data_def_props_contitional, "{http://autosar.org/schema/r4.0}DATA-CONSTR-REF")
        # data_constr_ref.set("DEST", "DATA-CONSTR")
        # data_constr_ref.text = "/DataConstrs/{}".format(Data_Tpye_Dict["Data_Type"])
    elif Data_Tpye_Dict["Type"] == "STRUCTURE":
        implementation_data_type = ET.Element("{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
        implementation_data_type.set('T',str(Feature.convert_to_datetime()))
        implementation_data_type.set("UUID",str(uuid.uuid4()))
        short_name = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SHORT-NAME")
        short_name.text = Data_Tpye_Dict["Data_Type"]
        category = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}CATEGORY")
        category.text = Data_Tpye_Dict["Type"]
        sw_data_def_props = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
        sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
        sw_data_def_props_contitional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
        is_struct_with_optional_element = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}IS-STRUCT-WITH-OPTIONAL-ELEMENT")
        is_struct_with_optional_element.text = "false"
        sub_elements = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SUB-ELEMENTS")
        for struct in Data_Tpye_Dict["Struct_List"]:
            implementation_data_type_element = ET.SubElement(sub_elements, "{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-ELEMENT")
            implementation_data_type_element.set('T',str(Feature.convert_to_datetime()))
            implementation_data_type_element.set("UUID",str(uuid.uuid4()))
            short_name = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}SHORT-NAME")
            short_name.text = struct["Record_Data_element"]
            category = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}CATEGORY")
            category.text = "TYPE_REFERENCE"
            sw_data_def_props = ET.SubElement(implementation_data_type_element,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
            sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
            sw_data_def_props_contitional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
            sw_data_def_props_contitional.set('T',str(Feature.convert_to_datetime()))
            implementation_data_type_ref = ET.SubElement(sw_data_def_props_contitional, "{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
            # if struct["Data_Type_Name"] in ApplicationDataTypes_Data_type_List:
            #     implementation_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
            #     implementation_data_type_ref.text = "/ApplicationDataTypes/{}".format(struct["Data_Type_Name"])
            # # if struct["Data_Type_Name"] in ImplementationDataTypes_Data_type_List:
            # else:
            if struct["Data_Type_Name"] in DataTypeImplementation_Data_type_List:
                implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                implementation_data_type_ref.text = "/DataTypeImplementation/{}".format(struct["Data_Type_Name"])
            else:
                implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                implementation_data_type_ref.text = "/ImplementationDataTypes/{}".format(struct["Data_Type_Name"])
            
            # else:
            #     print("数据类新未定义！",struct["Data_Type_Name"])       
    elif Data_Tpye_Dict["Type"] == "ARRAY":
        implementation_data_type = ET.Element("{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
        implementation_data_type.set('T',str(Feature.convert_to_datetime()))
        implementation_data_type.set("UUID",str(uuid.uuid4()))
        short_name = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SHORT-NAME")
        short_name.text = "rt_Array_{}_{}".format(Data_Tpye_Dict["Data_Type"], str(Data_Tpye_Dict["Size"]))
        category = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}CATEGORY")
        category.text = Data_Tpye_Dict["Type"]
        implementation_data_type_element = ET.SubElement(sub_elements, "{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-ELEMENT")
        implementation_data_type_element.set('T',str(Feature.convert_to_datetime()))
        implementation_data_type_element.set("UUID",str(uuid.uuid4()))
        short_name = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}SHORT-NAME")
        short_name.text = "rt_Array_{}_{}".format(Data_Tpye_Dict["Data_Type"], str(Data_Tpye_Dict["Size"]))
        category = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}CATEGORY")
        category.text = "TYPE_REFERENCE"
        array_size = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}ARRAY-SIZE")
        array_size.text = str(Data_Tpye_Dict["Size"])
        array_size_semantics = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}ARRAY-SIZE-SEMANTICS")
        array_size_semantics.text = "FIXED-SIZE"
        sw_data_def_props = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
        sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
        sw_data_def_props_contitional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
        sw_data_def_props_contitional.set('T', str(Feature.convert_to_datetime()))
        implementation_data_type_ref = ET.SubElement(sw_data_def_props_contitional, "{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
        if struct["Data_Type_Name"] in ApplicationDataTypes_Data_type_List:
            implementation_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
            implementation_data_type_ref.text = "/ApplicationDataTypes/{}".format(struct["Data_Type_Name"])
        # if struct["Data_Type_Name"] in ImplementationDataTypes_Data_type_List:
        else:
            if struct["Data_Type_Name"] in DataTypeImplementation_Data_type_List:
                implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                implementation_data_type_ref.text = "/DataTypeImplementation/{}".format(struct["Data_Type_Name"])
            else:
                implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                implementation_data_type_ref.text = "/ImplementationDataTypes/{}".format(struct["Data_Type_Name"])
        
        # else:
        #     print("数据类新未定义！",struct["Data_Type_Name"])
    return implementation_data_type


def Process_ImplementationDataTypes_Array(Array_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
    implementation_data_type = ET.Element("{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
    implementation_data_type.set('T',str(Feature.convert_to_datetime()))
    implementation_data_type.set("UUID",str(uuid.uuid4()))
    short_name = ET.SubElement(implementation_data_type,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "rt_Array_{}_{}".format(Array_Dict["Data_Type"], str(Array_Dict["Size"]))
    category = ET.SubElement(implementation_data_type, "{http://autosar.org/schema/r4.0}CATEGORY")
    category.text = "ARRAY"
    sub_elements = ET.SubElement(implementation_data_type, "{http://autosar.org/schema/r4.0}SUB-ELEMENTS")
    implementation_data_type_element = ET.SubElement(sub_elements, "{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-ELEMENT")
    implementation_data_type_element.set('T',str(Feature.convert_to_datetime()))
    implementation_data_type_element.set("UUID",str(uuid.uuid4()))
    short_name = ET.SubElement(implementation_data_type_element,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "rt_Array_{}_{}".format(Array_Dict["Data_Type"], str(Array_Dict["Size"]))
    category = ET.SubElement(implementation_data_type_element, "{http://autosar.org/schema/r4.0}CATEGORY")
    category.text = "TYPE_REFERENCE"
    array_size = ET.SubElement(implementation_data_type_element,"{http://autosar.org/schema/r4.0}ARRAY-SIZE")
    array_size.text = str(Array_Dict["Size"])
    array_size_semantics = ET.SubElement(implementation_data_type_element,"{http://autosar.org/schema/r4.0}ARRAY-SIZE-SEMANTICS")
    array_size_semantics.text = "FIXED-SIZE"
    sw_data_def_props = ET.SubElement(implementation_data_type_element,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    sw_data_def_props_conditional = ET.SubElement(sw_data_def_props_variants,"{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    sw_data_def_props_conditional.set('T',str(Feature.convert_to_datetime()))
    implementation_data_type_ref = ET.SubElement(sw_data_def_props_conditional,"{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
    if Array_Dict["Data_Type"] in ImplementationDataTypes_Data_type_List:
        if Array_Dict["Data_Type"] in DataTypeImplementation_Data_type_List:
            implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE-REF")
            implementation_data_type_ref.text = "/DataTypeImplementation/{}".format(Array_Dict["Data_Type"])
        else :
            implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE-REF")
            implementation_data_type_ref.text = "/ImplementationDataTypes/{}".format(Array_Dict["Data_Type"])
    elif Array_Dict["Data_Type"] in ApplicationDataTypes_Data_type_List:
        implementation_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        implementation_data_type_ref.text = "/ApplicationDataTypes/{}".format(Array_Dict["Data_Type"])
    return implementation_data_type
 
            
            
def Process_Include_DataType(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList):

    include_data_type = ET.Element("{http://autosar.org/schema/r4.0}DATA-TYPE-REF")
    if Data_Tpye_Dict["Data_Type"] in DataTypeImplementation_Data_type_List:
        include_data_type.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        include_data_type.text = "/DataTypeImplementation/{}".format(Data_Tpye_Dict["Data_Type"])
    else :
        include_data_type.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        include_data_type.text = "/ImplementationDataTypes/{}".format(Data_Tpye_Dict["Data_Type"])

    return include_data_type

def Process_DataTypeMappings(Data_Tpye_Dict, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList):
    data_type_map = ET.Element("{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    data_type_map.set('T',str(Feature.convert_to_datetime()))
    applicttion_data_type_ref = ET.SubElement(data_type_map,"{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
    # print("Application_DataTypeList1111_Common",Application_DataTypeList_Common)
    applicttion_data_type_ref.set("DEST", Application_DataTypeList[Data_Tpye_Dict["Data_Type"]])
    # print("Application_DataTypeList1111_Common",Application_DataTypeList[Data_Tpye_Dict["Data_Type"]],Data_Tpye_Dict["Data_Type"])
    applicttion_data_type_ref.text = "/ApplicationDataTypes/{}".format(Data_Tpye_Dict["Data_Type"])
    implementation_data_type_ref = ET.SubElement(data_type_map,"{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
    # if Data_Tpye_Dict["Data_Type"] in ApplicationDataTypes_Data_type_List:
    #     implementation_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    #     implementation_data_type_ref.text = "/ApplicationDataTypes/{}".format(Data_Tpye_Dict["Data_Type"])
    # if Data_Tpye_Dict["Data_Type"] in ImplementationDataTypes_Data_type_List:
    if Data_Tpye_Dict["Data_Type"] in DataTypeImplementation_Data_type_List:
        implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        implementation_data_type_ref.text = "/DataTypeImplementation/{}".format(Data_Tpye_Dict["Data_Type"])
    else :
        implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        implementation_data_type_ref.text = "/ImplementationDataTypes/{}".format(Data_Tpye_Dict["Data_Type"])
    
    # else:
    #     print("数据类型未定义！")
    return data_type_map


def Process_DataTypeMappings_Array(Array_Name, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
    data_type_map = ET.Element("{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
    data_type_map.set('T',str(Feature.convert_to_datetime()))
    applicttion_data_type_ref = ET.SubElement(data_type_map,"{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
    applicttion_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    applicttion_data_type_ref.text = "/ApplicationDataTypes/{}".format(Array_Name)
    implementation_data_type_ref = ET.SubElement(data_type_map,"{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
    # if Array_Name in ApplicationDataTypes_Data_type_List:
    #     implementation_data_type_ref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    #     implementation_data_type_ref.text = "/ApplicationDataTypes/{}".format(Array_Name)
    # if Array_Name in ImplementationDataTypes_Data_type_List:
    # else:
    if Array_Name in DataTypeImplementation_Data_type_List:
        implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        implementation_data_type_ref.text = "/DataTypeImplementation/{}".format(Array_Name)
    else:
        implementation_data_type_ref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
        implementation_data_type_ref.text = "/ImplementationDataTypes/{}".format(Array_Name)
    
    # else:
    #     print("数据类型未定义！")    
    return data_type_map


def Process_DataTypeMappings_Top():
    ar_package = ET.Element("{http://autosar.org/schema/r4.0}AR-PACKAGE")
    ar_package.set('T',str(Feature.convert_to_datetime()))
    ar_package.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(ar_package, "{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "DataTypeMappings"
    ET.SubElement(ar_package, "{http://autosar.org/schema/r4.0}ELEMENTS")
    return ar_package


def Process_PortInterfaces(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList):
    sender_receiver_interface = ET.Element("{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    sender_receiver_interface.set('T',str(Feature.convert_to_datetime()))
    sender_receiver_interface.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port["Interface"]
    is_service = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}IS-SERVICE")
    is_service.text = "false"
    data_elements = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    variable_data_prorotype = ET.SubElement(data_elements, "{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    variable_data_prorotype.set('T',str(Feature.convert_to_datetime()))
    variable_data_prorotype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_data_prorotype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port["Element"]
    # print("Receiver_Port", Receiver_Port)
    sw_data_def_props = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    type_tref = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}TYPE-TREF")
    # if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
    #     type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    #     type_tref.text = "/ApplicationDataTypes/{}".format(Receiver_Port["Data_Type"])
    # # if Receiver_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
    # else:
    #     if Receiver_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/DataTypeImplementation/{}".format(Receiver_Port["Data_Type"])
    #     else :
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/ImplementationDataTypes/{}".format(Receiver_Port["Data_Type"])
    
    if Receiver_Port["Data_Type_Property"] == "Array":
        # print("Receiver_Port", Receiver_Port)
        # print("Size","rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"])))
        if "rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))  in ApplicationDataTypes_Data_type_List:
            # print("Receiver_Port1", Receiver_Port)
            type_tref.set("DEST", Application_DataTypeList[Receiver_Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
        else:
            if "rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))  in DataTypeImplementation_Data_type_List:
                # print("Receiver_Port2", Receiver_Port)
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
            else :
                # print("Receiver_Port3", Receiver_Port)
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
        # type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        # type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
    else:
        if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
            type_tref.set("DEST", Application_DataTypeList[Receiver_Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/{}".format(Receiver_Port["Data_Type"])
        # if Receiver_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
        
        else:
            if Receiver_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/{}".format(Receiver_Port["Data_Type"])
            else :
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/{}".format(Receiver_Port["Data_Type"])


    # if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List and Receiver_Port["Data_Type_Property"] != "Array":
    #     type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    #     type_tref.text = "/ApplicationDataTypes/{}".format(Receiver_Port["Data_Type"])
    # # if Receiver_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
    # elif Receiver_Port["Data_Type_Property"] == "Array":
    #     if "rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"])) in DataTypeImplementation_Data_type_List:
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/DataTypeImplementation/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
    #     else :
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
    # else:
    #     if Receiver_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/DataTypeImplementation/{}".format(Receiver_Port["Data_Type"])
    #     else :
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/ImplementationDataTypes/{}".format(Receiver_Port["Data_Type"])








    return sender_receiver_interface



def Process_PortInterfaces_Sender_Port(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList):
    sender_receiver_interface = ET.Element("{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    sender_receiver_interface.set('T',str(Feature.convert_to_datetime()))
    sender_receiver_interface.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Interface"]
    is_service = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}IS-SERVICE")
    is_service.text = "false"
    data_elements = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    variable_data_prorotype = ET.SubElement(data_elements, "{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    variable_data_prorotype.set('T',str(Feature.convert_to_datetime()))
    variable_data_prorotype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_data_prorotype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Element"]
    sw_data_def_props = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    type_tref = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}TYPE-TREF")
    if Sender_Port["Interface"] == "BlockOffsetWriteChdLockDrvReStsValue":
        print("test",Sender_Port["Data_Type_Property"],Sender_Port["Data_Type"],Sender_Port["Size"],Sender_Port["Interface"])
    if Sender_Port["Data_Type_Property"] == "Array":
        if "rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"])) in ApplicationDataTypes_Data_type_List:
            type_tref.set("DEST",Application_DataTypeList[Sender_Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"]))
        # if Sender_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
        else:
            if "rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"])) in DataTypeImplementation_Data_type_List:
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"]))
            else :
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"]))
        # type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        # type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Sender_Port["Data_Type"], str(Sender_Port["Size"]))
    else:
        if Sender_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
            type_tref.set("DEST",Application_DataTypeList[Sender_Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/{}".format(Sender_Port["Data_Type"])
        # if Sender_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
        else:
            if Sender_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/{}".format(Sender_Port["Data_Type"])
            else :
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/{}".format(Sender_Port["Data_Type"])
    
    # else:
    #     print("数据类新未定义！",Sender_Port["Data_Type"])
    return sender_receiver_interface


def Process_SwComponentType_Sendport_CarCfg(Sender_Port):
    p_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    p_port_prototype.set('T',str(Feature.convert_to_datetime()))
    p_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Sender_Port"]
    provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
    provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
    provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Interface"])
    return p_port_prototype


def Process_SwComponentType_Receiveport_CarCfg(Receiver_Port):
    r_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    r_port_prototype.set('T',str(Feature.convert_to_datetime()))
    r_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port["Receiver_Port"]
    required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
    required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
    required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port["Interface"])  
    return r_port_prototype
    
    
def Process_SwComponentType_Sendport(Sender_Port,SDB_PortInterfaces_List,Interface_Data_Dype_Dict,InitValue_DataType_Dict,Port_Dict):
    p_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    p_port_prototype.set('T',str(Feature.convert_to_datetime()))
    p_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Sender_Port"]
    provided_com_speces = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-COM-SPECS")
    nonqueued_sender_com_spec = ET.SubElement(provided_com_speces,"{http://autosar.org/schema/r4.0}NONQUEUED-SENDER-COM-SPEC")
    nonqueued_sender_com_spec.set('T',str(Feature.convert_to_datetime()))
    data_element_ref = ET.SubElement(nonqueued_sender_com_spec,"{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
    data_element_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    data_element_ref.text ="/PortInterfaces/{}/{}".format(Sender_Port["Interface"],Sender_Port["Element"])
    hand_out_of_range = ET.SubElement(nonqueued_sender_com_spec,"{http://autosar.org/schema/r4.0}HANDLE-OUT-OF-RANGE")
    hand_out_of_range.text = "DEFAULT"
    uses_end_to_end_protection = ET.SubElement(nonqueued_sender_com_spec,"{http://autosar.org/schema/r4.0}USES-END-TO-END-PROTECTION")
    uses_end_to_end_protection.text = "0"
    init_value = ET.SubElement(nonqueued_sender_com_spec,"{http://autosar.org/schema/r4.0}INIT-VALUE")
    if Sender_Port["Data_Type_Property"] == "Non-Bus":
        if Sender_Port["Interface"] in SDB_PortInterfaces_List or Port_Dict[Sender_Port["Interface"]] == "APPLICATION-PRIMITIVE-DATA-TYPE":
            application_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
            category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
            if Sender_Port["Data_Type"] == "Boolean":
                category.text = "BOOLEAN"
            else:
                category.text = "VALUE"
            sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
            unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
            unit_ref.set("DEST", "UNIT")
            unit_ref.text = "/Units/NoUnit"
            sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
            v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
            v.text = str(Sender_Port["InitValue"])
        else:
            numerical_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
            value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
            value.text = str(Sender_Port["InitValue"])
        provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Interface"])
    elif Sender_Port["Data_Type_Property"] == "Bus":
        s = Sender_Port["InitValue"]
        values = Feature.Convert_InitValue(s)
        record_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}RECORD-VALUE-SPECIFICATION")
        fields0 = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}FIELDS")
        for i in range(0, len(Interface_Data_Dype_Dict[Sender_Port["Data_Type"]])):
            if InitValue_DataType_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]] == "STRUCTURE":
                record_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}RECORD-VALUE-SPECIFICATION")
                short_label = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                short_label.text = Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"]
                fields = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}FIELDS")
                for j in range(0, len(Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]])):
                    # if Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"] in SDB_PortInterfaces_List:
                    if Sender_Port["Interface"] in SDB_PortInterfaces_List or Port_Dict[Sender_Port["Interface"]] == "APPLICATION-PRIMITIVE-DATA-TYPE":
                        application_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                        short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                        short_label.text = Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"]
                        category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
                        category.text = "VALUE"
                        sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                        unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                        unit_ref.set("DEST", "UNIT")
                        unit_ref.text = "/Units/NoUnit"
                        sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                        v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
                        v.text = values[i][j]
                    else:
                        numerical_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                        short_label = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                        short_label.text = Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"]
                        value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                        value.text = values[i][j]
            elif InitValue_DataType_Dict[Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"]] == "VALUE":
                # if Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"] in SDB_PortInterfaces_List:
                if Sender_Port["Interface"] in SDB_PortInterfaces_List or Port_Dict[Sender_Port["Interface"]] == "APPLICATION-PRIMITIVE-DATA-TYPE":
                    application_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                    short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                    short_label.text = Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"]
                    category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
                    category.text = "VALUE"
                    sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                    unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                    unit_ref.set("DEST", "UNIT")
                    unit_ref.text = "/Units/NoUnit"
                    sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                    v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
                    v.text = values[i]
                else:
                    numerical_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                    short_label = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                    short_label.text = Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"]
                    value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                    value.text = values[i]
            elif Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Data_Type_Name"].startswith("rt_Array"):
                array_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}ARRAY-VALUE-SPECIFICATION")
                array_value_specification.set('T',str(Feature.convert_to_datetime()))
                elements = ET.SubElement(array_value_specification,"{http://autosar.org/schema/r4.0}ELEMENTS")
                for j in values[i]:
                    numerical_value_specification = ET.SubElement(elements,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                    value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                    value.text = j
            else:
                print("初始值数据类型错误")
        provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Interface"])    
        # if Sender_Port["Sender_Port"] in SDB_PortInterfaces_List:
        #     for i in range(0,len(Interface_Data_Dype_Dict[Sender_Port["Data_Type"]])):
        #         application_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
        #         short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
        #         short_label.text = Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"]
        #         category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
        #         category.text = "VALUE"
        #         sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}UNIT-REF")
        #         unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
        #         unit_ref.set("DEST", "UNIT")
        #         unit_ref.text = "/Units/NoUnit"
        #         sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
        #         v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
        #         v.text = values[i]
        #     provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        #     provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        #     provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Sender_Port"])
        # else:
        #     for i in range(0,len(Interface_Data_Dype_Dict[Sender_Port["Data_Type"]])):
        #         numerical_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
        #         short_label = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
        #         short_label.text = Interface_Data_Dype_Dict[Sender_Port["Data_Type"]][i]["Record_Data_element"]
        #         value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
        #         value.text = values[i]
        #     provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        #     provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        #     provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Sender_Port"])
    
    elif Sender_Port["Data_Type_Property"] == "Array":
        s = (Sender_Port["InitValue"])
        values = Feature.Convert_InitValue(s)
        array_value_specification = ET.SubElement(init_value,"ARRAY-VALUE-SPECIFICATION")
        array_value_specification.set('T',str(Feature.convert_to_datetime()))
        elements = ET.SubElement(array_value_specification,"ELEMENTS")
        for i in values:
            numerical_value_specification = ET.SubElement(elements,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
            value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
            value.text = i
        provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        provided_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        provided_interface_tref.text = "/PortInterfaces/{}".format(Sender_Port["Interface"])
    else:
        print("Data_Type_Property报错",Sender_Port['Data_Type'])
    return p_port_prototype
        
        
def Process_SwComponentType_Receiveport(Receiver_Port, SDB_PortInterfaces_List, Interface_Data_Dype_Dict,InitValue_DataType_Dict, Port_Dict):
    r_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    r_port_prototype.set('T',str(Feature.convert_to_datetime()))
    r_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port['Receiver_Port']
    required_com_speces = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-COM-SPECS")
    nonqueued_receiver_com_spec = ET.SubElement(required_com_speces,"{http://autosar.org/schema/r4.0}NONQUEUED-RECEIVER-COM-SPEC")
    nonqueued_receiver_com_spec.set('T',str(Feature.convert_to_datetime()))
    data_element_ref = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
    data_element_ref.set('DEST', "VARIABLE-DATA-PROTOTYPE")
    data_element_ref.text = "/PortInterfaces/{}/{}".format(Receiver_Port['Interface'],Receiver_Port['Element'])
    hand_out_of_range = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}HANDLE-OUT-OF-RANGE")
    hand_out_of_range.text = "NONE"
    uses_end_to_end_protection = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}USES-END-TO-END-PROTECTION")
    uses_end_to_end_protection.set('T',str(Feature.convert_to_datetime()))
    uses_end_to_end_protection.text = "false"
    alive_timeout = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}ALIVE-TIMEOUT")
    alive_timeout.text = "0.0"
    enable_update = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}ENABLE-UPDATE")
    if Receiver_Port["Data_Access_Mode"] == "IsUpdated":
        enable_update.text = "true"
    else:
        enable_update.text = "false"
    handle_never_received = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}HANDLE-NEVER-RECEIVED")
    handle_never_received.text = "false"
    handle_timeout_type = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}HANDLE-TIMEOUT-TYPE")
    handle_timeout_type.text = "NONE"
    init_value = ET.SubElement(nonqueued_receiver_com_spec,"{http://autosar.org/schema/r4.0}INIT-VALUE")
    if Receiver_Port["Data_Type_Property"] == "Non-Bus" :
        if Receiver_Port['Interface'] in SDB_PortInterfaces_List or Port_Dict[Receiver_Port['Interface']] == "APPLICATION-PRIMITIVE-DATA-TYPE":
            application_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
            category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
            if Receiver_Port["Data_Type"] == "Boolean":
                category.text = "BOOLEAN"
            else:
                category.text = "VALUE"
            sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
            unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
            unit_ref.set("DEST", "UNIT")
            unit_ref.text = "/Units/NoUnit"
            sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
            v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
            v.text = str(Receiver_Port["InitValue"])
        else:
            numerical_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
            value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
            value.text = str(Receiver_Port["InitValue"])
        required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port['Interface'])
    elif Receiver_Port["Data_Type_Property"] == "Bus":
        s = Receiver_Port["InitValue"]
        values = Feature.Convert_InitValue(s)
        record_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}RECORD-VALUE-SPECIFICATION")
        fields0 = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}FIELDS")
        for i in range(0, len(Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]])):
            # print(Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"])
            if InitValue_DataType_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]] == "STRUCTURE":
                record_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}RECORD-VALUE-SPECIFICATION")
                short_label = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                short_label.text = Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"]
                fields = ET.SubElement(record_value_specification,"{http://autosar.org/schema/r4.0}FIELDS")
                for j in range(0, len(Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]])):
                    # if Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"] in SDB_PortInterfaces_List:
                    if Receiver_Port['Interface'] in SDB_PortInterfaces_List or Port_Dict[Receiver_Port['Interface']] == "APPLICATION-PRIMITIVE-DATA-TYPE":
                        application_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                        short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                        short_label.text = Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"]
                        category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
                        category.text = "VALUE"
                        sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                        unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                        unit_ref.set("DEST", "UNIT")
                        unit_ref.text = "/Units/NoUnit"
                        sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                        v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
                        v.text = values[i][j]
                    else:
                        numerical_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                        short_label = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                        short_label.text = Interface_Data_Dype_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]][j]["Record_Data_element"]
                        value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                        value.text = values[i][j]
            elif InitValue_DataType_Dict[Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"]] == "VALUE":
                # if Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"] in SDB_PortInterfaces_List:
                if Receiver_Port['Interface'] in SDB_PortInterfaces_List or Port_Dict[Receiver_Port['Interface']] == "APPLICATION-PRIMITIVE-DATA-TYPE":
                    application_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                    short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                    short_label.text = Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"]
                    category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
                    category.text = "VALUE"
                    sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                    unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                    unit_ref.set("DEST", "UNIT")
                    unit_ref.text = "/Units/NoUnit"
                    sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                    v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
                    v.text = values[i]
                else:
                    numerical_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                    short_label = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
                    short_label.text = Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"]
                    value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                    value.text = values[i]
            elif Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Data_Type_Name"].startswith("rt_Array"):
                array_value_specification = ET.SubElement(fields0,"{http://autosar.org/schema/r4.0}ARRAY-VALUE-SPECIFICATION")
                array_value_specification.set('T',str(Feature.convert_to_datetime()))
                elements = ET.SubElement(array_value_specification,"{http://autosar.org/schema/r4.0}ELEMENTS")
                for j in values[i]:
                    numerical_value_specification = ET.SubElement(elements,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                    value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
                    value.text = j
            else:
                print("初始值数据类型错误")
        required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port["Interface"])   
            
        # if Receiver_Port['Receiver_Port'] in SDB_PortInterfaces_List:
        #     for i in range(0, len(Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]])):
        #         application_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
        #         short_label = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
        #         short_label.text = Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"]
        #         category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
        #         category.text = "VALUE"
        #         sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
        #         unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
        #         unit_ref.set("DEST", "UNIT")
        #         unit_ref.text = "/Units/NoUnit"
        #         sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
        #         v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
        #         v.text = values[i]
        #     required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        #     required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        #     required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port['Receiver_Port'])
        # else:
        #     for i in range(0, len(Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]])):
        #         numerical_value_specification = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
        #         short_label = ET.SubElement(fields,"{http://autosar.org/schema/r4.0}SHORT-LABEL")
        #         short_label.text = Interface_Data_Dype_Dict[Receiver_Port["Data_Type"]][i]["Record_Data_element"]
        #         value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
        #         value.text = values[i]
        #     required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        #     required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        #     required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port['Receiver_Port'])
    
    elif Receiver_Port["Data_Type_Property"] == "Array":
        s = Receiver_Port["InitValue"]
        values = Feature.Convert_InitValue(s)
        array_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}ARRAY-VALUE-SPECIFICATION")
        array_value_specification.set('T',str(Feature.convert_to_datetime()))
        elements = ET.SubElement(array_value_specification,"{http://autosar.org/schema/r4.0}ELEMENTS")
        for i in values:
            numerical_value_specification = ET.SubElement(elements,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
            value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
            value.text = i
        required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        required_interface_tref.set('DEST', "SENDER-RECEIVER-INTERFACE")
        required_interface_tref.text = "/PortInterfaces/{}".format(Receiver_Port["Interface"])
    else:
        print("Data_Type_Property报错",Receiver_Port['Data_Type'])
    return r_port_prototype

def Process_Common_CarCfg_Element(Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List,Application_DataTypeList):
    variable = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    variable.set('T',str(Feature.convert_to_datetime()))
    variable.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Port["Element"]
    category = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}CATEGORY")
    category.text = "VALUE"
    sw_data_def_props = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    sw_data_def_props_conditional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    sw_calibration_access = ET.SubElement(sw_data_def_props_conditional, "{http://autosar.org/schema/r4.0}SW-CALIBRATION-ACCESS")
    sw_calibration_access.text = "READ-ONLY"
    sw_impl_policy = ET.SubElement(sw_data_def_props_conditional, "{http://autosar.org/schema/r4.0}SW-IMPL-POLICY")
    sw_impl_policy.text = "STANDARD"
    type_tref = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}TYPE-TREF")


    if Port["Data_Type_Property"] == "Array":
        # print("Port", Port)
        # print("Size","rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"])))
        if "rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))  in ApplicationDataTypes_Data_type_List:
            # print("Port1", Port)
            type_tref.set("DEST", Application_DataTypeList[Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))
        else:
            if "rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))  in DataTypeImplementation_Data_type_List:
                # print("Port2", Port)
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))
            else :
                # print("Port3", Port)
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))
        # type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        # type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Port["Data_Type"], str(Port["Size"]))
    else:
        if Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
            type_tref.set("DEST", Application_DataTypeList[Port["Data_Type"]])
            type_tref.text = "/ApplicationDataTypes/{}".format(Port["Data_Type"])
        # if Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
        
        else:
            if Port["Data_Type"] in DataTypeImplementation_Data_type_List:
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/DataTypeImplementation/{}".format(Port["Data_Type"])
            else :
                type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
                type_tref.text = "/ImplementationDataTypes/{}".format(Port["Data_Type"])





    # if Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
    #     type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
    #     type_tref.text = "/ApplicationDataTypes/{}".format(Port["Data_Type"])
    #     # init_value = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}INIT-VALUE")
    #     # application_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
    #     # category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
    #     # category.text = "VALUE"
    #     # sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
    #     # unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
    #     # unit_ref.set("DEST", "UNIT")
    #     # unit_ref.text = "/Units/NoUnit"
    #     # sw_values_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
    #     # v = ET.SubElement(sw_values_phys,"{http://autosar.org/schema/r4.0}V")
    #     # v.text = str(Port["InitValue"])
    # # elif Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
    # else :
    #     if Port["Data_Type"] in DataTypeImplementation_Data_type_List:
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/DataTypeImplementation/{}".format(Port["Data_Type"])
    #     else:
    #         type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
    #         type_tref.text = "/ImplementationDataTypes/{}".format(Port["Data_Type"])
    #     # init_value = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}INIT-VALUE")
    #     # numerical_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
    #     # value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
    #     # value.text = str(Port["InitValue"])
    # # else:
    # #     print("数据类新未定义！",Port["Data_Type"])



    return variable

# def Process_Common_CarCfg_Element(Sender_Port,ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
#     variable = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
#     variable.set('T',str(Feature.convert_to_datetime()))
#     variable.set('UUID', str(uuid.uuid4()))
#     short_name = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}SHORT-NAME")
#     short_name.text = Sender_Port["Element"]
#     category = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}CATEGORY")
#     category.text = "VALUE"
#     sw_data_def_props = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
#     sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
#     sw_data_def_props_conditional = ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
#     sw_calibration_access = ET.SubElement(sw_data_def_props_conditional, "{http://autosar.org/schema/r4.0}SW-CALIBRATION-ACCESS")
#     sw_calibration_access.text = "READ-ONLY"
#     sw_impl_policy = ET.SubElement(sw_data_def_props_conditional, "{http://autosar.org/schema/r4.0}SW-IMPL-POLICY")
#     sw_impl_policy.text = "STANDARD"
#     type_tref = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}TYPE-TREF")


#     if Receiver_Port["Data_Type_Property"] == "Array":
#         # print("Receiver_Port", Receiver_Port)
#         # print("Size","rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"])))
#         if "rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))  in ApplicationDataTypes_Data_type_List:
#             # print("Receiver_Port1", Receiver_Port)
#             type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
#             type_tref.text = "/ApplicationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
#         else:
#             if "rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))  in DataTypeImplementation_Data_type_List:
#                 # print("Receiver_Port2", Receiver_Port)
#                 type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#                 type_tref.text = "/DataTypeImplementation/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
#             else :
#                 # print("Receiver_Port3", Receiver_Port)
#                 type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#                 type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
#         # type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
#         # type_tref.text = "/ImplementationDataTypes/rt_Array_{}_{}".format(Receiver_Port["Data_Type"], str(Receiver_Port["Size"]))
#     else:
#         if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
#             type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
#             type_tref.text = "/ApplicationDataTypes/{}".format(Receiver_Port["Data_Type"])
#         # if Receiver_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
        
#         else:
#             if Receiver_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
#                 type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#                 type_tref.text = "/DataTypeImplementation/{}".format(Receiver_Port["Data_Type"])
#             else :
#                 type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#                 type_tref.text = "/ImplementationDataTypes/{}".format(Receiver_Port["Data_Type"])





#     if Sender_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
#         type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
#         type_tref.text = "/ApplicationDataTypes/{}".format(Sender_Port["Data_Type"])
#         # init_value = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}INIT-VALUE")
#         # application_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
#         # category = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}CATEGORY")
#         # category.text = "VALUE"
#         # sw_value_cont = ET.SubElement(application_value_specification,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
#         # unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
#         # unit_ref.set("DEST", "UNIT")
#         # unit_ref.text = "/Units/NoUnit"
#         # sw_values_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
#         # v = ET.SubElement(sw_values_phys,"{http://autosar.org/schema/r4.0}V")
#         # v.text = str(Sender_Port["InitValue"])
#     # elif Sender_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
#     else :
#         if Sender_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
#             type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#             type_tref.text = "/DataTypeImplementation/{}".format(Sender_Port["Data_Type"])
#         else:
#             type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
#             type_tref.text = "/ImplementationDataTypes/{}".format(Sender_Port["Data_Type"])
#         # init_value = ET.SubElement(variable, "{http://autosar.org/schema/r4.0}INIT-VALUE")
#         # numerical_value_specification = ET.SubElement(init_value,"{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
#         # value = ET.SubElement(numerical_value_specification,"{http://autosar.org/schema/r4.0}VALUE")
#         # value.text = str(Sender_Port["InitValue"])
#     # else:
#     #     print("数据类新未定义！",Sender_Port["Data_Type"])



#     return variable


def Process_Common_CarCfg_Invaladation_Element(Sender_Port):
    invalidation_policy = ET.Element("{http://autosar.org/schema/r4.0}INVALIDATION-POLICY")
    invalidation_policy.set('T',str(Feature.convert_to_datetime()))
    data_element_ref = ET.SubElement(invalidation_policy,"{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
    data_element_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    data_element_temp = "/PortInterfaces/"+Sender_Port["Interface"]+"/{}"
    data_element_ref.text = data_element_temp.format(Sender_Port["Element"])
    # print("data_element_ref",data_element_ref.text)
    handle_invalid = ET.SubElement(invalidation_policy,"{http://autosar.org/schema/r4.0}HANDLE-INVALID")
    handle_invalid.text = "DONT-INVALIDATE"
    return invalidation_policy


def Process_SwComponentType_Variable_Access_Receiver_Port_CarCfg(Receiver_Port,swc):
    variable_access = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    variable_access.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "drparg_{}".format(Receiver_Port["Receiver_Port"] + "_" + Receiver_Port['Element'])
    access_variable = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE")
    autosar_variable_iref = ET.SubElement(access_variable,"{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF")
    port_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF")
    port_prototypr_ref.set("DEST", "R-PORT-PROTOTYPE")
    port_prototypr_ref.text = "/SwComponentType/{}/{}".format(swc,Receiver_Port['Receiver_Port'])
    # print("port_prototypr_ref",port_prototypr_ref.text)
    target_data_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
    target_data_prototypr_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    target_data_prototypr_ref.text = "/PortInterfaces/{}/{}".format(Receiver_Port['Interface'],Receiver_Port['Element'])
    return variable_access


def Process_SwComponentType_Variable_Access_Sender_Port_CarCfg(Sender_Port,swc):
    variable_access = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    variable_access.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dsp_{}".format(Sender_Port["Sender_Port"] + "_" + Sender_Port['Element'])
    access_variable = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE")
    autosar_variable_iref = ET.SubElement(access_variable,"{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF")
    port_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF")
    port_prototypr_ref.set("DEST", "P-PORT-PROTOTYPE")
    port_prototypr_ref.text = "/SwComponentType/{}/{}".format(swc,Sender_Port['Sender_Port'])
    target_data_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
    target_data_prototypr_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    target_data_prototypr_ref.text = "/PortInterfaces/{}/{}".format(Sender_Port['Interface'],Sender_Port['Element'])
    return variable_access


def Process_SwComponentType_Variable_Access_Receiver_Port(Receiver_Port,swc):
    variable_access = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    variable_access.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "drparg_{}".format(Receiver_Port["Receiver_Port"] + "_" + Receiver_Port['Element'])
    access_variable = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE")
    autosar_variable_iref = ET.SubElement(access_variable,"{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF")
    port_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF")
    port_prototypr_ref.set("DEST", "R-PORT-PROTOTYPE")
    port_prototypr_ref.text = "/SwComponentType/{}/{}".format(swc,Receiver_Port['Receiver_Port'])
    target_data_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
    target_data_prototypr_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    target_data_prototypr_ref.text = "/PortInterfaces/{}/{}".format(Receiver_Port['Interface'],Receiver_Port['Element'])
    return variable_access


def Process_SwComponentType_Variable_Access_Sender_Port(Sender_Port,swc):
    variable_access = ET.Element("{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
    variable_access.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dsp_{}".format(Sender_Port["Sender_Port"] + "_" + Sender_Port['Element'])
    access_variable = ET.SubElement(variable_access,"{http://autosar.org/schema/r4.0}ACCESSED-VARIABLE")
    autosar_variable_iref = ET.SubElement(access_variable,"{http://autosar.org/schema/r4.0}AUTOSAR-VARIABLE-IREF")
    port_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}PORT-PROTOTYPE-REF")
    port_prototypr_ref.set("DEST", "P-PORT-PROTOTYPE")
    port_prototypr_ref.text = "/SwComponentType/{}/{}".format(swc,Sender_Port['Sender_Port'])
    target_data_prototypr_ref = ET.SubElement(autosar_variable_iref,"{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
    target_data_prototypr_ref.set("DEST", "VARIABLE-DATA-PROTOTYPE")
    target_data_prototypr_ref.text = "/PortInterfaces/{}/{}".format(Sender_Port['Interface'],Sender_Port['Element'])
    return variable_access


def Process_Geely_Assembly_Receiver_Port_Element(SWC_Receiver_Port,Receiver_Port,swc):
    assembly_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    assembly_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "ac_its{}{}_its{}{}".format(Receiver_Port["Sig_From"],SWC_Receiver_Port,swc,Receiver_Port["Receiver_Port"])
    provider_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}PROVIDER-IREF")
    context_component_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(Receiver_Port["Sig_From"])
    target_p_port_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    target_p_port_ref.text = "/SwComponentType/{}/{}".format(Receiver_Port["Sig_From"],SWC_Receiver_Port)
    requester_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}REQUESTER-IREF")
    context_component_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")   
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(swc)
    target_r_port_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    target_r_port_ref.text = "/SwComponentType/{}/{}".format(swc,Receiver_Port["Receiver_Port"])
    return assembly_sw_connector


def Process_Geely_Assembly_Sender_Port_Element(SWC_Sender_Port,Sender_Port,swc):
    assembly_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    assembly_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "ac_its{}{}_its{}{}".format(swc,Sender_Port["Sender_Port"],Sender_Port["Sig_From"],SWC_Sender_Port)
    provider_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}PROVIDER-IREF")
    context_component_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(swc)
    target_p_port_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    target_p_port_ref.text = "/SwComponentType/{}/{}".format(swc,Sender_Port["Sender_Port"])
    requester_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}REQUESTER-IREF")
    context_component_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")   
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(Sender_Port["Sig_From"])
    target_r_port_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    target_r_port_ref.text = "/SwComponentType/{}/{}".format(Sender_Port["Sig_From"],SWC_Sender_Port)        
    return assembly_sw_connector


def Process_Geely_Delegation_Receiver_Port_Element(Receiver_Port,swc):   
    delegation_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    delegation_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dc_{}_its{}{}".format(Receiver_Port["Receiver_Port"],swc,Receiver_Port["Receiver_Port"])
    inner_port_iref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}INNER-PORT-IREF")
    r_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF")
    context_component_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(swc)
    target_r_port_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST","R-PORT-PROTOTYPE")
    target_r_port_ref.text = "/SwComponentType/{}/{}".format(swc,Receiver_Port["Receiver_Port"])
    outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
    outer_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    outer_port_ref.text = "/geely_cem/geely_cem/{}".format(Receiver_Port["Receiver_Port"])
    return delegation_sw_connector


def Process_Geely_Delegation_Sender_Port_Element(Sender_Port,swc): 
    delegation_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    delegation_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dc_{}_its{}{}".format(Sender_Port["Sender_Port"],swc,Sender_Port["Sender_Port"])
    inner_port_iref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}INNER-PORT-IREF")
    p_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}P-PORT-IN-COMPOSITION-INSTANCE-REF")
    context_component_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/geely_cem/geely_cem/its{}".format(swc)
    target_p_port_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST","P-PORT-PROTOTYPE")
    target_p_port_ref.text = "/SwComponentType/{}/{}".format(swc,Sender_Port["Sender_Port"])
    outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
    outer_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    outer_port_ref.text = "/geely_cem/geely_cem/{}".format(Sender_Port["Sender_Port"])
    return delegation_sw_connector


def Process_SDB_Assembly_Receiver_Port_Element(SWC_Receiver_Port,Receiver_Port,ECU_Name):
    assembly_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    assembly_sw_connector.set('T',str(Feature.convert_to_datetime()))
    assembly_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "ac_basetech{}_geely_cem{}".format(SWC_Receiver_Port,Receiver_Port["Receiver_Port"])
    provider_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}PROVIDER-IREF")
    context_component_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/SwComponentType/{}/basetech".format(ECU_Name)
    target_p_port_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    # if(ECU_Name == "ZCUDS"):
    #     target_p_port_ref.text = "/SWCs_Conti/basetech/{}".format(Receiver_Port["Receiver_Port"])
    # else:
    #     target_p_port_ref.text = "/basetech/basetech/{}".format(SWC_Receiver_Port)
    target_p_port_ref.text = "/basetech/basetech/{}".format(SWC_Receiver_Port)    
    requester_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}REQUESTER-IREF")
    context_component_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")   
    context_component_ref.text = "/SwComponentType/{}/geely_cem".format(ECU_Name)
    target_r_port_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    target_r_port_ref.text = "/geely_cem/geely_cem/{}".format(Receiver_Port["Receiver_Port"])
    return assembly_sw_connector

    
def Process_SDB_Assembly_Sender_Port_Element(SWC_Sender_Port,Sender_Port,ECU_Name):
    assembly_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    assembly_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "ac_geely_cem{}_basetech{}".format(Sender_Port["Sender_Port"],SWC_Sender_Port)
    provider_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}PROVIDER-IREF")
    context_component_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/SwComponentType/{}/geely_cem".format(ECU_Name)
    target_p_port_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    target_p_port_ref.text = "/geely_cem/geely_cem/{}".format(Sender_Port["Sender_Port"])
    requester_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}REQUESTER-IREF")
    context_component_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")   
    context_component_ref.text = "/SwComponentType/{}/basetech".format(ECU_Name)
    target_r_port_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    # if(ECU_Name == "ZCUDS"):
    #     target_r_port_ref.text = "/SWCs_Conti/basetech/{}".format(Sender_Port["Sender_Port"])
    # else:
    #     target_r_port_ref.text = "/SWCs_ContiComposition/basetech/{}".format(Sender_Port["Sender_Port"])
    target_r_port_ref.text = "/basetech/basetech/{}".format(SWC_Sender_Port)
    return assembly_sw_connector


def Process_SDB_Delegation_Receiver_Port_Element(SDB_Receiver_Port,Receiver_Port,ECU_Name):
    # SDB_Receiver_Port = Receiver_Port["Receiver_Port"]    
    # # 检查第一个字符是否是 'p'  
    # if SDB_Receiver_Port.startswith('r'):  
    #     # 删除第一个字符  
    #     SDB_Receiver_Port = SDB_Receiver_Port[1:]  


    delegation_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    delegation_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dc_{}_geely_cem{}".format(SDB_Receiver_Port,Receiver_Port["Receiver_Port"])
    inner_port_iref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}INNER-PORT-IREF")
    r_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF")
    context_component_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/SwComponentType/{}/geely_cem".format(ECU_Name)
    target_r_port_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
    target_r_port_ref.set("DEST","R-PORT-PROTOTYPE")
    target_r_port_ref.text = "/geely_cem/geely_cem/{}".format(Receiver_Port["Receiver_Port"])
    outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
    outer_port_ref.set("DEST", "R-PORT-PROTOTYPE")
    outer_port_ref.text = "/SwComponentType/{}/{}".format(ECU_Name,SDB_Receiver_Port)
    return delegation_sw_connector


def Process_SDB_Delegation_Sender_Port_Element(SDB_Sender_Port,Sender_Port,ECU_Name):
    # SDB_Sender_Port = Sender_Port["Sender_Port"]    
    # # 检查第一个字符是否是 'p'  
    # if SDB_Sender_Port.startswith('p'):  
    #     # 删除第一个字符  
    #     SDB_Sender_Port = SDB_Sender_Port[1:]  

    delegation_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
    delegation_sw_connector.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "dc_{}_geely_cem{}".format(SDB_Sender_Port,Sender_Port["Sender_Port"])
    inner_port_iref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}INNER-PORT-IREF")
    p_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}P-PORT-IN-COMPOSITION-INSTANCE-REF")
    context_component_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
    context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
    context_component_ref.text = "/SwComponentType/{}/geely_cem".format(ECU_Name)
    target_p_port_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
    target_p_port_ref.set("DEST","P-PORT-PROTOTYPE")
    target_p_port_ref.text = "/geely_cem/geely_cem/{}".format(Sender_Port["Sender_Port"])
    outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
    outer_port_ref.set("DEST", "P-PORT-PROTOTYPE")
    outer_port_ref.text = "/SwComponentType/{}/{}".format(ECU_Name,SDB_Sender_Port)
    return delegation_sw_connector


def Set_Enable_Update_Value_Receiver(root,portname):
    receiverports = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for child in receiverports:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == portname:
            if child.find(".//{http://autosar.org/schema/r4.0}ENABLE-UPDATE") is None:
                print("test",child.find(".//{http://autosar.org/schema/r4.0}NONQUEUED-RECEIVER-COM-SPEC"))
                print("ENABLE-UPDATE",portname)
                nonqueued_receiver_com_spec = child.find(".//{http://autosar.org/schema/r4.0}NONQUEUED-RECEIVER-COM-SPEC")
                active_out = child.find(".//{http://autosar.org/schema/r4.0}ALIVE-TIMEOUT")
                enable_update = ET.Element("ENABLE-UPDATE")
                enable_update.text = "true"
                nonqueued_receiver_com_spec.insert(list(nonqueued_receiver_com_spec).index(active_out)+1,enable_update)
            else:
                child.find(".//{http://autosar.org/schema/r4.0}ENABLE-UPDATE").text = "true"


def Set_Enable_Update_Value_Sender(root,portname):
    senderports = root.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for child in senderports:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == portname:
            if child.find(".//{http://autosar.org/schema/r4.0}ENABLE-UPDATE") is None:
                nonqueued_sender_com_spec = child.find(".//{http://autosar.org/schema/r4.0}NONQUEUED-SENDER-COM-SPEC")
                active_out = child.find(".//{http://autosar.org/schema/r4.0}ALIVE-TIMEOUT")
                enable_update = ET.Element("ENABLE-UPDATE")
                enable_update.text = "true"
                print("ENABLE-UPDATE",portname,nonqueued_sender_com_spec,active_out,enable_update)
                nonqueued_sender_com_spec.insert(list(nonqueued_sender_com_spec).index(active_out)+1,enable_update)
            else:
                child.find(".//{http://autosar.org/schema/r4.0}ENABLE-UPDATE").text = "true"
# Data_Tpye_Dict = {"SWC":"AlcolockManager", "Data_Type":"EngSt1", "Name":"Primitive_Data_Type", "Struct_List": [{"Record_Data_element":"/", "Data_Type_Name": "/"}], "Size":"/", "Constant_List":[{"Min":"0","Max":"0","Value":"0","Constant":"EngSt1_Ini"}, {"Min":"1","Max":"1","Value":"1","Constant":"EngSt1_Awake"}, {"Min":"2","Max":"2","Value":"2","Constant":"EngSt1_Rdy"}, {"Min":"3","Max":"3","Value":"3","Constant":"EngSt1_PreStrtg"}, {"Min":"4","Max":"4","Value":"4","Constant":"EngSt1_RunngRunng"}], "Value_Type":"TEXTTABLE", "Type":"VALUE"}
# # Data_Tpye_Dict = {"SWC":"AlcolockManager", "Data_Type":"EngSt1", "Name":"Primitive_Data_Type", "Struct_List": [{"Record_Data_element":"EngSt1WdSts", "Data_Type_Name": "EngSt1"}, {"Record_Data_element":"Chks", "Data_Type_Name": "UInt8"}], "Size":"/", "Constant_List":[{"Min":"0","Max":"0","Value":"0","Constant":"EngSt1_Ini"}, {"Min":"1","Max":"1","Value":"1","Constant":"EngSt1_Awake"}, {"Min":"2","Max":"2","Value":"2","Constant":"EngSt1_Rdy"}, {"Min":"3","Max":"3","Value":"3","Constant":"EngSt1_PreStrtg"}, {"Min":"4","Max":"4","Value":"4","Constant":"EngSt1_RunngRunng"}], "Value_Type":"TEXTTABLE", "Type":"STRUCTURE"}
# Process_CompuMethods(Data_Tpye_Dict)
# # Process_DataConstrs(Data_Tpye_Dict)
def Process_especially_PortInterfaces(Receiver_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
    sender_receiver_interface = ET.Element("{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    sender_receiver_interface.set('T',str(Feature.convert_to_datetime()))
    sender_receiver_interface.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port["Interface"]
    is_service = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}IS-SERVICE")
    is_service.text = "false"
    data_elements = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}DATA-ELEMENTS")

    variable_data_prorotype = ET.SubElement(data_elements, "{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    variable_data_prorotype.set('T',str(Feature.convert_to_datetime()))
    variable_data_prorotype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_data_prorotype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Receiver_Port["Element"]
    # print("Receiver_Port111", Receiver_Port)
    sw_data_def_props = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    type_tref = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}TYPE-TREF")
    if Receiver_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
        type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        type_tref.text = "/ApplicationDataTypes/{}".format(Receiver_Port["Data_Type"])
    # if Receiver_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
    else:
        if Receiver_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
            type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
            type_tref.text = "/DataTypeImplementation/{}".format(Receiver_Port["Data_Type"])
        else :
            type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
            type_tref.text = "/ImplementationDataTypes/{}".format(Receiver_Port["Data_Type"])
            
    ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")
    
    
    return sender_receiver_interface



def Process_especially_PortInterfaces_Sender_Port(Sender_Port, ImplementationDataTypes_Data_type_List,DataTypeImplementation_Data_type_List,ApplicationDataTypes_Data_type_List):
    sender_receiver_interface = ET.Element("{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
    sender_receiver_interface.set('T',str(Feature.convert_to_datetime()))
    sender_receiver_interface.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Interface"]
    is_service = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}IS-SERVICE")
    is_service.text = "false"
    data_elements = ET.SubElement(sender_receiver_interface, "{http://autosar.org/schema/r4.0}DATA-ELEMENTS")
    variable_data_prorotype = ET.SubElement(data_elements, "{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
    variable_data_prorotype.set('T',str(Feature.convert_to_datetime()))
    variable_data_prorotype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(variable_data_prorotype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Sender_Port["Element"]
    sw_data_def_props = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS")
    sw_data_def_props_variants = ET.SubElement(sw_data_def_props, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-VARIANTS")
    ET.SubElement(sw_data_def_props_variants, "{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL")
    type_tref = ET.SubElement(variable_data_prorotype, "{http://autosar.org/schema/r4.0}TYPE-TREF")
    if Sender_Port["Data_Type"] in ApplicationDataTypes_Data_type_List:
        type_tref.set("DEST", "APPLICATION-PRIMITIVE-DATA-TYPE")
        type_tref.text = "/ApplicationDataTypes/{}".format(Sender_Port["Data_Type"])
    # if Sender_Port["Data_Type"] in ImplementationDataTypes_Data_type_List:
    else:
        if Sender_Port["Data_Type"] in DataTypeImplementation_Data_type_List:
            type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
            type_tref.text = "/DataTypeImplementation/{}".format(Sender_Port["Data_Type"])
        else :
            type_tref.set("DEST", "IMPLEMENTATION-DATA-TYPE")
            type_tref.text = "/ImplementationDataTypes/{}".format(Sender_Port["Data_Type"])
    ET.SubElement(sender_receiver_interface,"{http://autosar.org/schema/r4.0}INVALIDATION-POLICYS")
    
    return sender_receiver_interface