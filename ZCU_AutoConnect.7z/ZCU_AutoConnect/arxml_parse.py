#!/usr/bin/python
# -*- coding: UTF-8 -*-
import xml.etree.ElementTree as ET
import os

class arxml(object):
    def __init__(self, filepath):
        self.tree = ET.parse(filepath)
        self.AUTOSAR = self.tree.getroot() 
        self.file_path = filepath
        self.interface_info_list = []
        self.composition_total_port_list = []
        self.port_info_list = []
        self.adt_name_list = []
        self.corresponding_swc = {}
        self.get_swc_name()
        self.get_interface_info()
        self.get_port_info()
        self.get_connection_list()
        self.get_adt_name()
     

    #  "interface_name":   interface_name
    #  "interface_type":   interface_type  
    #  "element_dict":      element_name: type
    def get_interface_info(self):
        interface_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
        for interface in interface_list:
            if interface.find("./{http://autosar.org/schema/r4.0}SHORT-NAME") is not None:
                interface_name = interface.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
                element_dic = {}
                element_list = interface.findall(".//{http://autosar.org/schema/r4.0}VARIABLE-DATA-PROTOTYPE")
                for element in element_list:
                    if element.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME") is not None:
                        element_name = element.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text
                    if element.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF") is not None:
                        element_type = element.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF").text.split("/")[-1]
                        element_dic[element_name] = element_type
                type_ref = interface.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF")  
                interface_type = "ADT"
                if type_ref is not None and type_ref.attrib.get("DEST").split("-")[0] == "IMPLEMENTATION":
                    interface_type = "IDT"                 
                self.interface_info_list.append({"interface_name":interface_name,"interface_type":interface_type,"element_dict":element_dic})
    #  "port_name":                port_name
    #  "port_type":                port_type
    #  "interface_ref":            interface_ref
    #  "data_element_ref_list":    [data_element_ref1, data_element_ref2]
    #  "init_value":               init_value
    #  "swc_name":                 swc_name
    def get_port_info(self):
        if os.path.basename(self.file_path) == "supply.arxml":
            COMPOSITION_SW_COMPONENT_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
            for component in COMPOSITION_SW_COMPONENT_list:
                rport_list = component.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")

                # if component.find("./{http://autosar.org/schema/r4.0}PORTS") is not None:
                #     print("111")
                #     # 查找当前组件下的所有R端口原型
                #     rport_list = component.find("./{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
                # print(rport_list)
            # rport_list = COMPOSITION_SW_COMPONENT_list.find(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
            
        else:
            rport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
        for rport in rport_list:
            port_type = "R"
            if rport.find("./{http://autosar.org/schema/r4.0}SHORT-NAME") is not None:
                rport_name = rport.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
                if(rport.find(".//{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF").attrib.get("DEST") != "CLIENT-SERVER-INTERFACE"):
                    interface_ref = rport.find(".//{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF").text.split("/")[-1]
                    data_element_ref_list = rport.findall(".//{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
                    data_element_ref_list = [data_element_ref.text.split("/")[-1] for data_element_ref in data_element_ref_list]
                    init_value = rport.find(".//{http://autosar.org/schema/r4.0}INIT-VALUE")
                    if init_value is not None:
                        if(init_value.find(".//{http://autosar.org/schema/r4.0}CONSTANT-REF")) is not None:
                            init_value = init_value.find(".//{http://autosar.org/schema/r4.0}CONSTANT-REF").text.split("/")[-1]  
                    self.port_info_list.append( {"port_name":rport_name,"port_type":port_type,"interface_ref":interface_ref,\
                                                "data_element_ref_list":data_element_ref_list,"init_value":init_value,"swc_name":self.swc_name} ) 
           
        if os.path.basename(self.file_path) == "supply.arxml":
            COMPOSITION_SW_COMPONENT_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
            for component in COMPOSITION_SW_COMPONENT_list:
                # rport_list = component.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
                pport_list = component.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
        else:
            pport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
        # pport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
        for pport in pport_list:
            port_type = "P"
            if pport.find("./{http://autosar.org/schema/r4.0}SHORT-NAME") is not None:
                pport_name = pport.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text
                if(pport.find(".//{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF").attrib.get("DEST") != "CLIENT-SERVER-INTERFACE"):
                    interface_ref = pport.find(".//{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF").text.split("/")[-1]
                    data_element_ref_list = pport.findall(".//{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
                    data_element_ref_list = [data_element_ref.text.split("/")[-1] for data_element_ref in data_element_ref_list]
                    init_value = pport.find(".//{http://autosar.org/schema/r4.0}INIT-VALUE") 
                    if init_value is not None:
                        if init_value.find(".//{http://autosar.org/schema/r4.0}CONSTANT-REF") is not None:
                            init_value = init_value.find(".//{http://autosar.org/schema/r4.0}CONSTANT-REF").text.split("/")[-1]  
                    self.port_info_list.append ({"port_name":pport_name,"port_type":port_type,"interface_ref":interface_ref,\
                                                "data_element_ref_list":data_element_ref_list,"init_value":init_value,"swc_name":self.swc_name} )

    def get_swc_name(self):
        application_swc = self.AUTOSAR.find(".//{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
        if application_swc is not None:
            self.swc_name = application_swc.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text 
        
        elif self.AUTOSAR.find(".//{http://autosar.org/schema/r4.0}COMPLEX-DEVICE-DRIVER-SW-COMPONENT-TYPE") is not None:
            cdd_swc = self.AUTOSAR.find(".//{http://autosar.org/schema/r4.0}COMPLEX-DEVICE-DRIVER-SW-COMPONENT-TYPE")
            self.swc_name = cdd_swc.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text 
        else:
            composition_swc = self.AUTOSAR.find(".//{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
            if composition_swc is not None:
                self.swc_name = composition_swc.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text 
            swc_prototype_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}SW-COMPONENT-PROTOTYPE")
            for swc_prototype in swc_prototype_list:
                short_name =  swc_prototype.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME")
                type_tref = swc_prototype.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF")
                if short_name is not None and type_tref is not None:
                    self.corresponding_swc[type_tref.text.split("/")[-1]] = short_name.text
            
    
    def get_adt_name(self):
        application_primitive_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-PRIMITIVE-DATA-TYPE")
        if application_primitive_list is not None:
            for application_primitive in application_primitive_list: 
                adt_name = application_primitive.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text 
                self.adt_name_list.append(adt_name)
        application_record_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-RECORD-DATA-TYPE")
        if application_record_list is not None:
            for application_record in application_record_list :
                adt_name = application_record.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text 
                self.adt_name_list.append(adt_name)
        application_array_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-ARRAY-DATA-TYPE")
        if application_array_list is not None:
            for application_array in application_array_list :
                adt_name = application_array.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text 
                self.adt_name_list.append(adt_name)
 
    def creat_codedec(self,engineering_objects):  
        code_decribe = ET.Element("{http://autosar.org/schema/r4.0}CODE-DESCRIPTORS")
        code = ET.SubElement(code_decribe, "{http://autosar.org/schema/r4.0}CODE")
        short_name = ET.SubElement(code, "{http://autosar.org/schema/r4.0}SHORT-NAME")
        # short_name.text = "Code"
        short_name.text = "Default"
        artifact_decribe = ET.SubElement(code, "{http://autosar.org/schema/r4.0}ARTIFACT-DESCRIPTORS")
        for obj_info in engineering_objects:
            engineering_object = ET.SubElement(artifact_decribe, "{http://autosar.org/schema/r4.0}AUTOSAR-ENGINEERING-OBJECT")
            short_label = ET.SubElement(engineering_object, "{http://autosar.org/schema/r4.0}SHORT-LABEL")
            short_label.text = obj_info["SHORT-LABEL"].replace("swc_name", f"{self.swc_name}")
            category = ET.SubElement(engineering_object, "{http://autosar.org/schema/r4.0}CATEGORY")
            category.text = obj_info["CATEGORY"]
        return code_decribe  
     
    def create_resource(self,memory_sections):
        resource_consumption = ET.Element("{http://autosar.org/schema/r4.0}RESOURCE-CONSUMPTION")
        short_name = ET.SubElement(resource_consumption, "{http://autosar.org/schema/r4.0}SHORT-NAME")
        short_name.text = "RsrcCons_" + self.swc_name  
        memory_sections_element = ET.SubElement(resource_consumption, "{http://autosar.org/schema/r4.0}MEMORY-SECTIONS")
        for section in memory_sections:
            memory_section = ET.SubElement(memory_sections_element, "{http://autosar.org/schema/r4.0}MEMORY-SECTION")
            # 假设memory_sections中的每个条目都是一个包含SHORT-NAME和SIZE的字典，以及一个指向SW-ADDR-METHOD的引用。
            short_name_elem = ET.SubElement(memory_section, "{http://autosar.org/schema/r4.0}SHORT-NAME")
            short_name_elem.text = section
            size_elem = ET.SubElement(memory_section, "{http://autosar.org/schema/r4.0}SIZE")
            size_elem.text = "0" 
            sw_addr_method_ref = ET.SubElement(memory_section, "{http://autosar.org/schema/r4.0}SW-ADDRMETHOD-REF")
            sw_addr_method_ref.set("DEST", "SW-ADDR-METHOD")
            sw_addr_method_ref.text = "/ImplementationDataTypes/SwAddressMethods/" + section  
        return resource_consumption  
    
    def create_proglang(self):
        program_language = ET.Element("{http://autosar.org/schema/r4.0}PROGRAMMING-LANGUAGE")
        program_language.text = "C"
        return program_language 
    
    def create_datatype_mapping_ref(self):
        datatype_mapping_refs = ET.Element("{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-REFS")
        datatype_mapping_ref = ET.SubElement(datatype_mapping_refs,"{http://autosar.org/schema/r4.0}DATA-TYPE-MAPPING-REF")
        datatype_mapping_ref.attrib = {"DEST":"DATA-TYPE-MAPPING-SET"}
        datatype_mapping_ref.text = rf"/DataTypeMappings/{self.swc_name}_DataTypeMappingSet"
        return datatype_mapping_refs 
    
    def insert_section(self,parent,section):
        parent_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}" + parent)
        for parent in parent_list:
            parent.append(section)

    def insert_swc_prototype(self,swc_name_list):
        parent = self.AUTOSAR.find(".//{http://autosar.org/schema/r4.0}COMPONENTS")
        parent.clear()
        for swc_name in swc_name_list:
            swc_prototype = ET.Element("{http://autosar.org/schema/r4.0}SW-COMPONENT-PROTOTYPE")
            short_name = ET.SubElement(swc_prototype, "{http://autosar.org/schema/r4.0}SHORT-NAME")
            short_name.text = f"its{swc_name}"
            type_ref = ET.SubElement(swc_prototype, "{http://autosar.org/schema/r4.0}TYPE-TREF")
            type_ref.attrib = {"DEST": "APPLICATION-SW-COMPONENT-TYPE"}
            type_ref.text = f"/SwComponentType/{swc_name}"
            parent.append(swc_prototype)

    def save(self,new_filepath):
        ET.register_namespace('', "http://autosar.org/schema/r4.0")
        tree = ET.ElementTree(self.AUTOSAR)
        tree.write(new_filepath, encoding='utf-8', short_empty_elements=False) 
        with open(new_filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            lines.insert(0, '<?xml version="1.0" encoding="UTF-8"?>\n')
            file_info = ''.join(lines)
        with open(new_filepath, 'w', encoding='utf-8') as f:
            f.write(file_info)  

    def get_texttable_compmethod_name(self):
        texttable_shortnames = []
        compmethod_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}COMPU-METHOD")
        for compmethod in compmethod_list:
            category_elem = compmethod.find(".//{http://autosar.org/schema/r4.0}CATEGORY")
            if category_elem is not None and category_elem.text == "TEXTTABLE":
                short_name_elem = compmethod.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME")
                if short_name_elem is not None:
                    texttable_shortnames.append(short_name_elem.text)
        return texttable_shortnames  
    def delete_texttable_constr(self): 
        texttable_shortnames = self.get_texttable_compmethod_name() 
        appl_datatype_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-PRIMITIVE-DATA-TYPE")  
        for appl_datatype in appl_datatype_list:
            data_prop = appl_datatype.find(".//{http://autosar.org/schema/r4.0}SW-DATA-DEF-PROPS-CONDITIONAL") 
            if data_prop is not None:
                compmothod_ref = data_prop.find(".//{http://autosar.org/schema/r4.0}COMPU-METHOD-REF")
                if compmothod_ref is not None and compmothod_ref.text.split("/")[-1] in texttable_shortnames:
                    data_constr = data_prop.find(".//{http://autosar.org/schema/r4.0}DATA-CONSTR-REF")  
                    if data_constr is not None:
                        # print("remove data constr:",data_constr.text)
                        data_prop.remove(data_constr)    

    def change_constant_spec(self):
        constant_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}CONSTANT-SPECIFICATION")
        for constant in constant_list:
            if constant is not None:
                short_name = constant.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME")
                parent = None
                interface_type = False
                # 如果constant 被某个port的init value引用 且 interface 的数据类型是ADT 则要更改constant为application
                for port in self.port_info_list:
                    if port["init_value"] == short_name.text:
                        for interface_info in self.interface_info_list:
                            if interface_info["interface_name"] == port["interface_ref"] and interface_info["interface_type"] == "ADT":
                                interface_type = "ADT"
                            elif interface_info["interface_name"] == port["interface_ref"] and interface_info["interface_type"] == "IDT":
                                interface_type = "IDT"
                                break
                        break
                if  short_name == "CarCfg_Nr2":
                    interface_type = "False"

                if interface_type != "False":
                    if constant.find(".//{http://autosar.org/schema/r4.0}FIELDS") is not None:
                        parent = constant.find(".//{http://autosar.org/schema/r4.0}FIELDS")
                        # print("CONSTANT FIELDS:",short_name.text)
                    elif constant.find(".//{http://autosar.org/schema/r4.0}ELEMENTS") is not None:
                        parent = constant.find(".//{http://autosar.org/schema/r4.0}ELEMENTS")
                        # print("CONSTANT ELEMENTS:",short_name.text)
                    elif constant.find(".//{http://autosar.org/schema/r4.0}VALUE-SPEC") is not None:
                        parent = constant.find(".//{http://autosar.org/schema/r4.0}VALUE-SPEC")
                        # print("CONSTANT VALUE-SPEC:",short_name.text)
                    else:
                        parent = None
                        # print("CONSTANT None")
                else:
                    # print("not change constant :",short_name.text)
                    pass
                if parent is not None:
                    if interface_type == "ADT":
                        number_value_list = parent.findall(".//{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                        for number_value in number_value_list:
                            if number_value is not None:
                                value = number_value.find(".//{http://autosar.org/schema/r4.0}VALUE").text
                                short_lable = number_value.find(".//{http://autosar.org/schema/r4.0}SHORT-LABEL")
                                parent.remove(number_value)
                                appl_value_info = ET.SubElement(parent, "{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                                category = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}CATEGORY")
                                category.text = "VALUE"
                                if short_lable is not None:
                                    new_short_lable = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}SHORT-LABLE")
                                    new_short_lable.text = short_lable.text
                                sw_value_cont = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                                unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                                unit_ref.set("DEST", "UNIT")
                                unit_ref.text = "/Units/NoUnit"
                                sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                                v = ET.SubElement(sw_value_phys,"{http://autosar.org/schema/r4.0}V")
                                v.text = value
                    elif interface_type == "IDT":
                        number_value_list = parent.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-VALUE-SPECIFICATION")
                        for number_value in number_value_list:
                            if number_value is not None:
                                v = number_value.find(".//{http://autosar.org/schema/r4.0}V").text
                                short_lable = number_value.find(".//{http://autosar.org/schema/r4.0}SHORT-LABEL")
                                parent.remove(number_value)
                                appl_value_info = ET.SubElement(parent, "{http://autosar.org/schema/r4.0}NUMERICAL-VALUE-SPECIFICATION")
                                # category = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}CATEGORY")
                                # category.text = "VALUE"
                                if short_lable is not None:
                                    new_short_lable = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}SHORT-LABLE")
                                    new_short_lable.text = short_lable.text
                                # sw_value_cont = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}SW-VALUE-CONT")
                                # unit_ref = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}UNIT-REF")
                                # unit_ref.set("DEST", "UNIT")
                                # unit_ref.text = "/Units/NoUnit"
                                # sw_value_phys = ET.SubElement(sw_value_cont,"{http://autosar.org/schema/r4.0}SW-VALUES-PHYS")
                                value = ET.SubElement(appl_value_info,"{http://autosar.org/schema/r4.0}VALUE")
                                value.text = v
         
    def change_idt_UInt32(self):
        idt_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE")
        for idt in idt_list:
            if idt is not None and idt.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text == "UInt32":
                if idt.find(".//{http://autosar.org/schema/r4.0}BASE-TYPE-REF") is not None:
                    # print("change idt UInt32")
                    idt.find(".//{http://autosar.org/schema/r4.0}BASE-TYPE-REF").text = "/BaseTypes/UInt32"
                    break                                         
    def replace_interface_adt_ref(self,new_adt_list):
        replace_adt_list = []
        interface_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}SENDER-RECEIVER-INTERFACE")
        for interface in interface_list:    
            type_tref =  interface.find(".//{http://autosar.org/schema/r4.0}TYPE-TREF")
            if type_tref is not None:
                if (type_tref.attrib.get("DEST").split("-")[0] == "APPLICATION"):
                    element_type = type_tref.text.split("/")[-1]
                    if element_type in new_adt_list:
                        replace_adt_list.append(element_type)
                        type_tref.text = f"/ApplicationDataTypes/{element_type}"
                        # print("replace adt ref from sdb",element_type)
                        break
                    else:
                        pass
                        # print("adt_name not found ",element_type)

        appl_data_type_ref_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
        for adt in replace_adt_list:
            if f"/ApplicationDataTypes/{element_type}" not in [appl_data_type_ref.text for appl_data_type_ref in appl_data_type_ref_list]:
                datatype_mapping = self.create_datatype_mapping(adt)
                # self.insert_section("DATA-TYPE-MAPS",datatype_mapping)

    def create_datatype_mapping(self,adt):
        datatype_mapping = ET.Element("{http://autosar.org/schema/r4.0}DATA-TYPE-MAP")
        appl_data_type_ref = ET.SubElement(datatype_mapping,"{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
        appl_data_type_ref.text = rf"/ApplicationDataTypes/{adt}"
        idt_data_type_ref = ET.SubElement(datatype_mapping,"{http://autosar.org/schema/r4.0}IMPLEMENTATION-DATA-TYPE-REF")
        idt_data_type_ref.text = rf"/HiRain_DataTypeImplementation/{adt}"
        return datatype_mapping

    def replace_port_interface_ref(self,sdb_interface_info_list,common_interface_info_list):
        sdb_inface_name_list = [interface_info["interface_name"] for interface_info in sdb_interface_info_list]
        common_interface_list = [interface_info["interface_name"] for interface_info in common_interface_info_list]
        rport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
        variable_access_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}VARIABLE-ACCESS")
        for rport in rport_list:
            rinterface_tref = rport.find(".//{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
            interface_name = rinterface_tref.text.split("/")[-1]
            if (interface_name in sdb_inface_name_list or interface_name in common_interface_list) and interface_name != "CarCfg":
                match_interface_info = []
                if interface_name in common_interface_list:
                    match_interface_info = [d for d in common_interface_info_list if interface_name == d["interface_name"]][0]
                #     # print("replace port interface from common", interface_name)
                else:
                    # print("replace port interface from sdb", interface_name)
                    match_interface_info = [d for d in sdb_interface_info_list if interface_name == d["interface_name"]][0]
                element_type = list(match_interface_info["element_dict"].values())[0]
                appl_data_type_ref_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
                if f"/ApplicationDataTypes/{element_type}" not in [appl_data_type_ref.text for appl_data_type_ref in appl_data_type_ref_list]:
                    datatype_mapping = self.create_datatype_mapping(element_type)
                    # self.insert_section("DATA-TYPE-MAPS",datatype_mapping)
                for index,interface_dict in enumerate(self.interface_info_list):
                    if interface_dict["interface_name"] == interface_name:
                        self.interface_info_list[index] = match_interface_info 
                element_name = list(match_interface_info["element_dict"].keys())[0]
                
                rinterface_tref.text = f"/PortInterfaces/{interface_name}"
                data_element_ref = rport.find(".//{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
                data_element_ref.text = f"/PortInterfaces/{interface_name}/{element_name}"
                for variable_access in variable_access_list:
                    target_data_ref = variable_access.find(".//{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
                    if target_data_ref.text.split("/")[2] == interface_name:
                        target_data_ref.text = f"/PortInterfaces/{interface_name}/{element_name}"
            else:
                pass
                # print("interface_name not found ",interface_name)    
        
        pport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
        for pport in pport_list:
            pinterface_tref = pport.find(".//{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
            interface_name = pinterface_tref.text.split("/")[-1]
            if (interface_name in sdb_inface_name_list or interface_name in common_interface_list) and interface_name != "CarCfg": 
                if interface_name in common_interface_list:
                    match_interface_info = [d for d in common_interface_info_list if interface_name == d["interface_name"]][0]
                    # print("replace port interface from common", interface_name)
                else:
                    # print("replace port interface from sdb", interface_name)
                    match_interface_info = [d for d in sdb_interface_info_list if interface_name == d["interface_name"]][0]
                    element_type = list(match_interface_info["element_dict"].values())[0]
                    appl_data_type_ref_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}APPLICATION-DATA-TYPE-REF")
                    if f"/ApplicationDataTypes/{element_type}" not in [appl_data_type_ref.text for appl_data_type_ref in appl_data_type_ref_list]:
                        datatype_mapping = self.create_datatype_mapping(element_type)
                        # self.insert_section("DATA-TYPE-MAPS",datatype_mapping)
                for index,interface_dict in enumerate(self.interface_info_list):
                    if interface_dict["interface_name"] == interface_name:
                        self.interface_info_list[index] = match_interface_info 
                element_name = list(match_interface_info["element_dict"].keys())[0]
                pinterface_tref.text = f"/PortInterfaces/{interface_name}"
                data_element_ref = pport.find(".//{http://autosar.org/schema/r4.0}DATA-ELEMENT-REF")
                data_element_ref.text = f"/PortInterfaces/{interface_name}/{element_name}"
                for variable_access in variable_access_list:
                    target_data_ref = variable_access.find(".//{http://autosar.org/schema/r4.0}TARGET-DATA-PROTOTYPE-REF")
                    if target_data_ref.text.split("/")[2] == interface_name:
                        target_data_ref.text = f"/PortInterfaces/{interface_name}/{element_name}"

            else:
                pass
                # print("interface_name not found ",interface_name)
                                                                            
    def get_connection_list(self):
        self.ac_connection_list = []
        self.dc_connection_list = []
        ac_connector_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
        for ac_connector in ac_connector_list:
            ac_connection_short_name = ac_connector.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME")
            if ac_connection_short_name != None:
                self.ac_connection_list.append(ac_connection_short_name.text)
        dc_connector_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
        for dc_connector in dc_connector_list:
            dc_connection_short_name = dc_connector.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME")
            if dc_connection_short_name != None:
                self.dc_connection_list.append(dc_connection_short_name.text)

    def get_port_node(self,port_name):
        rport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
        for rport in rport_list:
            if rport.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text == port_name:
                return rport
        pport_list = self.AUTOSAR.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
        for pport in pport_list:
            if pport.find(".//{http://autosar.org/schema/r4.0}SHORT-NAME").text == port_name:
                return pport
      
    def create_ac_connection(self,pport,rport,composition,corresponding_swc):
        assembly_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
        short_name = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
        if composition != "ZCUD5" and composition != "ZCUP":
            short_name.text = "ac_{}{}_{}{}".format(corresponding_swc[pport["swc_name"]],pport["port_name"],corresponding_swc[rport["swc_name"]],rport["port_name"])
        else:
            short_name.text = "ac_{}{}_{}{}".format(pport["swc_name"],pport["port_name"],rport["swc_name"],rport["port_name"])
        provider_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}PROVIDER-IREF")
        context_component_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
        context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
        if composition != "ZCUD5" and composition != "ZCUP":
            context_component_ref.text = "/{}/{}/{}".format(composition,composition,corresponding_swc[pport["swc_name"]])
        else:
            context_component_ref.text = "/SwComponentType/{}/{}".format(composition,pport["swc_name"])
        target_p_port_ref = ET.SubElement(provider_iref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
        target_p_port_ref.set("DEST", "P-PORT-PROTOTYPE")
        if composition != "ZCUD5" and composition != "ZCUP":
            if pport["swc_name"] == "FltEgyCns":
                target_p_port_ref.text = "/FltEgyCns_1_pkg/FltEgyCns_1_swc/FltEgyCns/{}".format(pport["port_name"])
            else:
                target_p_port_ref.text = "/SwComponentType/{}/{}".format(pport["swc_name"],pport["port_name"])
        else:
            target_p_port_ref.text = "/{}/{}/{}".format(pport["swc_name"],pport["swc_name"],pport["port_name"])
        requester_iref = ET.SubElement(assembly_sw_connector,"{http://autosar.org/schema/r4.0}REQUESTER-IREF")
        context_component_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
        context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")   
        if composition != "ZCUD5" and composition != "ZCUP":    
            context_component_ref.text = "/{}/{}/{}".format(composition,composition,corresponding_swc[rport["swc_name"]])
        else:
            context_component_ref.text = "/SwComponentType/{}/{}".format(composition,rport["swc_name"])

        target_r_port_ref = ET.SubElement(requester_iref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
        target_r_port_ref.set("DEST", "R-PORT-PROTOTYPE")
        if composition != "ZCUD5" and composition != "ZCUP":
            if rport["swc_name"] == "FltEgyCns":
                target_r_port_ref.text = "/FltEgyCns_1_pkg/FltEgyCns_1_swc/FltEgyCns/{}".format(rport["port_name"])
            else:

                target_r_port_ref.text = "/SwComponentType/{}/{}".format(rport["swc_name"],rport["port_name"])
        else:    
            target_r_port_ref.text = "/{}/{}/{}".format(rport["swc_name"],rport["swc_name"],rport["port_name"])
        return assembly_sw_connector
    
    def create_dc_connection(self,port,outer_port,composition,corresponding_swc):
        delegation_sw_connector = ET.Element("{http://autosar.org/schema/r4.0}DELEGATION-SW-CONNECTOR")
        # delegation_sw_connector.set('UUID', str(uuid.uuid4()))
        short_name = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}SHORT-NAME")
        if composition != "ZCUD5" and composition != "ZCUP":
            short_name.text = "dc_{}_{}{}".format(outer_port["port_name"],corresponding_swc[port["swc_name"]],port["port_name"])
        else:
            short_name.text = "dc_{}_{}{}".format(outer_port["port_name"],port["swc_name"],port["port_name"])
        inner_port_iref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}INNER-PORT-IREF")
        if port["port_type"] == "R":
            r_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}R-PORT-IN-COMPOSITION-INSTANCE-REF")
            context_component_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
            context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                context_component_ref.text = "/{}/{}/{}".format(composition,composition,corresponding_swc[port["swc_name"]])
            else:
                context_component_ref.text = "/SwComponentType/{}/{}".format(composition,port["swc_name"])
            target_r_port_ref = ET.SubElement(r_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF")
            target_r_port_ref.set("DEST","R-PORT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                if port["swc_name"] == "FltEgyCns":
                    target_r_port_ref.text = "/FltEgyCns_1_pkg/FltEgyCns_1_swc/FltEgyCns/{}".format(port["port_name"])
                else:
                    target_r_port_ref.text = "/SwComponentType/{}/{}".format(port["swc_name"],port["port_name"]) 
            else:
                target_r_port_ref.text = "/{}/{}/{}".format(port["swc_name"],port["swc_name"],port["port_name"])
            outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
            outer_port_ref.set("DEST", "R-PORT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                outer_port_ref.text = "/{}/{}/{}".format(composition,composition,outer_port["port_name"])
            else:
                outer_port_ref.text = "/SwComponentType/{}/{}".format(composition,outer_port["port_name"])
        else:
            p_port_in_composition_instance_ref = ET.SubElement(inner_port_iref,"{http://autosar.org/schema/r4.0}P-PORT-IN-COMPOSITION-INSTANCE-REF")
            context_component_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF")
            context_component_ref.set("DEST", "SW-COMPONENT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                context_component_ref.text = "/{}/{}/{}".format(composition,composition,corresponding_swc[port["swc_name"]])
            else:
                context_component_ref.text = "/SwComponentType/{}/{}".format(composition,port["swc_name"])
            target_p_port_ref = ET.SubElement(p_port_in_composition_instance_ref,"{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF")
            target_p_port_ref.set("DEST","P-PORT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                if port["swc_name"] == "FltEgyCns":
                    target_p_port_ref.text = "/FltEgyCns_1_pkg/FltEgyCns_1_swc/FltEgyCns/{}".format(port["port_name"])
                else:
                    target_p_port_ref.text = "/SwComponentType/{}/{}".format(port["swc_name"],port["port_name"]) 
            else:
                target_p_port_ref.text = "/{}/{}/{}".format(port["swc_name"],port["swc_name"],port["port_name"])
            outer_port_ref = ET.SubElement(delegation_sw_connector,"{http://autosar.org/schema/r4.0}OUTER-PORT-REF")
            outer_port_ref.set("DEST", "P-PORT-PROTOTYPE")
            if composition != "ZCUD5" and composition != "ZCUP":
                outer_port_ref.text = "/{}/{}/{}".format(composition,composition,outer_port["port_name"])
            else:
                outer_port_ref.text = "/SwComponentType/{}/{}".format(composition,outer_port["port_name"])
        return delegation_sw_connector
