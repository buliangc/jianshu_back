import sys
import os
import json
import threading
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton, QFileDialog,
    QComboBox, QHBoxLayout, QVBoxLayout, QTextEdit, QMessageBox
)
from PyQt5.QtCore import Qt, pyqtSignal

class SimpleConfigGUI(QWidget):
    log_signal = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("工程配置工具")
        self.resize(520, 420)  # 初始大小
        self.setMinimumSize(400, 320)  # 最小大小
        self.init_ui()
        self.set_style()
        self.log_signal.connect(self.append_log)

    def set_style(self):
        self.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #e3f0ff, stop:1 #f9f9fb);
            }
            QLabel {
                color: #1a237e;
                font-size: 15px;
                font-weight: 500;
            }
            QLineEdit, QComboBox {
                border: 2px solid #90caf9;
                border-radius: 12px;
                padding: 7px 12px;
                background: #f7fbff;
                font-size: 15px;
            }
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #42a5f5, stop:1 #7e57c2);
                color: #fff;
                border: none;
                border-radius: 12px;
                padding: 8px 22px;
                font-size: 15px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #7e57c2, stop:1 #42a5f5);
                color: #fff;
            }
            QTextEdit {
                background: #f7fbff;
                border: 2px solid #90caf9;
                border-radius: 12px;
                font-size: 14px;
                color: #263238;
            }
        """)

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 20)
        layout.setSpacing(18)

        # 路径选择
        path_layout = QHBoxLayout()
        path_layout.setSpacing(12)
        path_label = QLabel("工程路径:")
        path_label.setFixedWidth(70)
        self.path_edit = QLineEdit()
        self.path_edit.setMinimumHeight(32)
        self.path_edit.setSizePolicy(self.path_edit.sizePolicy().Expanding, self.path_edit.sizePolicy().verticalPolicy())
        self.path_edit.textChanged.connect(self.adjust_window_width_to_path)
        path_btn = QPushButton("浏览")
        path_btn.setMinimumHeight(32)
        path_btn.setFixedWidth(60)
        path_btn.clicked.connect(self.select_path)
        path_layout.addWidget(path_label)
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(path_btn)
        layout.addLayout(path_layout)

        # 项目类型（对称布局）
        type_layout = QHBoxLayout()
        type_layout.setSpacing(12)
        type_label = QLabel("项目类型:")
        type_label.setFixedWidth(70)
        self.type_combo = QComboBox()
        self.type_combo.addItems(["ZCUD", "ZCUP"])
        self.type_combo.setMinimumHeight(32)
        type_btn_placeholder = QPushButton()
        type_btn_placeholder.setFixedWidth(60)
        type_btn_placeholder.setMinimumHeight(32)
        type_btn_placeholder.setVisible(False)
        type_layout.addWidget(type_label)
        type_layout.addWidget(self.type_combo, 1)
        type_layout.addWidget(type_btn_placeholder)
        layout.addLayout(type_layout)

        # 按钮区（居中）
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(24)
        self.save_btn = QPushButton("保存配置")
        self.save_btn.setMinimumHeight(34)
        self.save_btn.setFixedWidth(100)
        self.save_btn.clicked.connect(self.save_config)
        self.load_btn = QPushButton("加载配置")
        self.load_btn.setMinimumHeight(34)
        self.load_btn.setFixedWidth(100)
        self.load_btn.clicked.connect(self.load_config_dialog)
        self.run_btn = QPushButton("运行")
        self.run_btn.setMinimumHeight(34)
        self.run_btn.setFixedWidth(100)
        self.run_btn.clicked.connect(self.run_action)
        btn_layout.addStretch()
        btn_layout.addWidget(self.save_btn)
        btn_layout.addWidget(self.load_btn)
        btn_layout.addWidget(self.run_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # LOG窗口
        log_label = QLabel("日志输出:")
        layout.addWidget(log_label)
        self.log_edit = QTextEdit()
        self.log_edit.setReadOnly(True)
        self.log_edit.setMinimumHeight(120)
        self.log_edit.setMaximumHeight(160)
        layout.addWidget(self.log_edit)

        self.setLayout(layout)
        self.load_config_on_startup()

    def select_path(self):
        path = QFileDialog.getExistingDirectory(self, "选择工程路径")
        if path:
            self.path_edit.setText(path)
            self.adjust_window_width_to_path(force=True)

    def run_action(self):
        path = self.path_edit.text()
        proj_type = self.type_combo.currentText()
        if not path:
            QMessageBox.warning(self, "提示", "请选择工程路径！")
            return
        # 启动线程
        t = threading.Thread(target=self.run_task, args=(proj_type, path), daemon=True)
        t.start()

    def run_task(self, proj_type, path):
        self.log_signal.emit(f"开始运行项目：{proj_type}，路径：{path}")
        import time
        for i in range(1, 6):
            self.log_signal.emit(f"正在处理第{i}步 ...")
            time.sleep(0.5)
        self.log_signal.emit("运行完成！\n")

    def append_log(self, text):
        self.log_edit.append(text)

    def save_config(self):
        config = {
            "project_path": self.path_edit.text(),
            "project_type": self.type_combo.currentText()
        }
        config_path = os.path.join(os.path.dirname(__file__), "config.json")
        try:
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=4)
            QMessageBox.information(self, "提示", "配置已保存！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存配置失败: {e}")

    def load_config_on_startup(self):
        config_path = os.path.join(os.path.dirname(__file__), "config.json")
        if os.path.exists(config_path):
            self.load_config(config_path)

    def load_config_dialog(self):
        config_path, _ = QFileDialog.getOpenFileName(self, "加载配置", "config.json", "JSON Files (*.json)")
        if config_path:
            self.load_config(config_path)

    def load_config(self, config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            self.path_edit.setText(config.get("project_path", ""))
            idx = self.type_combo.findText(config.get("project_type", ""), Qt.MatchExactly)
            if idx >= 0:
                self.type_combo.setCurrentIndex(idx)
            self.adjust_window_width_to_path(force=True)
            self.log_signal.emit(f"已加载配置：{config_path}")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载配置失败: {e}")

    def adjust_window_width_to_path(self, force=False):
        # 计算路径文本宽度，动态调整窗口宽度
        font_metrics = self.path_edit.fontMetrics()
        text_width = font_metrics.width(self.path_edit.text())
        # 计算其它控件宽度
        base_width = 70 + 60 + 100  # label + button + padding
        min_width = 520
        max_width = 1800  # 防止过大
        new_width = text_width + base_width
        if new_width < min_width:
            new_width = min_width
        if new_width > max_width:
            new_width = max_width
        # 仅在文本超出可视范围或force时才扩展窗口
        edit_width = self.path_edit.width()
        if force or (text_width > edit_width - 20 and new_width > self.width()):
            self.resize(new_width, self.height())

if __name__ == "__main__":
    app = QApplication(sys.argv)
    gui = SimpleConfigGUI()
    gui.show()
    sys.exit(app.exec_())