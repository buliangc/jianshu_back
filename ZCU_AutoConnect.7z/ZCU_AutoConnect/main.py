#!/usr/bin/python
# -*- coding: UTF-8 -*-
from autoconnect import autoconnect
from  autoconnect import cal_only_one_portinterface
from arxml_parse import arxml
import os
import pandas as pd
import openpyxl

def check_interface_element_diff(interface_list:list):
    print("interface different element")
    for index1,interface1 in enumerate(interface_list):
        for index2,interface2 in enumerate(interface_list[index1+1:]):
            if interface1["interface_name"] == interface2["interface_name"] and interface1["element_dict"] != interface2["element_dict"]:
                print({interface1["interface_name"]:[interface1["element_dict"],interface2["element_dict"]]})

def insert_swc_arxml(swc_arxml:arxml):
    # engineering_objects = [
    #     {"SHORT-LABEL": "swc_name_c", "CATEGORY": "SWSRC"},
    #     {"SHORT-LABEL": "swc_name_h", "CATEGORY": "SWHDR"},
    #     {"SHORT-LABEL": "rtwtypes_h", "CATEGORY": "SWHDR"},
    # ]
    engineering_objects = [
        {"SHORT-LABEL": "Default", "CATEGORY": "SWSRC"}
    ]
    code_decribe = swc_arxml.creat_codedec(engineering_objects)
    swc_arxml.insert_section("SWC-IMPLEMENTATION", code_decribe)

    proglang = swc_arxml.create_proglang()
    swc_arxml.insert_section("SWC-IMPLEMENTATION", proglang)

    memory_sections = ["APP_CAL","APP_DISP","APP_DISP_SAFE","APP_NOIRAM","APP_NOIRAM_SAFE","APP_NVM","APP_NVM_SAFE","APP_RUN","APP_RUN_SAFE","CODE"]
    resource_consumption = swc_arxml.create_resource(memory_sections)
    swc_arxml.insert_section("SWC-IMPLEMENTATION", resource_consumption)

    datatype_mapping_ref = swc_arxml.create_datatype_mapping_ref()
    swc_arxml.insert_section("SWC-INTERNAL-BEHAVIOR", datatype_mapping_ref)


if __name__ == "__main__":
    ZCU_workspace_folder_path = "D:\Zcu\ZcuD\ZCUD5_Release_Part1\Workspace"
    print("ZCU_workspace_folder_path",ZCU_workspace_folder_path)
    sdb_arxml_file_path = ZCU_workspace_folder_path + "/ASW/Arxml/common/SDB/SDB22437_ZCUD5_AR-4.2.2_250512_UnFlattened_Swc_NoVer.arxml"   
    sdb_arxml = arxml(sdb_arxml_file_path)
    common_arxml_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/common","common.arxml")
    common_arxml = arxml(common_arxml_path)
    
    geely_cem_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/cemswc/SWC")
    geely_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/cemswc"),"geely_cem.arxml",[geely_cem_floder_path])
    geely_info.composition_name = "geely_cem"

    chassis_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/chassisswc/SWC")
    chassisswc_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/chassisswc"),"chassis.arxml",[chassis_floder_path])
    chassisswc_info.composition_name = "chassis"

    cdtms_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/DTMS/SWC")
    cdtms_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/DTMS"),"CDTMS.arxml",[cdtms_floder_path])
    cdtms_info.composition_name = "CDTMS"

    hcm_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/hcmswc/SWC")
    hcm_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/hcmswc"),"HCM.arxml",[hcm_floder_path])
    hcm_info.composition_name = "HCM"

    geely_basetech_floder_path = os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/BSW/SWC")
    geely_basetech_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/BSW"),"geely_basetech.arxml",[geely_basetech_floder_path])
    geely_basetech_info.composition_name = "geely_basetech"

    supply_floder_path = os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/SUP")
    supply_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/SUP"),"supply.arxml",[supply_floder_path])
    supply_info.composition_name = "supply"

    
    # supply_uaes_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/uaesswc/SWC")
    # supply_bsw_floder_path = os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/SWC")
    # supply_dtms_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/DTMS/SWC")
    # # supply_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml"),"supply.arxml",[supply_uaes_floder_path,supply_bsw_floder_path])
    # supply_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml"),"supply.arxml",[supply_bsw_floder_path,supply_dtms_floder_path])
    # supply_info.composition_name = "supply"


    # ZCU_workspace_folder_path = "D:\Zcu\ZcuD\ZCUD5_Release_Part1\Workspace"
    # print("ZCU_workspace_folder_path",ZCU_workspace_folder_path)
    # sdb_arxml_file_path = ZCU_workspace_folder_path + "/ASW/Arxml/common/SDB/SDB22437_ZCUD5_AR-4.2.2_250512_UnFlattened_Swc_NoVer.arxml"   
    # sdb_arxml = arxml(sdb_arxml_file_path)
    # common_arxml_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/common","common.arxml")
    # common_arxml = arxml(common_arxml_path)
    
    
    # geely_cem_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/cemswc/")
    # geely_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/cemswc"),"geely_cem.arxml",[geely_cem_floder_path])
    # geely_info.composition_name = "geely_cem"

    # supply_uaes_floder_path = os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/uaesswc/")
    # supply_bsw_floder_path = os.path.join(ZCU_workspace_folder_path,"Common_Service/Arxml/")
    # supply_info = autoconnect(os.path.join(ZCU_workspace_folder_path,"ASW/Arxml/common"),"Supply.arxml",[supply_uaes_floder_path, supply_bsw_floder_path])

    # basetech_info = autoconnect(os.path.join(hirain_workspace_folder_path,"ASW/Arxml/hcmswc"),"supply.arxml")
    # basetech_info.composition_name = "supply"
    
    # hirain_info = autoconnect(os.path.join(hirain_workspace_folder_path,"hirainswc"),"hirain_swc.arxml")
    # hirain_info.composition_name = "hirain_swc"

    # supplyswc_info = autoconnect(os.path.join(hirain_workspace_folder_path,"supplyswc"),"supplyswc.arxml")
    # supplyswc_info.composition_name = "supplyswc"

    # all_composition_list = [geely_info,basetech_info,hirain_info,supplyswc_info]
    # all_composition_list = [geely_info,supply_info,chassisswc_info,geely_basetech_info,hcm_info,cdtms_info]
    # all_composition_list = [supply_info]
    all_composition_list = [geely_info,supply_info,chassisswc_info,geely_basetech_info,hcm_info,cdtms_info]

    # # 修正检查hirain arxml文件
    # hirain_swc_total_interface_list = []
    # for hirain_swc_arxml in hirain_info.arxml_list:
    #     # insert_swc_arxml(hirain_swc_arxml)
    #     hirain_swc_arxml.replace_port_interface_ref(sdb_arxml.interface_info_list,common_arxml.interface_info_list)
    #     hirain_swc_arxml.replace_interface_adt_ref(sdb_arxml.adt_name_list)
    #     hirain_swc_arxml.delete_texttable_constr()
    #     hirain_swc_arxml.change_constant_spec()
    #     hirain_swc_arxml.change_idt_UInt32()
    #     hirain_swc_arxml.save(hirain_swc_arxml.file_path)
    #     hirain_swc_total_interface_list = hirain_swc_total_interface_list + (hirain_swc_arxml.interface_info_list) 
    # check_interface_element_diff(hirain_swc_total_interface_list) 
    # hirain_info = autoconnect(os.path.join(hirain_workspace_folder_path,"hirainswc"),"hirain_swc.arxml")
    # hirain_info.composition_name = "hirain_swc"
    # # 修正hirain_swc.arxml 添加swc prototype
    # # hirain_info.composition_arxml.insert_swc_prototype(hirain_info.swc_name_list)
    # # hirain_info.composition_arxml.save(hirain_info.composition_arxml.file_path)

    # # 修正检查hirain arxml文件
    # hirain_swc_total_interface_list = []
    # for hirain_swc_arxml in supplyswc_info.arxml_list:
    #     # insert_swc_arxml(hirain_swc_arxml)
    #     hirain_swc_arxml.replace_port_interface_ref(sdb_arxml.interface_info_list,common_arxml.interface_info_list)
    #     hirain_swc_arxml.replace_interface_adt_ref(sdb_arxml.adt_name_list)
    #     # hirain_swc_arxml.delete_texttable_constr()
    #     # hirain_swc_arxml.change_constant_spec()
    #     # hirain_swc_arxml.change_idt_UInt32()
    #     hirain_swc_arxml.save(hirain_swc_arxml.file_path)
    #     hirain_swc_total_interface_list = hirain_swc_total_interface_list + (hirain_swc_arxml.interface_info_list) 
    # check_interface_element_diff(hirain_swc_total_interface_list) 
    # supplyswc_info = autoconnect(os.path.join(hirain_workspace_folder_path,"supplyswc"),"supplyswc.arxml")
    # supplyswc_info.composition_name = "supplyswc"   
    # 自动连线
    if 0:  



        composition = basetech_info
        other_list = [geely_info,hirain_info]
        composition.connect_network(sdb_arxml,"ZCUD5")
        composition.connect_internal()
        composition.connect_other(other_list,sdb_arxml,"ZCUD5")
        composition.cal_not_connect_port()
        basetech_info.chassis_connect_port_list = basetech_info.internal_connect_port_list
        print(composition.composition_name,"INTERNAL CONNECT",len(composition.internal_connect_port_list))
        # print(composition.internal_connect_port_list)
        print(composition.composition_name,"NETWORK CONNECT",len(set(composition.network_connect_port_list)))
        # print(composition.network_connect_port_list)
        print(composition.composition_name,"GEELY CONNECT",len(set(composition.geely_connect_port_list)))
        # print(composition.geely_connect_port_list)
        # print(composition.composition_name,"BASETECH CONNECT",len(set(composition.supply_connect_port_list)))
        # print(composition.supply_connect_port_list)
        print(composition.composition_name,"HIRAIN CONNECT",len(composition.chassis_connect_port_list))
        # print(composition.chassis_connect_port_list)
        print(composition.composition_name,"NOT CONNECT",len(set(composition.not_connect_port_list)))
        # print(composition.not_connect_port_list)
        print("同时连到geely和network",len(set.intersection(set(basetech_info.geely_connect_port_list),set(basetech_info.network_connect_port_list))))


        # Create a DataFrame from the list of tuples  
        df = pd.DataFrame(composition.not_connect_port_list, columns=['SWC', 'Port', 'Type'])  

        # Define the Excel file path  
        excel_file_path = composition.composition_name + 'not_connect_ports.xlsx'  

        # Write the DataFrame to an Excel file  
        df.to_excel(excel_file_path, index=False)  

        print(f"Data written to Excel file '{excel_file_path}' successfully.") 

        # hirain_info自动连线


        # composition = hirain_info
        # other_list = [geely_info,basetech_info]
        # composition.connect_network(sdb_arxml,"ZCUD")
        # composition.connect_internal()
        # composition.connect_other(other_list,sdb_arxml,"ZCUD")
        # composition.cal_not_connect_port()
        # hirain_info.chassis_connect_port_list = hirain_info.internal_connect_port_list
        # print(composition.composition_name,"INTERNAL CONNECT",len(composition.internal_connect_port_list))
        # # print(composition.internal_connect_port_list)
        # print(composition.composition_name,"NETWORK CONNECT",len(set(composition.network_connect_port_list)))
        # # print(composition.network_connect_port_list)
        # print(composition.composition_name,"GEELY CONNECT",len(set(composition.geely_connect_port_list)))
        # # print(composition.geely_connect_port_list)
        # print(composition.composition_name,"BASETECH CONNECT",len(set(composition.supply_connect_port_list)))
        # # print(composition.supply_connect_port_list)
        # # print(composition.composition_name,"HIRAIN CONNECT",len(composition.chassis_connect_port_list))
        # # print(composition.chassis_connect_port_list)
        # print(composition.composition_name,"NOT CONNECT",len(set(composition.not_connect_port_list)))
        # # print(composition.not_connect_port_list)
        # print("同时连到geely和network",len(set.intersection(set(hirain_info.geely_connect_port_list),set(hirain_info.network_connect_port_list))))

    else:  # 连线所有
        for composition in all_composition_list:
            
            if composition.composition_name == "supply":
                print("composition1",composition.composition_name)
                other_list = [other_composition for other_composition in all_composition_list if other_composition != composition]
                composition.connect_network_supply(sdb_arxml,"ZCUD5")
                composition.connect_other_supply(other_list,sdb_arxml,"ZCUD5")
            else:
                print("composition2",composition.composition_name)
                other_list = [other_composition for other_composition in all_composition_list if other_composition != composition]
                composition.connect_network(sdb_arxml,"ZCUD5")
                composition.connect_internal()
                # print("other_list",other_list)
                composition.connect_other(other_list,sdb_arxml,"ZCUD5")
                composition.cal_not_connect_port()
                # hirain_info.chassis_connect_port_list = hirain_info.internal_connect_port_list
                # geely_info.geely_connect_port_list = geely_info.internal_connect_port_list
                # basetech_info.supply_connect_port_list = basetech_info.internal_connect_port_list
                
                print(composition.composition_name,"INTERNAL CONNECT",len(composition.internal_connect_port_list))
                # print(composition.internal_connect_port_list)
                print(composition.composition_name,"NETWORK CONNECT",len(composition.network_connect_port_list))
                # print(composition.network_connect_port_list)
                print(composition.composition_name,"GEELY CONNECT",len(composition.geely_connect_port_list))
                # print(composition.geely_connect_port_list)
                print(composition.composition_name,"Supply CONNECT",len(composition.supply_connect_port_list))
                # print(composition.supply_connect_port_list)
                print(composition.composition_name,"CHASSIS CONNECT",len(composition.chassis_connect_port_list))

                print(composition.composition_name,"CHASSIS CONNECT",len(composition.cdtms_connect_port_list))

                print(composition.composition_name,"CHASSIS CONNECT",len(composition.hcm_connect_port_list))

                print(composition.composition_name,"CHASSIS CONNECT",len(composition.geely_basetech_connect_port_list))
                # print(composition.chassis_connect_port_list)
                print(composition.composition_name,"NOT CONNECT",len(set(composition.not_connect_port_list)))
                # print(composition.not_connect_port_list)
                            # Create a DataFrame from the list of tuples  
                df = pd.DataFrame(composition.not_connect_port_list, columns=['SWC', 'Port', 'Type'])  

                # Define the Excel file path  
                excel_file_path = "ZCUD_" + composition.composition_name + '_not_connect_ports_24R3_01.xlsx'  

                # Write the DataFrame to an Excel file  
                df.to_excel(excel_file_path, index=False)   

                print(f"Data written to Excel file '{excel_file_path}' successfully.") 
    # 更新excel
    # excel_folder = "D:/01_ProjectFiles/03_Hirain/01_Git/H_Release_Source/2.HR_ARCH/1.ARXML/HR_WIN_SEAT_PEPS/ZCUD/"
    # excel_list = [file for file in os.listdir(excel_folder) if file.endswith(".xlsx")]
    # for excel_file in excel_list:
    #     file_path = os.path.join(excel_folder,excel_file)
    #     change_excel(file_path,composition,sdb_arxml,all_composition_list)
        