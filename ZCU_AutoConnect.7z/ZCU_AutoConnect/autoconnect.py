#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
from arxml_parse import arxml

testtype = True

class autoconnect(object):
    def __init__(self, composition_path:str,composition_arxml_name:str,composition_swc_list_path):
        self.composition_path = composition_path
        self.composition_arxml_name = composition_arxml_name
        self.composition_swc_list_path = composition_swc_list_path
        self.arxml_list = []
        self.swc_name_list = []
        self.internal_connect_port_list = []
        self.network_connect_port_list = []
        self.geely_connect_port_list = []
        self.chassis_connect_port_list = []
        self.supply_connect_port_list = []
        self.geely_basetech_connect_port_list = []
        self.hcm_connect_port_list = []
        self.cdtms_connect_port_list = []
        self.not_connect_port_list = []
        self.composition_arxml = None
        self.composition_name = None
        self.parser_arxml_folder(self.composition_path,self.composition_arxml_name,self.composition_swc_list_path)
    def parser_arxml_folder(self,composition_path:str,composition_arxml_name:str,subfolders):
        total_port_list = []
        print("arxml解析分类中...")
        print("waiting...")
        print("start parser arxml folder",composition_path,composition_arxml_name,subfolders)
        # print("start parser arxml folder",composition_path,composition_arxml_name,subfolders)
        for subfolder in subfolders:
            folder_path = subfolder
            exclude_files = ['BswMBaseType.arxml']
            arxml_file_list = [file for file in os.listdir(folder_path)if file.endswith(".arxml") and file not in exclude_files]
            # arxml_file_list = [file for file in os.listdir(folder_path) if file.endswith(".arxml")]
            for file in arxml_file_list:
                # print("file",file)
                file_path = os.path.join(folder_path, file)
                current_arxml = arxml(file_path)
                # print("current_arxml.swc_name",current_arxml.port_info_list)
                self.arxml_list.append(current_arxml)
                self.swc_name_list.append(current_arxml.swc_name)
                total_port_list.extend(current_arxml.port_info_list)
        composition_arxml_path = os.path.join(composition_path,composition_arxml_name)
        self.composition_arxml = arxml(composition_arxml_path)
        
        self.composition_arxml.composition_total_port_list = total_port_list  
        # print(self.composition_arxml.composition_total_port_list) 

    
    def connect_internal(self):
        self.total_rport_list = []
        self.total_pport_list = []
        for port in self.composition_arxml.composition_total_port_list:
            if port["port_type"] == "R":
                self.total_rport_list.append(port)
            else:
                self.total_pport_list.append(port)
        for rport in self.total_rport_list:
            for pport in self.total_pport_list:
                # if self.composition_name == "basetech":
                #     compare = (pport["port_name"] == rport["port_name"])
                # else:
                #     compare = (pport["interface_ref"] == rport["interface_ref"])
                # if compare and pport["swc_name"] != rport["swc_name"]:
                if pport["interface_ref"] == rport["interface_ref"] and pport["swc_name"] != rport["swc_name"]:
                    self.internal_connect_port_list.append((pport["swc_name"],pport["port_name"]))
                    self.internal_connect_port_list.append((rport["swc_name"],rport["port_name"]))
                    ac_connection_short_name = "ac_{}{}_{}{}".format(self.composition_arxml.corresponding_swc[pport["swc_name"]],pport["port_name"],self.composition_arxml.corresponding_swc[rport["swc_name"]],rport["port_name"])
                    if ac_connection_short_name not in self.composition_arxml.ac_connection_list:
                        self.composition_arxml.ac_connection_list.append(ac_connection_short_name)
                        ac_connection =  self.composition_arxml.create_ac_connection(pport,rport,self.composition_name,self.composition_arxml.corresponding_swc)
                        self.composition_arxml.insert_section("CONNECTORS",ac_connection)
        self.composition_arxml.save(os.path.join(self.composition_path,self.composition_arxml_name))

    def connect_network_supply(self,sdb_arxml:arxml,zcu_type = "ZCUD5"):
        # print("net",self.composition_arxml.composition_total_port_list)
        for port in self.composition_arxml.composition_total_port_list: 
            for sdb_port in sdb_arxml.port_info_list:
                if port["interface_ref"] == sdb_port["interface_ref"] and port["port_type"] == sdb_port["port_type"]:
                    
                    # if port["swc_name"] == "IoHwAb":
                    #     continue
                        # self.chassis_connect_port_list.append((port["swc_name"],port["port_name"]))

                    self.network_connect_port_list.append((port["swc_name"],port["port_name"]))
                    # print(self.composition_arxml.corresponding_swc)
                    # dc_connection_composition_name = "dc_{}_{}{}".format(port["port_name"],self.composition_arxml.corresponding_swc[port["swc_name"]],port["port_name"])
                    dc_connection_sdb_name = "dc_{}_{}{}".format(sdb_port["port_name"],self.composition_name,port["port_name"])
                    composition_port_info = {"port_name":port["port_name"],"port_type":port["port_type"],"interface_ref":port["interface_ref"],\
                                    "data_element_ref_list":port["data_element_ref_list"],"init_value":port["init_value"],"swc_name":self.composition_name}
                    # if dc_connection_composition_name not in self.composition_arxml.dc_connection_list:
                    #     self.composition_arxml.dc_connection_list.append(dc_connection_composition_name)
                    #     dc_connection =  self.composition_arxml.create_dc_connection(port,port,self.composition_name,self.composition_arxml.corresponding_swc)
                    #     self.composition_arxml.insert_section("CONNECTORS",dc_connection)
                    # if port["port_name"] not in [port_info["port_name"] for port_info in self.composition_arxml.port_info_list]:   
                    #     port_node = self.arxml_list[self.swc_name_list.index(port["swc_name"])].get_port_node(port["port_name"])
                    #     self.composition_arxml.insert_section("PORTS",port_node)
                    #     self.composition_arxml.port_info_list.append(composition_port_info)
                    # print("dc_connection_sdb_name",dc_connection_sdb_name)
                    

                    if dc_connection_sdb_name not in sdb_arxml.dc_connection_list:
                        # print(port["port_name"])
                        sdb_arxml.dc_connection_list.append(dc_connection_sdb_name)
                        dc_connection =  sdb_arxml.create_dc_connection(composition_port_info,sdb_port,zcu_type,self.composition_arxml.corresponding_swc)
                        sdb_arxml.insert_section("CONNECTORS",dc_connection)
        self.composition_arxml.save(os.path.join(self.composition_path,self.composition_arxml_name))
        # print("sdb_arxml",sdb_arxml.dc_connection_list)
        print("file_path",sdb_arxml.file_path)

        sdb_arxml.save(sdb_arxml.file_path)

    def connect_other_supply(self,other_list:list["autoconnect"],sdb_arxml:arxml,zcu_type = "ZCUD5"):
        for other in other_list:
            for port in self.composition_arxml.composition_total_port_list: 
                for other_port in other.composition_arxml.composition_total_port_list:
                    # if other.composition_name == "basetech" or self.composition_name == "basetech":
                    #     compare = (port["port_name"] == other_port["port_name"])
                    # else:
                    #     compare = (port["interface_ref"] == other_port["interface_ref"])
                    # if compare and port["port_type"] != other_port["port_type"]:
                    if port["interface_ref"] == other_port["interface_ref"] and port["port_type"] != other_port["port_type"]:
                        # print(port["interface_ref"],other_port["interface_ref"])
                        if other.composition_name == "geely_cem":
                            self.geely_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "chassis":
                            self.chassis_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "geely_basetech":
                            self.geely_basetech_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "CDTMS":
                            self.cdtms_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "HCM":
                            self.hcm_connect_port_list.append((port["swc_name"],port["port_name"]))
                        
                        else:
                            print("error port connect error ")
                            # self.chassis_connect_port_list.append((port["swc_name"],port["port_name"]))
                        composition_port_info = {"port_name":port["port_name"],"port_type":port["port_type"],"interface_ref":port["interface_ref"],\
                                        "data_element_ref_list":port["data_element_ref_list"],"init_value":port["init_value"],"swc_name":self.composition_name}
                        # dc_connection_name = "dc_{}_{}{}".format(port["port_name"],self.composition_arxml.corresponding_swc[port["swc_name"]],port["port_name"])
                        
                        other_composition_port_info = {"port_name":other_port["port_name"],"port_type":other_port["port_type"],"interface_ref":other_port["interface_ref"],\
                                        "data_element_ref_list":other_port["data_element_ref_list"],"init_value":other_port["init_value"],"swc_name":other.composition_name}
                        # print(other_port["port_name"],other_port["port_name"],other_port["swc_name"])
                        # print(other.composition_arxml.corresponding_swc)
                        dc_connection_other_name = "dc_{}_{}{}".format(other_port["port_name"],other.composition_arxml.corresponding_swc[other_port["swc_name"]],other_port["port_name"])
                        # if dc_connection_name not in self.composition_arxml.dc_connection_list:
                        #     self.composition_arxml.dc_connection_list.append(dc_connection_name)
                        #     dc_connection =  self.composition_arxml.create_dc_connection(port,port,self.composition_name,self.composition_arxml.corresponding_swc)
                        #     self.composition_arxml.insert_section("CONNECTORS",dc_connection)
                        if dc_connection_other_name not in other.composition_arxml.dc_connection_list:
                            other.composition_arxml.dc_connection_list.append(dc_connection_other_name)
                            dc_connection =  other.composition_arxml.create_dc_connection(other_port,other_port,other.composition_name,other.composition_arxml.corresponding_swc)
                            other.composition_arxml.insert_section("CONNECTORS",dc_connection)
                        if port["port_name"] not in [port_info["port_name"] for port_info in self.composition_arxml.port_info_list]:  
                            port_node = self.arxml_list[self.swc_name_list.index(port["swc_name"])].get_port_node(port["port_name"])
                            self.composition_arxml.insert_section("PORTS",port_node)
                            self.composition_arxml.port_info_list.append(composition_port_info)
                        if other_port["port_name"] not in [port_info["port_name"] for port_info in other.composition_arxml.port_info_list]:   
                            port_node = other.arxml_list[other.swc_name_list.index(other_port["swc_name"])].get_port_node(other_port["port_name"])
                            other.composition_arxml.insert_section("PORTS",port_node)
                            other.composition_arxml.port_info_list.append(other_composition_port_info)
                        
                        if port["port_type"] == "R":
                            ac_connection_sdb_name = "ac_{}{}_{}{}".format(other.composition_name,other_port["port_name"],self.composition_name,port["port_name"])
                        else:
                            ac_connection_sdb_name = "ac_{}{}_{}{}".format(self.composition_name,port["port_name"],other.composition_name,other_port["port_name"])
                        if ac_connection_sdb_name not in sdb_arxml.ac_connection_list:
                            sdb_arxml.ac_connection_list.append(ac_connection_sdb_name)
                            if port["port_type"] == "R":
                                ac_connection =  sdb_arxml.create_ac_connection(other_composition_port_info,composition_port_info,zcu_type,self.composition_arxml.corresponding_swc)
                            else:
                                ac_connection =  sdb_arxml.create_ac_connection(composition_port_info,other_composition_port_info,zcu_type,self.composition_arxml.corresponding_swc)
                            sdb_arxml.insert_section("CONNECTORS",ac_connection)
        
        self.composition_arxml.save(os.path.join(self.composition_path,self.composition_arxml_name))
        sdb_arxml.save(sdb_arxml.file_path)
        for other in other_list:
            other.composition_arxml.save(os.path.join(other.composition_path,other.composition_arxml_name))

    def connect_network(self,sdb_arxml:arxml,zcu_type = "ZCUD5"):
        # print("net",self.composition_arxml.composition_total_port_list)
        for port in self.composition_arxml.composition_total_port_list: 
            for sdb_port in sdb_arxml.port_info_list:
                if port["interface_ref"] == sdb_port["interface_ref"] and port["port_type"] == sdb_port["port_type"]:
                    self.network_connect_port_list.append((port["swc_name"],port["port_name"]))
                    # print(self.composition_arxml.corresponding_swc)
                    dc_connection_composition_name = "dc_{}_{}{}".format(port["port_name"],self.composition_arxml.corresponding_swc[port["swc_name"]],port["port_name"])
                    dc_connection_sdb_name = "dc_{}_{}{}".format(sdb_port["port_name"],self.composition_name,port["port_name"])
                    composition_port_info = {"port_name":port["port_name"],"port_type":port["port_type"],"interface_ref":port["interface_ref"],\
                                    "data_element_ref_list":port["data_element_ref_list"],"init_value":port["init_value"],"swc_name":self.composition_name}
                    if dc_connection_composition_name not in self.composition_arxml.dc_connection_list:
                        self.composition_arxml.dc_connection_list.append(dc_connection_composition_name)
                        dc_connection =  self.composition_arxml.create_dc_connection(port,port,self.composition_name,self.composition_arxml.corresponding_swc)
                        self.composition_arxml.insert_section("CONNECTORS",dc_connection)
                    if port["port_name"] not in [port_info["port_name"] for port_info in self.composition_arxml.port_info_list]:   
                        port_node = self.arxml_list[self.swc_name_list.index(port["swc_name"])].get_port_node(port["port_name"])
                        self.composition_arxml.insert_section("PORTS",port_node)
                        self.composition_arxml.port_info_list.append(composition_port_info)
                    if dc_connection_sdb_name not in sdb_arxml.dc_connection_list:
                        sdb_arxml.dc_connection_list.append(dc_connection_sdb_name)
                        dc_connection =  sdb_arxml.create_dc_connection(composition_port_info,sdb_port,zcu_type,self.composition_arxml.corresponding_swc)
                        sdb_arxml.insert_section("CONNECTORS",dc_connection)
        self.composition_arxml.save(os.path.join(self.composition_path,self.composition_arxml_name))
        sdb_arxml.save(sdb_arxml.file_path)

    # def connect_other(self, other_list: list["autoconnect"], sdb_arxml: arxml, zcu_type: str = "ZCUD5", handle_supply: bool = True):
    #     for other in other_list:
    #         for port in self.composition_arxml.composition_total_port_list:
    #             for other_port in other.composition_arxml.composition_total_port_list:
    #                 if port["interface_ref"] == other_port["interface_ref"] and port["port_type"] != other_port["port_type"]:
    #                     if other.composition_name == "geely_cem":
    #                         self.geely_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                     elif other.composition_name == "supply":
    #                         if handle_supply:
    #                             self.supply_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                         else:
    #                             continue  # 跳过supply组件的连接处理
    #                     elif other.composition_name == "chassis":
    #                         self.chassis_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                     elif other.composition_name == "geely_basetech":
    #                         self.geely_basetech_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                     elif other.composition_name == "CDTMS":
    #                         self.cdtms_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                     elif other.composition_name == "HCM":
    #                         self.hcm_connect_port_list.append((port["swc_name"], port["port_name"]))
    #                     else:
    #                         print("error port connect error ")

    #                     composition_port_info = {
    #                         "port_name": port["port_name"],
    #                         "port_type": port["port_type"],
    #                         "interface_ref": port["interface_ref"],
    #                         "data_element_ref_list": port["data_element_ref_list"],
    #                         "init_value": port["init_value"],
    #                         "swc_name": self.composition_name
    #                     }

    #                     other_composition_port_info = {
    #                         "port_name": other_port["port_name"],
    #                         "port_type": other_port["port_type"],
    #                         "interface_ref": other_port["interface_ref"],
    #                         "data_element_ref_list": other_port["data_element_ref_list"],
    #                         "init_value": other_port["init_value"],
    #                         "swc_name": other.composition_name
    #                     }

    #                     if port["swc_name"] == "IoHwAb":
    #                         continue
    #                     else:
    #                     # 处理当前组件的连接
    #                         if handle_supply or other.composition_name != "supply":
    #                             dc_connection_name = "dc_{}_{}{}".format(
    #                                 port["port_name"],
    #                                 self.composition_arxml.corresponding_swc[port["swc_name"]],
    #                                 port["port_name"]
    #                             )
    #                             if dc_connection_name not in self.composition_arxml.dc_connection_list:
    #                                 self.composition_arxml.dc_connection_list.append(dc_connection_name)
    #                                 dc_connection = self.composition_arxml.create_dc_connection(
    #                                     port, port, self.composition_name, self.composition_arxml.corresponding_swc
    #                                 )
    #                                 self.composition_arxml.insert_section("CONNECTORS", dc_connection)
    #                     if other_port["swc_name"] == "IoHwAb":
    #                         continue
    #                     else:
    #                         # continue
    #                     # 处理其他组件的连接
    #                         dc_connection_other_name = "dc_{}_{}{}".format(
    #                             other_port["port_name"],
    #                             other.composition_arxml.corresponding_swc[other_port["swc_name"]],
    #                             other_port["port_name"]
    #                         )
    #                     if dc_connection_other_name not in other.composition_arxml.dc_connection_list:
    #                         other.composition_arxml.dc_connection_list.append(dc_connection_other_name)
    #                         dc_connection = other.composition_arxml.create_dc_connection(
    #                             other_port, other_port, other.composition_name, other.composition_arxml.corresponding_swc
    #                         )
    #                         other.composition_arxml.insert_section("CONNECTORS", dc_connection)
    
    def connect_other(self,other_list:list["autoconnect"],sdb_arxml:arxml,zcu_type = "ZCUD5"):
        for other in other_list:
            for port in self.composition_arxml.composition_total_port_list: 
                for other_port in other.composition_arxml.composition_total_port_list:
                    # if other.composition_name == "basetech" or self.composition_name == "basetech":
                    #     compare = (port["port_name"] == other_port["port_name"])
                    # else:
                    #     compare = (port["interface_ref"] == other_port["interface_ref"])
                    # if compare and port["port_type"] != other_port["port_type"]:
                    if port["interface_ref"] == other_port["interface_ref"] and port["port_type"] != other_port["port_type"]:
                        # print(port["interface_ref"],other_port["interface_ref"])
                        if other.composition_name == "geely_cem":
                            self.geely_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "supply":
                            
                            self.supply_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "chassis":
                            self.chassis_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "geely_basetech":
                            self.geely_basetech_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "CDTMS":
                            self.cdtms_connect_port_list.append((port["swc_name"],port["port_name"]))
                        elif other.composition_name == "HCM":
                            self.hcm_connect_port_list.append((port["swc_name"],port["port_name"]))
                        
                        else:
                            print("error port connect error ")
                            # self.chassis_connect_port_list.append((port["swc_name"],port["port_name"]))
                        composition_port_info = {"port_name":port["port_name"],"port_type":port["port_type"],"interface_ref":port["interface_ref"],\
                                        "data_element_ref_list":port["data_element_ref_list"],"init_value":port["init_value"],"swc_name":self.composition_name}
                        dc_connection_name = "dc_{}_{}{}".format(port["port_name"],self.composition_arxml.corresponding_swc[port["swc_name"]],port["port_name"])
                        
                        other_composition_port_info = {"port_name":other_port["port_name"],"port_type":other_port["port_type"],"interface_ref":other_port["interface_ref"],\
                                        "data_element_ref_list":other_port["data_element_ref_list"],"init_value":other_port["init_value"],"swc_name":other.composition_name}
                        # print(other_port["port_name"],other_port["port_name"],other_port["swc_name"])
                        # print(other.composition_arxml.corresponding_swc)
                        if other.composition_name == "supply":
                            continue
                        else:
                            dc_connection_other_name = "dc_{}_{}{}".format(other_port["port_name"],other.composition_arxml.corresponding_swc[other_port["swc_name"]],other_port["port_name"])
                            if dc_connection_other_name not in other.composition_arxml.dc_connection_list:
                                other.composition_arxml.dc_connection_list.append(dc_connection_other_name)
                                dc_connection =  other.composition_arxml.create_dc_connection(other_port,other_port,other.composition_name,other.composition_arxml.corresponding_swc)
                                other.composition_arxml.insert_section("CONNECTORS",dc_connection)
                        if dc_connection_name not in self.composition_arxml.dc_connection_list:
                            self.composition_arxml.dc_connection_list.append(dc_connection_name)
                            dc_connection =  self.composition_arxml.create_dc_connection(port,port,self.composition_name,self.composition_arxml.corresponding_swc)
                            self.composition_arxml.insert_section("CONNECTORS",dc_connection)
                        
                        if port["port_name"] not in [port_info["port_name"] for port_info in self.composition_arxml.port_info_list]: 
                            port_node = self.arxml_list[self.swc_name_list.index(port["swc_name"])].get_port_node(port["port_name"])
                            self.composition_arxml.insert_section("PORTS",port_node)
                            self.composition_arxml.port_info_list.append(composition_port_info)
                        if other_port["port_name"] not in [port_info["port_name"] for port_info in other.composition_arxml.port_info_list]:   
                            port_node = other.arxml_list[other.swc_name_list.index(other_port["swc_name"])].get_port_node(other_port["port_name"])
                            other.composition_arxml.insert_section("PORTS",port_node)
                            other.composition_arxml.port_info_list.append(other_composition_port_info)
                        
                        if port["port_type"] == "R":
                            ac_connection_sdb_name = "ac_{}{}_{}{}".format(other.composition_name,other_port["port_name"],self.composition_name,port["port_name"])
                        else:
                            ac_connection_sdb_name = "ac_{}{}_{}{}".format(self.composition_name,port["port_name"],other.composition_name,other_port["port_name"])
                        if ac_connection_sdb_name not in sdb_arxml.ac_connection_list:
                            sdb_arxml.ac_connection_list.append(ac_connection_sdb_name)
                            if port["port_type"] == "R":
                                ac_connection =  sdb_arxml.create_ac_connection(other_composition_port_info,composition_port_info,zcu_type,self.composition_arxml.corresponding_swc)
                            else:
                                ac_connection =  sdb_arxml.create_ac_connection(composition_port_info,other_composition_port_info,zcu_type,self.composition_arxml.corresponding_swc)
                            sdb_arxml.insert_section("CONNECTORS",ac_connection)
        
        self.composition_arxml.save(os.path.join(self.composition_path,self.composition_arxml_name))
        sdb_arxml.save(sdb_arxml.file_path)
        for other in other_list:
            other.composition_arxml.save(os.path.join(other.composition_path,other.composition_arxml_name))

    def cal_not_connect_port(self):
        total_connect_port = self.internal_connect_port_list + self.geely_connect_port_list + self.network_connect_port_list + \
                            self.chassis_connect_port_list + self.supply_connect_port_list+ self.hcm_connect_port_list+ self.cdtms_connect_port_list+ self.geely_basetech_connect_port_list
        port_connect_flag = False
        for port_info in self.composition_arxml.composition_total_port_list:
            for connect_port in total_connect_port:
                if port_info["swc_name"] == connect_port[0] and port_info["port_name"] == connect_port[1]:
                    port_connect_flag = True
                    break 
            if  port_connect_flag == True:
                port_connect_flag = False
            else:
                self.not_connect_port_list.append((port_info["swc_name"],port_info["port_name"],port_info["port_type"]))
    def not_connect_only_one_portinfercase(self,all_only_one_portinterface_list:list,sdb_arxml:arxml):
        not_connect_port_name_list = [port_info[1] for port_info in self.not_connect_port_list] 
        only_one_portinterface_list = [only_one_portinterface for only_one_portinterface in all_only_one_portinterface_list if only_one_portinterface in not_connect_port_name_list]
        sdb_port_list = [port_info["port_name"] for port_info in sdb_arxml.port_info_list]
        sdb_diff_port_type_list = [port_name for port_name in only_one_portinterface_list if port_name in  sdb_port_list]
        return [only_one_portinterface_list,sdb_diff_port_type_list]

def cal_only_one_portinterface(all_composition_list:list[autoconnect],sdb_arxml:arxml):
    all_only_one_portinterface_list = []
    total_port_info_list = []
    for composition in all_composition_list:
        total_port_info_list = total_port_info_list + composition.composition_arxml.composition_total_port_list
    
    composition_tuple_sets = set((d["interface_ref"],d["port_type"],d["port_name"]) for d in total_port_info_list )
    # sdb_tuple_sets = set((d["interface_ref"],d["port_type"],d["port_name"]) for d in sdb_arxml.composition_total)

    for tuple1  in composition_tuple_sets:
        match_found = False 
        for tuple2  in composition_tuple_sets:
            if tuple1[0] == tuple2[0] and tuple1[1] != tuple2[1]:
                match_found = True
        # for tuple3 in sdb_tuple_sets:
        #     if tuple1[0] == tuple3[0] and tuple1[1] == tuple3[1]:
        #         match_found = True
        if not match_found:   
            all_only_one_portinterface_list.append(tuple1[2])
    return all_only_one_portinterface_list




