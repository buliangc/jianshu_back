import xml.etree.ElementTree as ET

def Add_PortInterfaces_Element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    Elements = PortInterfacesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    Elements.append(element)

def Add_SwComponentType_Port_Element(root,swc,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    Elements = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Elements.append(element)

# 客户端 SERVER-CALL-POINTS
def Add_SwComponentType_SyncServerCallPoint(root,swc,element,ClientPort_Port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == ClientPort_Port["Runnable_Entity"]:
            runnables_entityPkg = child
            break
    Elements = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}SERVER-CALL-POINTS")
    if Elements == None:
        server_call_points=ET.SubElement(runnables_entityPkg,'{http://autosar.org/schema/r4.0}SERVER-CALL-POINTS')
        server_call_points.append(element)
    else:
        Elements.append(element)
    
# 服务端添加Runnable
def Add_SwComponentType_Runnable(root,swc,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")

    runnables_entity = swc_internal_behaviorsPkg.find("./{http://autosar.org/schema/r4.0}RUNNABLES")
    runnables_entity.append(element)

def Add_SwComponentType_OperationEvent(root,swc,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")

    events = swc_internal_behaviorsPkg.find("./{http://autosar.org/schema/r4.0}EVENTS")
    events.append(element)

def Add_Geely_sw_connector_element(root,element):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    Elements = GeelyPkg.find("./{http://autosar.org/schema/r4.0}CONNECTORS")
    Elements.append(element)
    