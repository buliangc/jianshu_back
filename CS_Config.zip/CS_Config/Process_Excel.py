import pandas as pd
import openpyxl

# R Port
def Get_Client_Port_Dict(filepath,sheetname):
    Client_Port_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname)
    i = 0
    while i < len(df.values):
        Client_Port_Dict = {}
        Client_Port_Dict["SWC"] = df.values[i][0]
        Client_Port_Dict["Client_Port_List"] = [{"SWC":df.values[i][0], "Runnable_Entity":df.values[i][1], "Client_Port":df.values[i][2], "Interface":df.values[i][3] , "Operation":df.values[i][4],"Access_SWC":df.values[i][6]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Client_Port_Dict["Client_Port_List"].append({"SWC":df.values[i][0], "Runnable_Entity":df.values[i][1], "Client_Port":df.values[i][2], "Interface":df.values[i][3] , "Operation":df.values[i][4],"Access_SWC":df.values[i][6]})
            i = i + 1
        Client_Port_Dict_List.append(Client_Port_Dict)
    return Client_Port_Dict_List

# Get_Client_Port_Dict("./CS_Config/驱动新增接口汇总ZCUP_23R3_U2_01_03.xlsx", "Client Port")

# P Port
def Get_Server_Port_Dict(filepath,sheetname):
    Server_Port_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname)
    i = 0
    while i < len(df.values):
        Server_Port_Dict = {}
        Server_Port_Dict["SWC"] = df.values[i][0]
        Server_Port_Dict["Server_Port_List"] = [{"SWC":df.values[i][0], "Runnable_Entity":df.values[i][1], "Server_Port":df.values[i][2], "Interface":df.values[i][3] , "Operation":df.values[i][4],"Access_SWC":df.values[i][6]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Server_Port_Dict["Server_Port_List"].append({"SWC":df.values[i][0], "Runnable_Entity":df.values[i][1], "Server_Port":df.values[i][2], "Interface":df.values[i][3] , "Operation":df.values[i][4],"Access_SWC":df.values[i][6]})
            i = i + 1
        Server_Port_Dict_List.append(Server_Port_Dict)
    return Server_Port_Dict_List

def Get_InterfaceLib_Dict(filepath, sheetname):  
    InterfaceLib_Dict_List = []  
    df = pd.read_excel(filepath, sheet_name=sheetname)  
    
    # 用于存储接口及其操作的信息  
    interface_dict = {}  

    for i in range(len(df.values)):  
        interface_name = df.values[i][0]  
        operation_name = df.values[i][2]  

        # 如果接口还不存在，初始化接口字典  
        if interface_name not in interface_dict:  
            interface_dict[interface_name] = {  
                "InterfaceName": interface_name,  
                "Operations": []  
            }  

        # 查找当前操作是否已存在于接口的操作中  
        operation_found = False  
        for operation in interface_dict[interface_name]["Operations"]:  
            if operation_name in operation:  
                operation_found = True  
                # 添加参数到现有的操作  
                argument_dict = {  
                    'ArgumentsName': df.values[i][4],  
                    'ArgumentsType': df.values[i][5],  
                    'ArgumentsKind': df.values[i][6]  
                }  
                operation[operation_name].append(argument_dict)  
                break  
        
        # 如果操作不存在，添加一个新的操作  
        if not operation_found:  
            argument_dict = {  
                'ArgumentsName': df.values[i][4],  
                'ArgumentsType': df.values[i][5],  
                'ArgumentsKind': df.values[i][6]  
            }  
            new_operation = {operation_name: [argument_dict]}  
            interface_dict[interface_name]["Operations"].append(new_operation)  

    # 将整理好的接口字典转换为列表  
    InterfaceLib_Dict_List = list(interface_dict.values())  

    return InterfaceLib_Dict_List

# Get_InterfaceLib_Dict("./CS_Config/驱动新增接口汇总ZCUP_23R3_U2_01_03.xlsx", "Interface Lib")
# [
#     {
#         'InterfaceName': 'algo_add_dtcRecord', 
#         'Operations': [
#             {
#                 'algo_add_dtcRecord': [
#                     {'ArgumentsName': 'dtc_record_num', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'pass_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'failed_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}
#                 ]
#             }
#         ]
#     }, 
#     {
#         'InterfaceName': 'algo_dtc_write_record', 
#         'Operations': [
#             {
#                 'algo_dtc_write_record': [
#                     {'ArgumentsName': 'dtc_record_num', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'pass_sts', 'ArgumentsType': 'Boolean', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'failed_sts', 'ArgumentsType': 'Boolean', 'ArgumentsKind': 'IN'}
#                 ]
#             }
#         ]
#     }, 
#     {
#         'InterfaceName': 'algo_nvm_data_write', 
#         'Operations': [
#             {
#                 'algo_nvm_data_write': [
#                     {'ArgumentsName': 'data', 'ArgumentsType': 'Boolean', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'data_len', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'nvm_wr_swt', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'nvm_wr_data', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'IN'}
#                 ]
#             }
#         ]
#     }, 
#     {
#         'InterfaceName': 'algo_add_swtStuck', 
#         'Operations': [
#             {
#                 'algo_add_swtStuck': [
#                     {'ArgumentsName': 'status_get', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'stuck_condition', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'stuck_restore', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'change_cb', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'stuck_timeout', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'restore_timeout', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}
#                 ]
#             }, 
#             {
#                 'algo_add_dtcRecord': [
#                     {'ArgumentsName': 'dtc_record_num', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#                     {'ArgumentsName': 'pass_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#                     {'ArgumentsName': 'failed_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}
#                 ]
#             }
#         ]
#     }
# ]
