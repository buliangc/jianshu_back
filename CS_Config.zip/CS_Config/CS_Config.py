#!/usr/bin/python
# -*- coding: UTF-8 -*-
import xml.etree.ElementTree as ET
import os
import GetList
import Generate_Element
import Delete_Element
import Feature
import Add_Element
import Process_Excel
import pickle
from collections import Counter 
import json  
import os

def Interface_Config(geely_zcu_path, interface_path,ZCU_type):
    data = dict()
    data["Excel_Name"] = interface_path
    data["ECU_Name"] = ZCU_type   
    data["SDB_Name"] = next((f for f in os.listdir(os.path.join(geely_zcu_path,"workspace/SDB")) if 'Swc' in f), None)
    geely_cem_path = "workspace/geely_cem"
    swc_path = "workspace/geely_cem/SWC"
   
    InterfaceLib_Dict_List = Process_Excel.Get_InterfaceLib_Dict(data["Excel_Name"], "Interface Lib")
    ClientPort_Dict_List = Process_Excel.Get_Client_Port_Dict(data["Excel_Name"], "Client Port")
    ServerPort_Dict_List = Process_Excel.Get_Server_Port_Dict(data["Excel_Name"], "Server Port")
 
    #解析Geely文件
    Geely_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, geely_cem_path, "geely_cem.arxml"))
    # Geely_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/", "geely_cem.arxml"))

    #获得geely_cem文件下的Assembly连线列表
    Geely_Assembly_connector_list = GetList.Get_Geely_assembly_sw_connector_list(Geely_AUTOSAR)

    #解析Commom文件
    Common_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, geely_cem_path,"Common.arxml"))
    # Common_AUTOSAR = Feature.parse_file("./CS_Config/Common.arxml")

    #获得Commom下PortInterfaces的列表
    CSInterfaces_List = GetList.Get_CSInterfacesList(Common_AUTOSAR)
    
    # 遍历接收端口字典列表  
    for InterfaceLib_Dict in InterfaceLib_Dict_List:  
        if InterfaceLib_Dict["InterfaceName"] in CSInterfaces_List:
            # 找到则删除重建
            Delete_Element.Delete_PortInterfaces_port(Common_AUTOSAR, InterfaceLib_Dict["InterfaceName"])
            element = Generate_Element.Process_CSInterfaces(InterfaceLib_Dict)
            Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)
        else:
            # 找不到则直接新建
            element = Generate_Element.Process_CSInterfaces(InterfaceLib_Dict)
            Add_Element.Add_PortInterfaces_Element(Common_AUTOSAR,element)

    # 创建Client Port
    for ClientPort_Dict in ClientPort_Dict_List:
        # SWC_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/SWC", "{}.arxml".format(ClientPort_Dict["SWC"])))
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ClientPort_Dict["SWC"])))
        # 获取创建的Client Port口
        ClientPort_List = GetList.Get_SwComponentType_ClientPort_List(SWC_AUTOSAR)
        # 获取创建的DataAccess
        ServerCallPoints_List = GetList.Get_SwComponentType_ServerCallPoints_List(SWC_AUTOSAR)
        for ClientPort_Port in ClientPort_Dict['Client_Port_List']:
            if ClientPort_Port["Client_Port"] in ClientPort_List:
                Delete_Element.Delete_SwComponentType_Client_port(SWC_AUTOSAR, ClientPort_Dict["SWC"], ClientPort_Port["Client_Port"])
                element = Generate_Element.Process_ClientPort(ClientPort_Port)
                Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, ClientPort_Dict["SWC"], element)
            else:
                element = Generate_Element.Process_ClientPort(ClientPort_Port)
                Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, ClientPort_Dict["SWC"], element)

            # 客户端在Step中添加DataAccess
            if ClientPort_Port["Operation"] in ServerCallPoints_List:
                Delete_Element.Delete_Synchronous_ServerCallPoints(SWC_AUTOSAR, ClientPort_Dict["SWC"], ClientPort_Port)
                element = Generate_Element.Add_SyncServerCallPoint(ClientPort_Port)
                Add_Element.Add_SwComponentType_SyncServerCallPoint(SWC_AUTOSAR, ClientPort_Dict["SWC"], element, ClientPort_Port)
            else:
                element = Generate_Element.Add_SyncServerCallPoint(ClientPort_Port)
                Add_Element.Add_SwComponentType_SyncServerCallPoint(SWC_AUTOSAR, ClientPort_Dict["SWC"], element, ClientPort_Port)

            ET.indent(SWC_AUTOSAR)
            # Feature.save_file(SWC_AUTOSAR, os.path.join("./CS_Config/SWC", "{}.arxml".format(ClientPort_Dict["SWC"])))
            Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ClientPort_Dict["SWC"])))
            
    # 创建Server Port
    for ServerPort_Dict in ServerPort_Dict_List:
        SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ServerPort_Dict["SWC"])))
        # SWC_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/SWC", "{}.arxml".format(ServerPort_Dict["SWC"])))

        ServerPort_List = GetList.Get_SwComponentType_ServerPort_List(SWC_AUTOSAR)
        OperationEvents_List = GetList.Get_SwComponentType_OperationEvents_List(SWC_AUTOSAR)
        # 原先存在的Runnables
        Runnables_List = GetList.Get_SwComponentType_Runnables_List(SWC_AUTOSAR)
        # 预新增
        newrunnables_List = []
        for ServerPort_Port in ServerPort_Dict['Server_Port_List']:
            # 添加 Port
            if ServerPort_Port["Server_Port"] in ServerPort_List:
                Delete_Element.Delete_SwComponentType_Server_port(SWC_AUTOSAR, ServerPort_Dict["SWC"], ServerPort_Port["Server_Port"])
                element = Generate_Element.Process_ServerPort(ServerPort_Port)
                Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)
            else:
                element = Generate_Element.Process_ServerPort(ServerPort_Port)
                Add_Element.Add_SwComponentType_Port_Element(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)
            
            # 添加 Runnables
            if ServerPort_Port["Runnable_Entity"] in Runnables_List:
                if ServerPort_Port["Runnable_Entity"] in newrunnables_List:
                    pass
                else:
                    newrunnables_List.append(ServerPort_Port["Runnable_Entity"])
                    # 删除 重建
                    Delete_Element.Delete_SwComponentType_Runnables(SWC_AUTOSAR, ServerPort_Dict["SWC"], ServerPort_Port["Runnable_Entity"])
                    element = Generate_Element.Add_RunnableEntry(ServerPort_Port)
                    Add_Element.Add_SwComponentType_Runnable(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)
            else:
                if ServerPort_Port["Runnable_Entity"] in newrunnables_List:
                    pass
                else:
                    newrunnables_List.append(ServerPort_Port["Runnable_Entity"])
                    element = Generate_Element.Add_RunnableEntry(ServerPort_Port)
                    Add_Element.Add_SwComponentType_Runnable(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)

            # 添加 OperationInvokeEvent
            if "oie_" + ServerPort_Port["Access_SWC"] + "_" + ServerPort_Port["Operation"] in OperationEvents_List:
                Delete_Element.Delete_SwComponentType_OperationEvents(SWC_AUTOSAR, ServerPort_Dict["SWC"], ServerPort_Port)
                element = Generate_Element.Add_OperationInvokeEvent(ServerPort_Port)
                Add_Element.Add_SwComponentType_OperationEvent(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)
            else:
                element = Generate_Element.Add_OperationInvokeEvent(ServerPort_Port)
                Add_Element.Add_SwComponentType_OperationEvent(SWC_AUTOSAR, ServerPort_Dict["SWC"], element)
            
            # 添加
            ET.indent(SWC_AUTOSAR)
            Feature.save_file(SWC_AUTOSAR, os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ServerPort_Dict["SWC"])))

    # 添加连线
        for ClientPort_Dict in ClientPort_Dict_List:
            for ClientPort_Port in ClientPort_Dict['Client_Port_List']:
                SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ClientPort_Port["Access_SWC"])))
                # SWC_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/SWC", "{}.arxml".format(ClientPort_Port["Access_SWC"])))
                SwComponentType_Server_Port_List = GetList.Get_SwComponentType_ServerPort_List(SWC_AUTOSAR)

                # 看Client端的口，在Server端是否存在相应的Port口
                if ClientPort_Port["Client_Port"] in SwComponentType_Server_Port_List:  
                    port_line_name = "ac_its_{}{}_its_{}{}".format(ClientPort_Port["Access_SWC"],ClientPort_Port["Client_Port"],ClientPort_Port["SWC"],ClientPort_Port["Client_Port"])
                    if port_line_name not in Geely_Assembly_connector_list:
                        element = Generate_Element.Add_Assembly_Swc_CS_Connector(port_line_name, ClientPort_Port)
                        Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
                        Geely_Assembly_connector_list.append(port_line_name)

        for ServerPort_Dict in ServerPort_Dict_List:
            for ServerPort_Port in ServerPort_Dict['Server_Port_List']:
                SWC_AUTOSAR = Feature.parse_file(os.path.join(geely_zcu_path, swc_path, "{}.arxml".format(ServerPort_Port["Access_SWC"])))
                # SWC_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/SWC", "{}.arxml".format(ServerPort_Port["Access_SWC"])))
                SwComponentType_Client_Port_List = GetList.Get_SwComponentType_ClientPort_List(SWC_AUTOSAR)

                # 看Server端的口，在Client端是否存在相应的Port口
                if ServerPort_Port["Server_Port"] in SwComponentType_Client_Port_List:  
                    port_line_name = "ac_its_{}{}_its_{}{}".format(ServerPort_Port["SWC"],ServerPort_Port["Server_Port"],ServerPort_Port["Access_SWC"],ServerPort_Port["Server_Port"])
                    if port_line_name not in Geely_Assembly_connector_list:
                        element = Generate_Element.Add_Assembly_Swc_CS_Connector(port_line_name, ServerPort_Port)
                        Add_Element.Add_Geely_sw_connector_element(Geely_AUTOSAR,element)
                        Geely_Assembly_connector_list.append(port_line_name)

    ET.indent(Common_AUTOSAR)
    # Feature.save_file(Common_AUTOSAR, "./CS_Config/Common_change.arxml")
    Feature.save_file(Common_AUTOSAR, os.path.join(geely_zcu_path, geely_cem_path, "Common.arxml"))

    ET.indent(Geely_AUTOSAR)
    # Feature.save_file(Geely_AUTOSAR, "./CS_Config/geely_cem.arxml")
    Feature.save_file(Geely_AUTOSAR, os.path.join(geely_zcu_path, geely_cem_path, "geely_cem.arxml"))


Interface_Config("D:/Zcu/ZcuD/Hirain/Intergration_Temp", "D:/Zcu/ZCUP_Port/Hirain_Port/W49D4/驱动接口汇总ZCUP_23R3_U2_01_06.xlsx", "ZCUP")