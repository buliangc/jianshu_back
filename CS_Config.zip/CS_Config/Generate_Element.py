import xml.etree.ElementTree as ET
import xml.dom.minidom as md
import Feature
import uuid
import re

# 处理C/S Interface Operation 的 arguments
def Process_ArgumentData(argumentsName, argumentsType, argumentsKind):
    argument_data_prototype = ET.Element("{http://autosar.org/schema/r4.0}ARGUMENT-DATA-PROTOTYPE")
    argument_data_prototype.set('T',str(Feature.convert_to_datetime()))
    argument_data_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(argument_data_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = argumentsName
    type_tref = ET.SubElement(argument_data_prototype,"{http://autosar.org/schema/r4.0}TYPE-TREF")
    type_tref.set('DEST', "IMPLEMENTATION-DATA-TYPE")
    type_tref.text = "/DataTypeImplementation/" + argumentsType
    direction = ET.SubElement(argument_data_prototype,"{http://autosar.org/schema/r4.0}DIRECTION")
    direction.text = argumentsKind
    server_argument_impl_policy = ET.SubElement(argument_data_prototype,"{http://autosar.org/schema/r4.0}SERVER-ARGUMENT-IMPL-POLICY")
    server_argument_impl_policy.text = "USE-ARGUMENT-TYPE"
    return argument_data_prototype

# 在Common.arxml中 接收 的添加Interface 以及 Operation
def Process_CSInterfaces(Interface_Lib):
    client_server_interface = ET.Element("{http://autosar.org/schema/r4.0}CLIENT-SERVER-INTERFACE")
    client_server_interface.set('T',str(Feature.convert_to_datetime()))
    client_server_interface.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(client_server_interface,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Interface_Lib["InterfaceName"]
    is_service = ET.SubElement(client_server_interface, "{http://autosar.org/schema/r4.0}IS-SERVICE")
    is_service.text = "false"
    operations = ET.SubElement(client_server_interface, "{http://autosar.org/schema/r4.0}OPERATIONS")
    # 遍历有多少Operations
    for Operation in Interface_Lib['Operations']:
        # print(Operation.keys())
        for key in Operation:
            client_server_operation = ET.SubElement(operations, "{http://autosar.org/schema/r4.0}CLIENT-SERVER-OPERATION")
            client_server_operation.set('T',str(Feature.convert_to_datetime()))
            client_server_operation.set('UUID', str(uuid.uuid4()))
            short_name = ET.SubElement(client_server_operation,"{http://autosar.org/schema/r4.0}SHORT-NAME")
            short_name.text = key
            arguments = ET.SubElement(client_server_operation, "{http://autosar.org/schema/r4.0}ARGUMENTS")
            for argument in Operation[key]:
                arguments.append(Process_ArgumentData(argument["ArgumentsName"], argument["ArgumentsType"], argument["ArgumentsKind"]))
    return client_server_interface

# 客户端  R Port口 
def Process_ClientPort(Client_Port):
    r_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    r_port_prototype.set('T',str(Feature.convert_to_datetime()))
    r_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Client_Port["Client_Port"]
    required_interface_tref = ET.SubElement(r_port_prototype,"{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
    required_interface_tref.set('DEST', "CLIENT-SERVER-INTERFACE")
    required_interface_tref.text = "/PortInterfaces/{}".format(Client_Port["Interface"])
    return r_port_prototype

# 客户端在Step中添加DataAccess Rte_Call
def Add_SyncServerCallPoint(Client_Port):
    synchronous_server_call_opint=ET.Element('{http://autosar.org/schema/r4.0}SYNCHRONOUS-SERVER-CALL-POINT')
    synchronous_server_call_opint.set('T',str(Feature.convert_to_datetime()))
    synchronous_server_call_opint.set('UUID', str(uuid.uuid4()))
    short_name=ET.SubElement(synchronous_server_call_opint,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    short_name.text="scp_" + Client_Port["Operation"]
    operation_iref=ET.SubElement(synchronous_server_call_opint,'{http://autosar.org/schema/r4.0}OPERATION-IREF')
    context_r_port_ref=ET.SubElement(operation_iref,'{http://autosar.org/schema/r4.0}CONTEXT-R-PORT-REF')
    context_r_port_ref.set("DEST","R-PORT-PROTOTYPE")
    context_r_port_ref.text="/SwComponentType/" + Client_Port["SWC"] + "/"+ Client_Port["Client_Port"]
    target_required_operation_ref=ET.SubElement(operation_iref,'{http://autosar.org/schema/r4.0}TARGET-REQUIRED-OPERATION-REF')
    target_required_operation_ref.set("DEST","CLIENT-SERVER-OPERATION")
    target_required_operation_ref.text="/PortInterfaces/" + Client_Port["Interface"] + "/" + Client_Port["Operation"]
    timeout=ET.SubElement(synchronous_server_call_opint,'{http://autosar.org/schema/r4.0}TIMEOUT')
    timeout.text="0.0"
    return synchronous_server_call_opint

# 服务端 P Port口
def Process_ServerPort(Server_Port):
    p_port_prototype = ET.Element("{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    p_port_prototype.set('T',str(Feature.convert_to_datetime()))
    p_port_prototype.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Server_Port["Server_Port"]
    provided_interface_tref = ET.SubElement(p_port_prototype,"{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
    provided_interface_tref.set('DEST', "CLIENT-SERVER-INTERFACE")
    provided_interface_tref.text = "/PortInterfaces/{}".format(Server_Port["Interface"])
    return p_port_prototype

# 服务端添加 Runnable
def Add_RunnableEntry(Server_Port):
    runnable_entity = ET.Element("{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    runnable_entity.set('T',str(Feature.convert_to_datetime()))
    runnable_entity.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(runnable_entity,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = Server_Port["Runnable_Entity"]
    minimum_start_interval = ET.SubElement(runnable_entity,"{http://autosar.org/schema/r4.0}MINIMUM-START-INTERVAL")
    minimum_start_interval.text = 0
    can_be_invoked_concurrently = ET.SubElement(runnable_entity,"{http://autosar.org/schema/r4.0}CAN-BE-INVOKED-CONCURRENTLY")
    can_be_invoked_concurrently.text = "true"
    symbol = ET.SubElement(runnable_entity,"{http://autosar.org/schema/r4.0}SYMBOL")
    symbol.text = Server_Port["Runnable_Entity"]
    return runnable_entity

# 服务端添加 Event
def Add_OperationInvokeEvent(Server_Port):
    operation_invoked_event = ET.Element("{http://autosar.org/schema/r4.0}OPERATION-INVOKED-EVENT")
    operation_invoked_event.set('T',str(Feature.convert_to_datetime()))
    operation_invoked_event.set('UUID', str(uuid.uuid4()))
    short_name = ET.SubElement(operation_invoked_event,"{http://autosar.org/schema/r4.0}SHORT-NAME")
    short_name.text = "oie_" + Server_Port["Access_SWC"] + "_" + Server_Port["Operation"]
    start_On_Event_Ref=ET.SubElement(operation_invoked_event,'{http://autosar.org/schema/r4.0}START-ON-EVENT-REF')
    start_On_Event_Ref.set("DEST","RUNNABLE-ENTITY")
    start_On_Event_Ref.text="/SwComponentType/" + Server_Port["SWC"] + "/" + Server_Port["SWC"] + "/" + Server_Port["Runnable_Entity"]
    operation_iref=ET.SubElement(operation_invoked_event,'{http://autosar.org/schema/r4.0}OPERATION-IREF')
    context_p_port_ref=ET.SubElement(operation_iref,'{http://autosar.org/schema/r4.0}CONTEXT-P-PORT-REF')
    context_p_port_ref.set("DEST","P-PORT-PROTOTYPE")
    context_p_port_ref.text="/SwComponentType/" +  Server_Port["SWC"] + "/" +  Server_Port["Server_Port"]
    target_provided_operation_ref=ET.SubElement(operation_iref,'{http://autosar.org/schema/r4.0}TARGET-PROVIDED-OPERATION-REF')
    target_provided_operation_ref.set("DEST","CLIENT-SERVER-OPERATION")
    target_provided_operation_ref.text="/PortInterfaces/" + Server_Port["Interface"] + "/" + Server_Port["Operation"]
    return operation_invoked_event

def Add_Assembly_Swc_CS_Connector(ConnectorName,Client_Port):
    Assembly_Connector=ET.Element('{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR')
    Short_name=ET.SubElement(Assembly_Connector,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    Short_name.text= ConnectorName
    Provider_Iref=ET.SubElement(Assembly_Connector,'{http://autosar.org/schema/r4.0}PROVIDER-IREF')
    PContext_Component_Ref=ET.SubElement(Provider_Iref,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    PContext_Component_Ref.set("DEST","SW-COMPONENT-PROTOTYPE")
    PContext_Component_Ref.text="/geely_cem/geely_cem/its_" + Client_Port["Access_SWC"]
    Target_PPort_Ref=ET.SubElement(Provider_Iref,'{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF')
    Target_PPort_Ref.set("DEST","P-PORT-PROTOTYPE")
    Target_PPort_Ref.text="/SwComponentType/" + Client_Port["Access_SWC"] + "/" + Client_Port["Client_Port"]
    Require_Iref=ET.SubElement(Assembly_Connector,'{http://autosar.org/schema/r4.0}REQUESTER-IREF')
    RContext_Component_Ref=ET.SubElement(Require_Iref,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    RContext_Component_Ref.set("DEST","SW-COMPONENT-PROTOTYPE")
    RContext_Component_Ref.text="/geely_cem/geely_cem/its_" + Client_Port["SWC"]
    Target_RPort_Ref=ET.SubElement(Require_Iref,'{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF')
    Target_RPort_Ref.set("DEST","R-PORT-PROTOTYPE")
    Target_RPort_Ref.text="/SwComponentType/" + Client_Port["SWC"] + "/" + Client_Port["Client_Port"]
    return Assembly_Connector
# {
#     'algo_add_swtStuck': [
#         {'ArgumentsName': 'status_get', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#         {'ArgumentsName': 'stuck_condition', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#         {'ArgumentsName': 'stuck_restore', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#         {'ArgumentsName': 'change_cb', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#         {'ArgumentsName': 'stuck_timeout', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#         {'ArgumentsName': 'restore_timeout', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}
#     ]
# }, 
# {
#     'algo_add_dtcRecord': [
#         {'ArgumentsName': 'dtc_record_num', 'ArgumentsType': 'UInt32', 'ArgumentsKind': 'IN'}, 
#         {'ArgumentsName': 'pass_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}, 
#         {'ArgumentsName': 'failed_record', 'ArgumentsType': 'UInt8', 'ArgumentsKind': 'INOUT'}
#     ]
# }