import xml.etree.ElementTree as ET
import os
import Feature

def Delete_PortInterfaces_port(root,port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    Element = PortInterfacesPkg.find("./{http://autosar.org/schema/r4.0}ELEMENTS")
    PortInterfacesList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}CLIENT-SERVER-INTERFACE")
    for child in PortInterfacesList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)
            
def Delete_SwComponentType_Client_port(root, swc, port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    Application_List = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in Application_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationPkg = child
            break
    Element = ApplicationPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Port_Prototype_List = ApplicationPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for child in Port_Prototype_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)

def Delete_SwComponentType_Server_port(root, swc, port):
    AR_PACKAGES =root[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    Application_List = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in Application_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationPkg = child
            break
    Element = ApplicationPkg.find("./{http://autosar.org/schema/r4.0}PORTS")
    Port_Prototype_List = ApplicationPkg.findall("./{http://autosar.org/schema/r4.0}PORTS/{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for child in Port_Prototype_List:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == port:
            Element.remove(child)

def Delete_SwComponentType_Runnables(root, swc, runnable_name):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    runnables = swc_internal_behaviorsPkg.find("./{http://autosar.org/schema/r4.0}RUNNABLES")

    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == runnable_name:
            runnables.remove(child)

def Delete_SwComponentType_OperationEvents(root, swc, Server_Port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    events = swc_internal_behaviorsPkg.find("./{http://autosar.org/schema/r4.0}EVENTS")

    operation_event_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}EVENTS/{http://autosar.org/schema/r4.0}OPERATION-INVOKED-EVENT")
    for child in operation_event_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "oie_" + Server_Port["Access_SWC"] + "_" + Server_Port["Operation"]:
            events.remove(child)


def Delete_Synchronous_ServerCallPoints(root, swc, ClientPort_Port):
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "SwComponentType":
            SwComponentTypePkg = child
            break
    ApplicationTypeList = SwComponentTypePkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}APPLICATION-SW-COMPONENT-TYPE")
    for child in ApplicationTypeList:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == swc:
            ApplicationTypePkg = child
            break
    swc_internal_behaviorsPkg = ApplicationTypePkg.find("./{http://autosar.org/schema/r4.0}INTERNAL-BEHAVIORS/{http://autosar.org/schema/r4.0}SWC-INTERNAL-BEHAVIOR")
    runnables_entity_list = swc_internal_behaviorsPkg.findall("./{http://autosar.org/schema/r4.0}RUNNABLES/{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for child in runnables_entity_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == ClientPort_Port["Runnable_Entity"]:
            runnables_entityPkg = child
            break
    Element = runnables_entityPkg.find("./{http://autosar.org/schema/r4.0}SERVER-CALL-POINTS")
    serverCallPointsLists = runnables_entityPkg.findall("./{http://autosar.org/schema/r4.0}SERVER-CALL-POINTS/{http://autosar.org/schema/r4.0}SYNCHRONOUS-SERVER-CALL-POINT")
    for child in serverCallPointsLists:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "scp_" + ClientPort_Port["Operation"]:
            Element.remove(child)