import xml.etree.ElementTree as ET
import os
import Feature


def Get_CSInterfacesList(root):
    CSInterfacesList = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "PortInterfaces":
            PortInterfacesPkg = child
            break
    InterfacessList = PortInterfacesPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}CLIENT-SERVER-INTERFACE")
    for child in InterfacessList:
        # print(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
        CSInterfacesList.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return CSInterfacesList

def Get_SwComponentType_ClientPort_List(root):
    ClientPort_List = []
    Receivertemp_list = root.findall(".//{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE")
    for i in Receivertemp_list:
        element = i.find("./{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF")
        
        if element.get("DEST") == "CLIENT-SERVER-INTERFACE":
            ClientPort_List.append(i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return ClientPort_List

def Get_SwComponentType_ServerPort_List(root):
    ServerPort_List = []
    Receivertemp_list = root.findall(".//{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE")
    for i in Receivertemp_list:
        element = i.find("./{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF")
        
        if element.get("DEST") == "CLIENT-SERVER-INTERFACE":
            ServerPort_List.append(i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return ServerPort_List

SWC_AUTOSAR = Feature.parse_file(os.path.join("./CS_Config/SWC", "{}.arxml".format("AlgoTransfer")))

def Get_SwComponentType_ServerCallPoints_List(root):
    ServerCallPoints_List = []
    Synchronous_list = root.findall(".//{http://autosar.org/schema/r4.0}SYNCHRONOUS-SERVER-CALL-POINT/{http://autosar.org/schema/r4.0}SHORT-NAME")
    if Synchronous_list == None:
        return ServerCallPoints_List
    for i in Synchronous_list:
        ServerCallPoints_List.append(i.text.replace("scp_", ""))
    return ServerCallPoints_List

def Get_SwComponentType_Runnables_List(root):
    Runnables_List = []
    RunnableEntry_list = root.findall(".//{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY")
    for i in RunnableEntry_list:
            Runnables_List.append(i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return Runnables_List

def Get_SwComponentType_OperationEvents_List(root):
    OperationEvents_List = []
    operation_list = root.findall(".//{http://autosar.org/schema/r4.0}OPERATION-INVOKED-EVENT")
    if operation_list == None:
        return OperationEvents_List
    for i in operation_list:
            OperationEvents_List.append(i.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return OperationEvents_List

# Get_SwComponentType_Runnables_List(SWC_AUTOSAR)

def Get_Geely_assembly_sw_connector_list(root):
    connector_List = []
    AUTOSAR = root                                               #最顶层标签AUTOSAR
    AR_PACKAGES =AUTOSAR[0]
    for child in AR_PACKAGES:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    composition_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}ELEMENTS/{http://autosar.org/schema/r4.0}COMPOSITION-SW-COMPONENT-TYPE")
    for child in composition_list:
        if child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text == "geely_cem":
            GeelyPkg = child
            break
    connectors_list = GeelyPkg.findall("./{http://autosar.org/schema/r4.0}CONNECTORS/{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR")
    for child in connectors_list:
        connector_List.append(child.find("./{http://autosar.org/schema/r4.0}SHORT-NAME").text)
    return connector_List
