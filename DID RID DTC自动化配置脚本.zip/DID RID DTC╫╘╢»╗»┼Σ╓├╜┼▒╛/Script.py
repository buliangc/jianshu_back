from lxml import etree
from BaseHandle import BaseHandle

'''
脚本功能：
    自动添加DID RID Runnable，DTC CallPoint

脚本使用说明：
    AppDiagMgr和Dcm Service SWC需要在同一个SWC组合级下。    
    
脚本逻辑：
1、抽取DID DTC RID数据
2、删除原来添加的DID DTC RID(脚本添加的数据都会带 _Script 标签)
    2.1删除P-PORT-PROTOTYPE(带 _Script 标签)
    2.2删除R-PORT-PROTOTYPE(带 _Script 标签)
    2.3删除OPERATION-INVOKED-EVENT(带 _Script 标签)
    2.4删除RUNNABLE-ENTITY(带 _Script 标签)
    2.5删除连线
    2.5若CONTEXT-R-PORT-REF带Script，则向上走两次到SYNCHRONOUS-SERVER-CALL-POINT，将其删除。
3、添加
    3.1添加 DID ProvidePort
    3.2添加 RID ProvidePort
    3.3添加 DID Runnable
    3.4添加 RID Runnable
    3.5添加 DID OPERATION-INVOKED-EVENT
    3.6添加 RID OPERATION-INVOKED-EVENT
    3.7添加 DTC SYNCHRONOUS-SERVER-CALL-POINT
    3.8添加 连线
'''

def DID_Rid_Add_PPort(AppDiagMgr_Tree,nsmap,DID_RID_Str):
    PortsNode=AppDiagMgr_Tree.xpath("//as:PORTS",namespaces=nsmap)[0]
    # print(PortsNode)
    # print(DIDStr)
    PPort_NewNode=etree.SubElement(PortsNode,'{http://autosar.org/schema/r4.0}P-PORT-PROTOTYPE')
    PPort_ShortName_NewNode=etree.SubElement(PPort_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    PPort_ShortName_NewNode.text=DID_RID_Str+"_Script"
    PPort_ProvideInterfaceTRef_NewNode=etree.SubElement(PPort_NewNode,'{http://autosar.org/schema/r4.0}PROVIDED-INTERFACE-TREF')
    PPort_ProvideInterfaceTRef_NewNode.set("DEST","CLIENT-SERVER-INTERFACE")
    PPort_ProvideInterfaceTRef_NewNode.text="/AUTOSAR_Dcm/PortInterfaces/"+DID_RID_Str
    print("添加"+DID_RID_Str+" ProvidePort")

def DTC_Add_RPort(AppDiagMgr_Tree,nsmap,DTC_Str):
    PortsNode=AppDiagMgr_Tree.xpath("//as:PORTS",namespaces=nsmap)[0]
    RPort_NewNode=etree.SubElement(PortsNode,'{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE')
    RPort_ShortName_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    RPort_ShortName_NewNode.text=DTC_Str+"_Script"
    RPort_RequireComSpecs_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}REQUIRED-COM-SPECS')

    # OperationList=["SetEventStatus","ResetEventStatus","ResetEventDebounceStatus","PrestoreFreezeFrame","ClearPrestoredFreezeFrame"]
    OperationList=["SetEventStatus"]

    for Operation in OperationList:
        RPort_RequireComSpecs_ClientComSpecs_NewNode=etree.SubElement(RPort_RequireComSpecs_NewNode,'{http://autosar.org/schema/r4.0}CLIENT-COM-SPEC')
        RPort_RequireComSpecs_ClientComSpecs_OperationRef_NewNode=etree.SubElement(RPort_RequireComSpecs_ClientComSpecs_NewNode,'{http://autosar.org/schema/r4.0}OPERATION-REF')
        RPort_RequireComSpecs_ClientComSpecs_OperationRef_NewNode.set("DEST","CLIENT-SERVER-OPERATION")
        RPort_RequireComSpecs_ClientComSpecs_OperationRef_NewNode.text="/AUTOSAR_Dem/PortInterfaces/DiagnosticMonitor/"+Operation
    RPort_RequiredInterfaceTref_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF')
    RPort_RequiredInterfaceTref_NewNode.set("DEST","CLIENT-SERVER-INTERFACE")
    RPort_RequiredInterfaceTref_NewNode.text="/AUTOSAR_Dem/PortInterfaces/DiagnosticMonitor"
    print("添加"+DTC_Str+" RequirePort")

def DemEnablePPort_Add_RPort(AppDiagMgr_Tree,nsmap,DTC_Str):   
    PortsNode=AppDiagMgr_Tree.xpath("//as:PORTS",namespaces=nsmap)[0]
    RPort_NewNode=etree.SubElement(PortsNode,'{http://autosar.org/schema/r4.0}R-PORT-PROTOTYPE')
    RPort_ShortName_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    RPort_ShortName_NewNode.text=DTC_Str+"_Script"
    # RPort_RequireComSpecs_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}REQUIRED-COM-SPECS')
    RPort_RequiredInterfaceTref_NewNode=etree.SubElement(RPort_NewNode,'{http://autosar.org/schema/r4.0}REQUIRED-INTERFACE-TREF')
    RPort_RequiredInterfaceTref_NewNode.set("DEST","CLIENT-SERVER-INTERFACE")
    RPort_RequiredInterfaceTref_NewNode.text="/AUTOSAR_Dem/PortInterfaces/EnableCondition"
    print("添加"+DTC_Str+" RequirePort")

def DTC_Add_SyncServerCallPoint(ServerCallPointNode,nsmap,DTC_Str,operation,index):
    SyncServerCallPoint_NewNode=etree.SubElement(ServerCallPointNode,'{http://autosar.org/schema/r4.0}SYNCHRONOUS-SERVER-CALL-POINT')
    SyncServerCallPoint_ShortName_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    SyncServerCallPoint_ShortName_NewNode.text="scp_" + operation + "_" + str(index)
    SyncServerCallPoint_OperationIref_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}OPERATION-IREF')
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode=etree.SubElement(SyncServerCallPoint_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-R-PORT-REF')
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode.set("DEST","R-PORT-PROTOTYPE")
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode.text="/SwComponentType/AppDiagMgr/"+DTC_Str+"_Script"
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode=etree.SubElement(SyncServerCallPoint_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-REQUIRED-OPERATION-REF')
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode.set("DEST","CLIENT-SERVER-OPERATION")
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode.text="/AUTOSAR_Dem/PortInterfaces/DiagnosticMonitor/" + operation
    SyncServerCallPoint_Timeout_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}TIMEOUT')
    SyncServerCallPoint_Timeout_NewNode.text="0.0"
    print("添加"+DTC_Str+" SyncServerCallPoint")

def DTC_Add_SyncServerCallPoint_EnableCondition(ServerCallPointNode,nsmap,DTC_Str,operation,index):
    SyncServerCallPoint_NewNode=etree.SubElement(ServerCallPointNode,'{http://autosar.org/schema/r4.0}SYNCHRONOUS-SERVER-CALL-POINT')
    SyncServerCallPoint_ShortName_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    SyncServerCallPoint_ShortName_NewNode.text="scp_" + operation + "_" + str(index)
    SyncServerCallPoint_OperationIref_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}OPERATION-IREF')
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode=etree.SubElement(SyncServerCallPoint_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-R-PORT-REF')
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode.set("DEST","R-PORT-PROTOTYPE")
    SyncServerCallPoint_OperationIref_ContextRPortRef_NewNode.text="/SwComponentType/AppDiagMgr/"+DTC_Str+"_Script"
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode=etree.SubElement(SyncServerCallPoint_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-REQUIRED-OPERATION-REF')
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode.set("DEST","CLIENT-SERVER-OPERATION")
    SyncServerCallPoint_OperationIref_TargetRequiredOperationRef_NewNode.text="/AUTOSAR_Dem/PortInterfaces/EnableCondition/" + operation
    SyncServerCallPoint_Timeout_NewNode=etree.SubElement(SyncServerCallPoint_NewNode,'{http://autosar.org/schema/r4.0}TIMEOUT')
    SyncServerCallPoint_Timeout_NewNode.text="0.0"
    print("添加"+DTC_Str+" SyncServerCallPoint")

    
def DID_Rid_Add_RunnableEntry(AppDiagMgr_Tree,nsmap,DID_RID_Str,Operation):
    RunnablesNode=AppDiagMgr_Tree.xpath("//as:RUNNABLES",namespaces=nsmap)[0]
    RunnablesEntry_NewNode=etree.SubElement(RunnablesNode,'{http://autosar.org/schema/r4.0}RUNNABLE-ENTITY')
    RunnablesEntry_ShortName_NewNode=etree.SubElement(RunnablesEntry_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    RunnablesEntry_ShortName_NewNode.text=DID_RID_Str+"_"+Operation+"_Script"
    RunnablesEntry_Minimum_Start_Interval_NewNode=etree.SubElement(RunnablesEntry_NewNode,'{http://autosar.org/schema/r4.0}MINIMUM-START-INTERVAL')
    RunnablesEntry_Minimum_Start_Interval_NewNode.text="0.0"
    RunnablesEntry_Can_Be_Invoked_Concurrently_NewNode=etree.SubElement(RunnablesEntry_NewNode,'{http://autosar.org/schema/r4.0}CAN-BE-INVOKED-CONCURRENTLY')
    RunnablesEntry_Can_Be_Invoked_Concurrently_NewNode.text="false"
    RunnablesEntry_Symbol_NewNode=etree.SubElement(RunnablesEntry_NewNode,'{http://autosar.org/schema/r4.0}SYMBOL')
    RunnablesEntry_Symbol_NewNode.text=DID_RID_Str+"_"+Operation
    print(DID_RID_Str+"_"+Operation+" Runnable添加完成")

def DID_Rid_Add_OperationInvokeEvent(AppDiagMgr_Tree,nsmap,DID_RID_Str,Operation):
    EventsNode=AppDiagMgr_Tree.xpath("//as:EVENTS",namespaces=nsmap)[0]
    OperationInvokedEvent_NewNode=etree.SubElement(EventsNode,'{http://autosar.org/schema/r4.0}OPERATION-INVOKED-EVENT')
    OperationInvokedEvent_ShortName_NewNode=etree.SubElement(OperationInvokedEvent_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    OperationInvokedEvent_ShortName_NewNode.text="oie_"+DID_RID_Str+"_"+Operation+"_Script"
    OperationInvokedEvent_StartOnEventRef_NewNode=etree.SubElement(OperationInvokedEvent_NewNode,'{http://autosar.org/schema/r4.0}START-ON-EVENT-REF')
    OperationInvokedEvent_StartOnEventRef_NewNode.set("DEST","RUNNABLE-ENTITY")
    OperationInvokedEvent_StartOnEventRef_NewNode.text="/SwComponentType/AppDiagMgr/AppDiagMgr/"+DID_RID_Str+"_"+Operation+"_Script"
    OperationInvokedEvent_OperationIref_NewNode=etree.SubElement(OperationInvokedEvent_NewNode,'{http://autosar.org/schema/r4.0}OPERATION-IREF')
    OperationInvokedEvent_OperationIref_ContextPPortRef_NewNode=etree.SubElement(OperationInvokedEvent_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-P-PORT-REF')
    OperationInvokedEvent_OperationIref_ContextPPortRef_NewNode.set("DEST","P-PORT-PROTOTYPE")
    OperationInvokedEvent_OperationIref_ContextPPortRef_NewNode.text="/SwComponentType/AppDiagMgr/"+DID_RID_Str+"_Script"
    OperationInvokedEvent_OperationIref_TargetProvidedOperationRef_NewNode=etree.SubElement(OperationInvokedEvent_OperationIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-PROVIDED-OPERATION-REF')
    OperationInvokedEvent_OperationIref_TargetProvidedOperationRef_NewNode.set("DEST","CLIENT-SERVER-OPERATION")
    OperationInvokedEvent_OperationIref_TargetProvidedOperationRef_NewNode.text="/AUTOSAR_Dcm/PortInterfaces/"+DID_RID_Str+"/"+Operation
    print(DID_RID_Str+"_"+Operation+" OperationInvokeEvent添加完成")
    

def Add_Assembly_Swc_Connector_DID_RID(ConnectorNodes,nsmap,DidStr):
    AssemblyConnector_NewNode=etree.SubElement(ConnectorNodes,'{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR')
    AssemblyConnector_ShortName_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    AssemblyConnector_ShortName_NewNode.text="ac_AppDiagMgr_Dcm_"+DidStr+"_Script"
    AssemblyConnector_ProviderIref_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}PROVIDER-IREF')
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode=etree.SubElement(AssemblyConnector_ProviderIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode.set("DEST","SW-COMPONENT-PROTOTYPE")
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode.text="/basetech/basetech/AppDiagMgr"
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode=etree.SubElement(AssemblyConnector_ProviderIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF')
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode.set("DEST","P-PORT-PROTOTYPE")
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode.text="/SwComponentType/AppDiagMgr/"+DidStr+"_Script"
    AssemblyConnector_RequireIref_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}REQUESTER-IREF')
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode=etree.SubElement(AssemblyConnector_RequireIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode.set("DEST","SW-COMPONENT-PROTOTYPE")
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode.text="/basetech/basetech/Dcm"
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode=etree.SubElement(AssemblyConnector_RequireIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF')
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode.set("DEST","R-PORT-PROTOTYPE")
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode.text="/AUTOSAR_Dcm/SwComponentTypes/Dcm/"+DidStr
    print("添加连线"+"ac_AppDiagMgr_Dcm_"+DidStr+"_Script")


def Add_Assembly_Swc_Connector_Dtc(ConnectorNodes,nsmap,DtcStr):
    AssemblyConnector_NewNode=etree.SubElement(ConnectorNodes,'{http://autosar.org/schema/r4.0}ASSEMBLY-SW-CONNECTOR')
    AssemblyConnector_ShortName_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}SHORT-NAME')
    AssemblyConnector_ShortName_NewNode.text="ac_AppDiagMgr_Dcm_"+DtcStr+"_Script"
    AssemblyConnector_ProviderIref_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}PROVIDER-IREF')
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode=etree.SubElement(AssemblyConnector_ProviderIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode.set("DEST","SW-COMPONENT-PROTOTYPE")
    AssemblyConnector_ProviderIref_ContextComponentRef_NewNode.text="/basetech/basetech/DEM"
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode=etree.SubElement(AssemblyConnector_ProviderIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-P-PORT-REF')
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode.set("DEST","P-PORT-PROTOTYPE")
    AssemblyConnector_ProviderIref_TargetPPortRef_NewNode.text="/AUTOSAR_Dem/SwComponentTypes/Dem/"+DtcStr
    AssemblyConnector_RequireIref_NewNode=etree.SubElement(AssemblyConnector_NewNode,'{http://autosar.org/schema/r4.0}REQUESTER-IREF')
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode=etree.SubElement(AssemblyConnector_RequireIref_NewNode,'{http://autosar.org/schema/r4.0}CONTEXT-COMPONENT-REF')
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode.set("DEST","SW-COMPONENT-PROTOTYPE")
    AssemblyConnector_RequireIref_ContextComponentRef_NewNode.text="/basetech/basetech/AppDiagMgr"
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode=etree.SubElement(AssemblyConnector_RequireIref_NewNode,'{http://autosar.org/schema/r4.0}TARGET-R-PORT-REF')
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode.set("DEST","R-PORT-PROTOTYPE")
    AssemblyConnector_RequireIref_TargetRPortRef_NewNode.text="/SwComponentType/AppDiagMgr/"+DtcStr+"_Script"
    print("添加连线"+"ac_AppDiagMgr_Dcm_"+DtcStr+"_Script")
    

def GetDidRidDTCData():
    print("#"*50+"Step 1:[Start]抽取DID RID DTC数据"+"#"*50)
    nsmap={'as':'http://autosar.org/schema/r4.0'}
    BaseHandleInterface=BaseHandle()
    Dcm_swc_interface_Tree=etree.parse('./DID RID DTC自动化配置脚本/input/Dcm_swc_interface.arxml')
    Dem_swc_internal_Tree=etree.parse('./DID RID DTC自动化配置脚本/input/Dem_swc_internal.arxml')
    DTC_List=[]
    DID_List=[]
    RID_List=[]
    Dem_EnableCond_P_Ports=[]

    #抓取DID、RID数据
    PortInterface_CS_DID_List=Dcm_swc_interface_Tree.xpath("//as:CLIENT-SERVER-INTERFACE",namespaces=nsmap)
    for PortInterface_CS_DID in PortInterface_CS_DID_List:
        ShortName=PortInterface_CS_DID.xpath("./as:SHORT-NAME",namespaces=nsmap)[0]

        if "DID" in ShortName.text:
            OperationNode_List=PortInterface_CS_DID.xpath("./as:OPERATIONS/as:CLIENT-SERVER-OPERATION/as:SHORT-NAME",namespaces=nsmap)
            Operation_List=[]
            for OperationNode in OperationNode_List:
                Operation_List.append(OperationNode.text)
            DID_Op_Map={"DID":ShortName.text,"Operation":Operation_List}
            DID_List.append(DID_Op_Map)
    
        elif "RID" in ShortName.text:
            OperationNode_List=PortInterface_CS_DID.xpath("./as:OPERATIONS/as:CLIENT-SERVER-OPERATION/as:SHORT-NAME",namespaces=nsmap)
            Operation_List=[]
            for OperationNode in OperationNode_List:
                Operation_List.append(OperationNode.text)
            RID_Op_Map={"RID":ShortName.text,"Operation":Operation_List}
            RID_List.append(RID_Op_Map)

    # print("抓取到的DID, Operation有：")
    # for DID in DID_List:
    #     print(DID)

    # print("抓取到的RID有, Operation：")
    # for RID in RID_List:
    #     print(RID)

    #抓取DTC数据
    PortInterface_CS_DTC_List=Dem_swc_internal_Tree.xpath("//as:P-PORT-PROTOTYPE",namespaces=nsmap)
    for PortInterface_CS_DTC in PortInterface_CS_DTC_List:
        DTCEvent=PortInterface_CS_DTC.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "Event_" in DTCEvent:
            DTC_List.append(DTCEvent)
        elif "EnableCond_" in  DTCEvent:
            Dem_EnableCond_P_Ports.append(DTCEvent)

    # 拿到Dem中 Port和Interface的对应关系
    
    # print("抓取到的DTC有：")
    # for DTC in DTC_List:
    #     print(DTC)
    # print("抓取到的DemPPort有：")
    # for DemPPort in Dem_EnableCond_P_Ports:
    #     print(DemPPort)
    
    RetValMap={"DID":DID_List,"RID":RID_List,"DTC":DTC_List, "DemEnablePPort":Dem_EnableCond_P_Ports}
    
    # print("#"*50+"Step 1:[End]抽取DID RID DTC数据"+"#"*50)

    return RetValMap

def DeleteDidRidDTCDataToAppDiagMgr(AppDiagMgr_Tree,SDB_SWC_Tree,nsmap):
    print("#"*50+"Step 2:[Start]删除原有的DID RID DTC"+"#"*50)
    
    BaseHandleInterface=BaseHandle()
    
    # 删除原来脚本创建的Provide Port, 带_Script需要进行删除
    PPortNode_List=AppDiagMgr_Tree.xpath("//as:P-PORT-PROTOTYPE",namespaces=nsmap)
    for PPortNode in PPortNode_List:
        PPortNode_FatherNode=PPortNode.xpath('..',namespaces=nsmap)[0]
        PPort=PPortNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        # 判断是否存在_Script字段，如果存在则是脚本添加的，删除。
        if "_Script" in PPort:
            print(PPort)
            BaseHandleInterface.NodeDelete(PPortNode,PPortNode_FatherNode)
    print("Provide Port删除完成")

    # 删除原来脚本创建的Requirt Port
    RPortNode_List=AppDiagMgr_Tree.xpath("//as:R-PORT-PROTOTYPE",namespaces=nsmap)
    for RPortNode in RPortNode_List:
        RPortNode_FatherNode=RPortNode.xpath('..',namespaces=nsmap)[0]
        RPort=RPortNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        #判断是否存在_Script字段，如果存在则是脚本添加的，删除。
        if "_Script" in RPort:
            print(RPort)
            BaseHandleInterface.NodeDelete(RPortNode,RPortNode_FatherNode)
    print("Requirt Port删除完成")

    #删除原来脚本创建的OPERATION-INVOKED-EVENT
    OieNode_List=AppDiagMgr_Tree.xpath("//as:OPERATION-INVOKED-EVENT",namespaces=nsmap)
    for OieNode in OieNode_List:
        OieNode_FatherNode=OieNode.xpath('..',namespaces=nsmap)[0]
        Oie=OieNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "_Script" in Oie:
            print(Oie)
            BaseHandleInterface.NodeDelete(OieNode,OieNode_FatherNode)
    print("Oie删除完成")

    #删除原来脚本创建的RUNNABLE-ENTIT
    RunnableEntry_List=AppDiagMgr_Tree.xpath("//as:RUNNABLE-ENTITY",namespaces=nsmap)
    for RunnableEntryNode in RunnableEntry_List:
        RunnableEntry_FatherNode=RunnableEntryNode.xpath('..',namespaces=nsmap)[0]
        RunnableEntry=RunnableEntryNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "_Script" in RunnableEntry:
            print(RunnableEntry)
            BaseHandleInterface.NodeDelete(RunnableEntryNode,RunnableEntry_FatherNode)
    print("RunnableEntry删除完成")

    #删除DTC Access
    DTCCallPointNode_List=AppDiagMgr_Tree.xpath("//as:CONTEXT-R-PORT-REF",namespaces=nsmap)
    for DTCCallPointNode in DTCCallPointNode_List :
        if "_Script" in DTCCallPointNode.text:
            TempDeleNode=DTCCallPointNode.xpath("../..",namespaces=nsmap)[0]
            TempDeleNode_FatherNode=TempDeleNode.xpath("..",namespaces=nsmap)[0]
            print("CONTEXT-R-PORT-REF为"+DTCCallPointNode.text+"的SYNCHRONOUS-SERVER-CALL-POINT删除完成")
            BaseHandleInterface.NodeDelete(TempDeleNode,TempDeleNode_FatherNode)
    print("DTC CallPoint删除完成")      

    #删除连线
    AssemblyConnectorNodes=SDB_SWC_Tree.xpath("//as:ASSEMBLY-SW-CONNECTOR",namespaces=nsmap)
    for AssemblyConnectorNode in AssemblyConnectorNodes:
        AssemblyConnector=AssemblyConnectorNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "_Script" in AssemblyConnector:
            AssemblyConnectorFatherNode=AssemblyConnectorNode.xpath("..",namespaces=nsmap)[0]
            BaseHandleInterface.NodeDelete(AssemblyConnectorNode,AssemblyConnectorFatherNode)
            print(AssemblyConnector)
    print("所有连线删除完成")

    print("#"*50+"Step 2:[End]删除原有的DID RID DTC"+"#"*50)

def AddDidRidDTCDataToAppDiagMgr(AppDiagMgr_Tree,SDB_SWC_Tree,nsmap,DidRidDTCData):
    Did_List=DidRidDTCData["DID"]
    Rid_List=DidRidDTCData["RID"]
    Dtc_List=DidRidDTCData["DTC"]
    DemEnablePPort_List=DidRidDTCData["DemEnablePPort"]

    #添加DID的Provide Port
    for Did in Did_List:
        DID_Rid_Add_PPort(AppDiagMgr_Tree,nsmap,Did['DID'])

    #添加RID的Provide Port
    for Rid in Rid_List:
        DID_Rid_Add_PPort(AppDiagMgr_Tree,nsmap,Rid['RID'])

    #添加DID的Runnable
    for Did in Did_List:
        for Operation in Did["Operation"]:
            DID_Rid_Add_RunnableEntry(AppDiagMgr_Tree,nsmap,Did['DID'],Operation)

    #添加RID的Runnable
    for Rid in Rid_List:
        for Operation in Rid["Operation"]:
            DID_Rid_Add_RunnableEntry(AppDiagMgr_Tree,nsmap,Rid['RID'],Operation)

    #添加DID的OPERATION-INVOKED-EVENT
    for Did in Did_List:
        for Operation in Did["Operation"]:
            DID_Rid_Add_OperationInvokeEvent(AppDiagMgr_Tree,nsmap,Did['DID'],Operation)

    #添加RID的OPERATION-INVOKED-EVENT
    for Rid in Rid_List:
        for Operation in Rid["Operation"]:
            DID_Rid_Add_OperationInvokeEvent(AppDiagMgr_Tree,nsmap,Rid['RID'],Operation)

    #添加DTC RequirePort
    for DTC in Dtc_List:
        DTC_Add_RPort(AppDiagMgr_Tree,nsmap,DTC)

    for DemEnablePPort in DemEnablePPort_List:
        DemEnablePPort_Add_RPort(AppDiagMgr_Tree,nsmap,DemEnablePPort)

    #添加DTC Access
    print("#"*50+"Step 8:[Start]添加DTC Access"+"#"*50)
    RunnableEntry_AppDiagMgrStepNode=None
    RunnableEntryNodes=AppDiagMgr_Tree.xpath("//as:RUNNABLE-ENTITY",namespaces=nsmap)
    for RunnableEntryNode in RunnableEntryNodes:
        RunnableEntry=RunnableEntryNode.xpath('./as:SHORT-NAME',namespaces=nsmap)[0].text
        if RunnableEntry== "AppDiagMgr_Step":
           RunnableEntry_AppDiagMgrStepNode=RunnableEntryNode
    ServerCallPoint=RunnableEntry_AppDiagMgrStepNode.xpath("./as:SERVER-CALL-POINTS",namespaces=nsmap)[0]

    # DTC_OperationList=["SetEventStatus","ResetEventStatus","ResetEventDebounceStatus","PrestoreFreezeFrame","ClearPrestoredFreezeFrame"]
    DTC_OperationList=["SetEventStatus"]

    EnableCondition_OperationList=["SetEnableCondition"]

    index=0
    for Dtc in Dtc_List:
        for operation in DTC_OperationList:
            index=index+1
            DTC_Add_SyncServerCallPoint(ServerCallPoint, nsmap, Dtc, operation, index)

    index=0
    for DemEnablePPort in DemEnablePPort_List:
        for operation in EnableCondition_OperationList:
            index=index+1
            DTC_Add_SyncServerCallPoint_EnableCondition(ServerCallPoint, nsmap, DemEnablePPort, operation ,index)
    print("#"*50+"Step 8:[End]添加DTC Access"+"#"*50)

    #添加连线
    ConnectorNodes=SDB_SWC_Tree.xpath("//as:CONNECTORS",namespaces=nsmap)[0]
    for Did in Did_List:
        Add_Assembly_Swc_Connector_DID_RID(ConnectorNodes,nsmap,Did['DID'])

    # ConnectorNodes=SDB_SWC_Tree.xpath("//as:CONNECTORS",namespaces=nsmap)[0]
    for Rid in Rid_List:
        Add_Assembly_Swc_Connector_DID_RID(ConnectorNodes,nsmap,Rid['RID'])

    # ConnectorNodes=SDB_SWC_Tree.xpath("//as:CONNECTORS",namespaces=nsmap)[0]
    for Dtc in Dtc_List:
        Add_Assembly_Swc_Connector_Dtc(ConnectorNodes,nsmap,Dtc)
        
    # ConnectorNodes=SDB_SWC_Tree.xpath("//as:CONNECTORS",namespaces=nsmap)[0]
    for DemEnablePPort in DemEnablePPort_List:
        Add_Assembly_Swc_Connector_Dtc(ConnectorNodes,nsmap,DemEnablePPort)


def DID_RID_DTC_ChangeInfo(AppDiagMgr_Old_Tree,AppDiagMgr_New_Tree,nsmap):
    RunnableList_Old=[]
    RunnableList_New=[]
    DTCList_Old=[]
    DTCList_New=[]
    RunnablesNode_List_Old=AppDiagMgr_Old_Tree.xpath('//as:RUNNABLE-ENTITY',namespaces=nsmap)
    for RunnablesNode_Old in RunnablesNode_List_Old:
        Runnable_Old=RunnablesNode_Old.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "_Script" in Runnable_Old:
            RunnableSymbol=RunnablesNode_Old.xpath("./as:SYMBOL",namespaces=nsmap)[0].text
            RunnableList_Old.append(RunnableSymbol)

    RunnablesNode_List_New=AppDiagMgr_New_Tree.xpath('//as:RUNNABLE-ENTITY',namespaces=nsmap)
    for RunnablesNode_New in RunnablesNode_List_New:
        Runnable_New=RunnablesNode_New.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        if "_Script" in Runnable_New:
            RunnableSymbol=RunnablesNode_New.xpath("./as:SYMBOL",namespaces=nsmap)[0].text
            RunnableList_New.append(RunnableSymbol)

    RequirePortsNode_Old=AppDiagMgr_Old_Tree.xpath('//as:R-PORT-PROTOTYPE',namespaces=nsmap)
    for RequirePortNode in RequirePortsNode_Old:
        RequirePort=RequirePortNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        DTCList_Old.append(RequirePort)

    RequirePortsNode_New=AppDiagMgr_New_Tree.xpath('//as:R-PORT-PROTOTYPE',namespaces=nsmap)
    for RequirePortNode in RequirePortsNode_New:
        RequirePort=RequirePortNode.xpath("./as:SHORT-NAME",namespaces=nsmap)[0].text
        DTCList_New.append(RequirePort)
    
    #DID\RID老的找新的，若找不到，则说明删除
    Runnalbe_Del=[]
    for Runnable_Old in RunnableList_Old:
        FindFlag=False
        for Runnable_New in RunnableList_New:
            if Runnable_Old==Runnable_New:
                FindFlag=True
                break
        if FindFlag==False:
            Runnalbe_Del.append(Runnable_Old)
    print("DID、RID删除的接口有：")
    for Runnable in Runnalbe_Del:
        print(Runnable)

    #DID\RID新的找老的，若找不到，则说明是新加的
    Runnalbe_Add=[]
    for Runnable_New in RunnableList_New:
        FindFlag=False
        for Runnable_Old in RunnableList_Old:
            if Runnable_Old==Runnable_New:
                FindFlag=True
                break
        if FindFlag==False:
            Runnalbe_Add.append(Runnable_New)
    print("DID、RID增加的接口有：")
    for Runable in Runnalbe_Add:
        print(Runable)

    #DTC老的找新的，若找不到，则说明删除
    DTC_Del=[]
    for DTC_Old in DTCList_Old:
        FindFlag=False
        for DTC_New in DTCList_New:
            if DTC_Old==DTC_New:
                FindFlag=True
                break
        if FindFlag==False:
            DTC_Del.append(DTC_Old)
    print("DTC删除的接口有：")
    for DTC in DTC_Del:
        print(DTC)

    #DTC新的找老的，若找不到，则说明是新加的
    DTC_Add=[]
    for DTC_New in DTCList_New:
        FindFlag=False
        for DTC_Old in DTCList_Old:
            if DTC_Old==DTC_New:
                FindFlag=True
                break
        if FindFlag==False:
            DTC_Add.append(DTC_New)
    print("DTC增加的接口有：")
    for DTC in DTC_Add:
        print(DTC)

def main():

    #获取树
    AppDiagMgr_Tree=etree.parse('./DID RID DTC自动化配置脚本/input/AppDiagMgr.arxml')
    SDB_SWC_Tree=etree.parse('./DID RID DTC自动化配置脚本/input/basetech.arxml')

    nsmap={'as':'http://autosar.org/schema/r4.0'}

    # 抽取DID RID DTC数据
    DidRidDTCData = GetDidRidDTCData()
    # 删除
    DeleteDidRidDTCDataToAppDiagMgr(AppDiagMgr_Tree,SDB_SWC_Tree,nsmap)
    AddDidRidDTCDataToAppDiagMgr(AppDiagMgr_Tree,SDB_SWC_Tree,nsmap,DidRidDTCData)

    # 保存
    root=AppDiagMgr_Tree.getroot()
    etree.ElementTree(root).write("./DID RID DTC自动化配置脚本/output/AppDiagMgr.arxml",pretty_print=True, encoding='utf-8', xml_declaration=True)

    root2=SDB_SWC_Tree.getroot()
    etree.ElementTree(root2).write("./DID RID DTC自动化配置脚本/output/basetech.arxml",pretty_print=True, encoding='utf-8', xml_declaration=True)

    #比较新增接口和删除接口
    AppDiagMgr_Old_Tree=etree.parse('./DID RID DTC自动化配置脚本/input/AppDiagMgr.arxml')
    AppDiagMgr_New_Tree=etree.parse('./DID RID DTC自动化配置脚本/output/AppDiagMgr.arxml')
    DID_RID_DTC_ChangeInfo(AppDiagMgr_Old_Tree,AppDiagMgr_New_Tree,nsmap)

    print("处理完成")

main()
