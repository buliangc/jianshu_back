
import uuid

from xml.dom import minidom

from xml.etree import ElementTree as ET

class BaseHandle:
    def __init__(self):
        pass
    
        
    def NodeDelete(self,DeleteNode:ET.Element,DeleteFatherNode:ET.Element):
        child_nodes=DeleteNode.findall('*')
        if len(child_nodes)==0:
            DeleteFatherNode.remove(DeleteNode)
        else:
            for child_node in child_nodes:
                BaseHandleInterface=BaseHandle()
                BaseHandleInterface.NodeDelete(child_node,DeleteNode)
                child_nodes.remove(child_node)
            DeleteFatherNode.remove(DeleteNode)

    def GetUUID(self):
        uid= uuid.uuid4()
        return uid
    

    def FormateArxml(self,input,output):
        with open(input,'r') as f:
            xml_str = f.read()
        dom = minidom.parseString(xml_str)
        pretty_xml_str=dom.toprettyxml(indent='\t')
        with open(output,'w') as f:
            f.write(pretty_xml_str)
        with open(output,'r') as file:
            lines=file.readlines()
        lines = [line for line in lines if line.strip()]
        with open(output,'w')as file:
            file.writelines(lines)

    #输入一个列表
    #输入一个列表
    #例如:输入[a,b,c,d,a]
    #     输出[a_1,b,c,d,a_2]
    def GeneratedIndex(self,MyList=[]):
        count_dict={}
        count_dict2={}
        for item in MyList:
            if item not in count_dict:
                count_dict[item]=1
                count_dict2[item]=1
            else:
                count_dict[item]+=1
                count_dict2[item]+=1
        
        for i,item in enumerate(MyList):
            if count_dict2[item]>1:
                if count_dict[item]>0:
                    MyList[i]=f"{item}_{count_dict2[item]-(count_dict[item]-1)}"
                    count_dict[item] -=1
        return MyList


    #输入：字符串
    #输出：将非数字和非英文字母字符的删除并用_替换
    #例如输入"abcde () fg()Hi()  123"
    #   输出"abcde_fg_Hi_123"
    def HandleString(self,temp_str):
        templist = []
        FinallyString = ""
        for i in range(len(temp_str)):
            templist.append(temp_str[i])

        FirstIsEnglisthOrNumberFlag=False

        #删除头部的非数字和非英文字母字符
        while FirstIsEnglisthOrNumberFlag==False:
            if (ord(templist[0]) >= 65 and ord(templist[0]) <= 90) or (
                    ord(templist[0]) >= 97 and ord(templist[0]) <= 122
            ) or (ord(templist[0]) >= 48 and ord(templist[0]) <= 57):
                    FirstIsEnglisthOrNumberFlag = True
                    break
            else:
                templist.pop(0)

        #删除中间、末尾的非数字和非英文字母字符删除，用_替换
        s = 0
        IsNotEnglishOrNumberFlag = False
        t = len(templist)
        i = 0
        while i < t:
            if (ord(templist[i - s]) >= 65 and ord(templist[i - s]) <= 90) or (
                    ord(templist[i - s]) >= 97 and ord(templist[i - s]) <= 122
            ) or (ord(templist[i - s]) >= 48 and ord(templist[i - s]) <= 57):
                #print(temp_string[i])
                if IsNotEnglishOrNumberFlag == True:
                    templist.insert(i - s, "_")
                    IsNotEnglishOrNumberFlag = False
                    t = t + 1
            else:
                templist.pop(i - s)
                s = s + 1
                IsNotEnglishOrNumberFlag = True
            i = i + 1
            if i == t:
                break
        for i in range(len(templist)):
            FinallyString = FinallyString + templist[i]
        return FinallyString